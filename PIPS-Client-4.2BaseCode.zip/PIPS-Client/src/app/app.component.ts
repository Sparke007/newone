import { AfterViewInit, Component } from '@angular/core';
import { OnDestroy, OnInit } from '@angular/core/src/metadata/lifecycle_hooks';
import { NavigationCancel, NavigationEnd, NavigationStart, Router } from '@angular/router';
import { ISubscription } from 'rxjs/Subscription';

import { environment } from '../environments/environment';
import { Constants } from './shared/interfaces/constants';
import { LoaderState } from './shared/interfaces/loader';
import { CustomerService } from './shared/services/customer.service';
import { HttpLocaleService } from './shared/services/http-locale.service';
import { LoaderService } from './shared/services/loader.service';


@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent implements OnInit, OnDestroy, AfterViewInit {
  httpError: string;
  loading: boolean;
  show: Boolean = false;
  disable: Boolean = false;
  subRouteNavigation: ISubscription;
  requestarray = 0;
  constructor(private srvCustomer: CustomerService, private srvHttpLocale: HttpLocaleService,
    public loaderService: LoaderService, private router: Router) {
    this.loading = true;
  }

  ngOnInit() {
    let thresholdTimer: any;
    const threshold = (environment.loaderDelaySeconds > 0) ? environment.loaderDelaySeconds * 1000 : 0;
    this.loaderService.loaderState
      .subscribe((state: LoaderState) => {
        const show = state.show;
        if (this.requestarray === 0 && !state.show) {
          return;
        }
        if (state.cancel) {
          this.show = false;
          this.requestarray = 1;
        }
        if (show) {
          this.requestarray++;
          this.disable = true;
          if (thresholdTimer) {
            return;
          }
          thresholdTimer = setTimeout(function () {
            thresholdTimer = null;
            this.show = true;
          }.bind(this), threshold);
        } else {

          this.requestarray--;
          if (this.requestarray === 0) {
            if (thresholdTimer) {
              clearTimeout(thresholdTimer);
              thresholdTimer = null;
            }
            this.disable = false;
            this.show = false;
          }
        }
      });


    this.srvHttpLocale.httpError.subscribe(error => {
      if (error) {
        if (error.errorCode !== undefined && error.errorCode === Constants.PadZero) {
          this.httpError = Constants.Generic;
        } else { this.httpError = error.errorCode; }
      } else {
        this.httpError = Constants.Empty;
      }
    });

    const localNationalId = sessionStorage.getItem(Constants.NationalId);
    if (localNationalId) {
      this.srvCustomer.setNationalId(localNationalId);
    }

    const localCustomerId = sessionStorage.getItem(Constants.CustomerId);
    if (localCustomerId) {
      this.srvCustomer.setCustomerId(localCustomerId);
    }
  }

  ngAfterViewInit(): void {

    this.subRouteNavigation = this.router.events
      .subscribe((event) => {
        if (event instanceof NavigationStart) {
          this.loading = true;
          this.cancelLoader();
        } else if (
          event instanceof NavigationEnd ||
          event instanceof NavigationCancel
        ) {
          this.cancelLoader();
          this.loading = false;
        }
      });
  }

  cancelLoader() {
    this.requestarray = 1;
    this.loaderService.cancel();
  }

  ngOnDestroy() {
    this.subRouteNavigation.unsubscribe();
  }
}
