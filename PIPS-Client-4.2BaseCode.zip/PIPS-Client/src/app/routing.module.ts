import { ModuleWithProviders } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';

import { AuthGuard } from './shared/services/auth-guard.service';

const appRoutes: Routes = [
    {
        path: '',
        redirectTo: 'customer',
        canActivate: [AuthGuard],
        pathMatch: 'full'
    },
    {
        path: '',
        redirectTo: 'insurance',
        canActivate: [AuthGuard],
        pathMatch: 'full'
    },
    {
        path: '*',
        redirectTo: 'customer',
        canActivate: [AuthGuard],
        pathMatch: 'full'
    }
];

export const RoutingModule: ModuleWithProviders = RouterModule.forRoot(appRoutes);
