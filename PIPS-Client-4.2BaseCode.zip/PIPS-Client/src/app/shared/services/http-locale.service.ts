import { HttpClient, HttpErrorResponse, HttpHeaders, HttpResponse } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { BehaviorSubject } from 'rxjs/BehaviorSubject';
import { Observable } from 'rxjs/Observable';

import { environment } from '../../../environments/environment';
import { Constants } from '../interfaces/constants';
import { LoaderService } from './loader.service';


@Injectable()
export class HttpLocaleService {
  public locale: BehaviorSubject<string> = new BehaviorSubject(Constants.Empty);
  httpError: BehaviorSubject<{ errorCode: string, errorMsg: string, errorType: string }> = new BehaviorSubject(null);

  constructor(private http: HttpClient, private loaderService: LoaderService) {
    const locale = localStorage.getItem(Constants.Locale);
    if (locale) {
      this.setLocale(locale);
    } else {
      this.setLocale(Constants.English);
    }
    this.httpError.next(null);
  }

  // Set locale in the session storage
  setLocale(locale) {
    sessionStorage.setItem(Constants.Locale, locale);
    this.locale.next(locale);
  }

  setHttpError(errorCode: string, errorMsg: string, errorType) {
    this.httpError.next({ errorCode: errorCode, errorMsg: errorMsg, errorType: errorType });
  }

  // Get the extended life time JWT token from KAS
  getNewToken(): Observable<any> {
    return this.http.get(
      environment.domainURLKong + Constants.KerberosClientAuth,
      {
        observe: 'response', withCredentials: true, responseType: 'text',
        headers: new HttpHeaders({ [Constants.ContentType]: Constants.ContentTypeJson })
      }
    ).map((resp: HttpResponse<any>) => {
      const authToken = resp.headers.get(Constants.HeaderUserId);
      sessionStorage.setItem(Constants.AuthToken, authToken);
      return authToken;
    }).catch((exception: HttpErrorResponse) => {
      this.setErrorMessage(exception);
      return Observable.throw(exception);
    });
  }

  checkTokenLifeTime() {
    const token = sessionStorage.getItem(Constants.AuthToken);
    const jwtData = token.split(Constants.Dot)[1].replace(Constants.Hypen, Constants.Plus).replace(Constants.Underscore, Constants.Slash);
    const issueDate = Date.parse(new Date(((JSON.parse(window.atob(jwtData)).iat) * 1000)).toString());
    const expireDate = Date.parse(new Date(((JSON.parse(window.atob(jwtData)).exp) * 1000)).toString());
    const currentDate = Date.parse(new Date().toString());
    const timeElapsed = ((currentDate - issueDate) / (expireDate - issueDate)) * 100;
    return (timeElapsed > environment.lifeTimeTokenThreshold);
  }

  subscribeBasedonToken(service): any {
    if (!service) { return; }
    if (this.checkTokenLifeTime()) {
      this.getNewToken()
        .subscribe(token => {
          if (token) {
            service.subscribe();
          }
        });
    } else {
      service.subscribe({});
    }
  }
  // Set the error message received from the service that need to be  dispalyed on the screen
  setErrorMessage(exception: HttpErrorResponse) {
    if (exception === null) {
      this.setHttpError(Constants.Empty, Constants.Empty, Constants.Empty);
    } else if (exception.error) {
      this.loaderService.cancel();
      if (exception.error.Value) {
        this.setHttpError(exception.error.Value.ExceptionCode, Constants.Empty, exception.error.StatusCode);
      } else if (exception.error.ExceptionCode) {
        this.setHttpError(exception.error.ExceptionCode, Constants.Empty, exception.error.StatusCode);
      } else {
        this.setHttpError(exception.status.toString(), Constants.Empty, Constants.Empty);
      }
    }
  }
}
