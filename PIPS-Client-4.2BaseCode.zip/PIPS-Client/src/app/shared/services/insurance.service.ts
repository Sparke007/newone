import 'rxjs/add/observable/throw';

import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { BehaviorSubject } from 'rxjs/BehaviorSubject';
import { Observable } from 'rxjs/Observable';

import { environment } from '../../../environments/environment';
import { Constants } from '../interfaces/constants';
import { Product, ProductTerm, Products } from '../interfaces/product.interface';
import { HttpLocaleService } from './http-locale.service';
import { LoaderService } from './loader.service';

@Injectable()
export class InsuranceService {
  public selectedProduct = new BehaviorSubject<Product>(new Product);
  public selectedProductTerm = new BehaviorSubject<ProductTerm>(new ProductTerm);
  public payBackOptions = new BehaviorSubject<object>(Object);
  public agentList = new BehaviorSubject<object>(Object);

  constructor(private http: HttpClient, private srvHttpLocale: HttpLocaleService, private loaderService: LoaderService) { }

  setSelectedProduct(selectedProduct: Product) {
    return this.selectedProduct.next(selectedProduct);
  }

  setSelectedProductTerm(selectedProductTerm: ProductTerm) {
    return this.selectedProductTerm.next(selectedProductTerm);
  }

  policyCalculate(policyCalculate: any): Observable<any> {
    const httpHeaderOptions = {
      headers: new HttpHeaders({})
    };
    this.loaderService.show();
    return this.http.post(environment.domainURLPIP + Constants.UrlPolicyCalculate, policyCalculate, httpHeaderOptions)
      .map(res => {
        this.loaderService.hide();
        return res;
      })
      .catch(exception => {
        this.srvHttpLocale.setErrorMessage(exception);
        return Observable.throw(exception);
      });
  }

  getProducts(issueDate: string): Observable<any> {
    const httpHeaderOptions = {
      headers: new HttpHeaders({})
    };
    this.loaderService.show();
    return this.http.get(environment.domainURLPIP + Constants.UrlGetProducts + issueDate , httpHeaderOptions)
      .map((res: Products) => {
        this.loaderService.hide();
        return res;
      })
      .catch(exception => {
        this.srvHttpLocale.setErrorMessage(exception);
        return Observable.throw(exception);
      });
  }

  getPayBackOptions(): Observable<any> {
    this.payBackOptions.next([
      {
        [Constants.Id]: Constants.Cash
      },
      {
        [Constants.Id]: Constants.BankTransfer
      }
    ]);
    return this.payBackOptions;
  }

  getAgent(idnumber: string, firstname: string, lastname: string): Observable<any> {
    const httpHeaderOptions = {
      headers: new HttpHeaders({})
    };
    this.loaderService.show();
    return this.http.get(environment.domainURLPIP + Constants.UrlGetAgent + idnumber
      + Constants.ForeName + firstname
      + Constants.SurName + lastname,
      httpHeaderOptions)
      .map((res: Products) => {
        this.loaderService.hide();
        this.agentList.next(res);
        return res;
      })
      .catch(exception => {
        this.agentList.next([]);
        this.srvHttpLocale.setErrorMessage(exception);
        return Observable.throw(exception);
      });
  }
}
