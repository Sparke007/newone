import 'rxjs/add/observable/throw';
import 'rxjs/add/operator/catch';
import 'rxjs/add/operator/map';

import { HttpClient, HttpHeaders } from '@angular/common/http';
import { HttpErrorResponse } from '@angular/common/http/src/response';
import { Injectable, OnDestroy } from '@angular/core';
import { BehaviorSubject } from 'rxjs/BehaviorSubject';
import { Observable } from 'rxjs/Observable';
import { ISubscription } from 'rxjs/Subscription';

import { environment } from '../../../environments/environment';
import { Constants } from '../interfaces/constants';
import { Agreement, Customer, CustomerPolicy, ErrorValue } from '../interfaces/customer.interface';
import { HttpLocaleService } from './http-locale.service';
import { LoaderService } from './loader.service';
import { UtilityService } from './utility.service';

@Injectable()
export class CustomerService implements OnDestroy {

  public nationalId = new BehaviorSubject<string>(Constants.Empty);
  public customerId = new BehaviorSubject<string>(Constants.Empty);
  public businessExceptionCode = new BehaviorSubject<ErrorValue>(new ErrorValue);

  public customerList = new BehaviorSubject<Customer[]>([]);
  public selectedCustomer = new BehaviorSubject<Customer>(new Customer);
  public selectedAgreement = new BehaviorSubject<Agreement>(new Agreement);
  public selectedPolicy = new BehaviorSubject<CustomerPolicy>(new CustomerPolicy);
  // For Agreement Search
  public agreementSelectedCustomer = new BehaviorSubject<Customer>(new Customer);
  public agreementselectedAgreement = new BehaviorSubject<Agreement>(new Agreement);

  subNationalId: ISubscription;
  subCustomerId: ISubscription;
  subCustomerByPIN: ISubscription;
  subCustomerByCID: ISubscription;
  subCustomerList: ISubscription;
  subCustomer: ISubscription;
  utilityService = new UtilityService();

  constructor(private http: HttpClient, private srvHttpLocale: HttpLocaleService, private loaderService: LoaderService) {


    this.subNationalId = this.nationalId.subscribe(nationalId => {
      if (nationalId !== Constants.Empty) {
        this.subCustomerByPIN = this.srvHttpLocale.subscribeBasedonToken(this.getCustomerByPIN(nationalId));
      } else {
        this.customerList.next([]);
      }
    });

    this.subCustomerId = this.customerId.subscribe(customerId => {
      if (customerId !== Constants.Empty) {
        const customerIdFocusFormat = this.getCustomerIdValidFormat(customerId);
        this.subCustomerByCID = this.srvHttpLocale.subscribeBasedonToken(this.getCustomerByCID(customerIdFocusFormat));

      } else {
        this.customerList.next([]);
      }
    });


    this.subCustomerList = this.customerList.subscribe(customerList => {
      const selectedCustomerId = sessionStorage.getItem(Constants.SelectedCustomer);
      if (selectedCustomerId) {
        if (customerList !== undefined && customerList.length > 0) {
          customerList.forEach((customer: Customer) => {
            if (parseInt(selectedCustomerId, 10) === customer.CustomerId) {
              this.setSelectedCustomer(customer);
            }
          });
        }
      }
    });

    this.subCustomer = this.selectedCustomer.subscribe(customer => {
      const selectedAgreementId = sessionStorage.getItem(Constants.SelectedAgreement);
      if (selectedAgreementId && customer && customer.Agreements) {
        if (customer.Agreements.length > 0) {
          customer.Agreements.forEach((agreement: Agreement) => {
            if (parseInt(selectedAgreementId, 10) === agreement.AgreementId) {
              this.setSelectedAgreement(agreement);
            }
          });
        }
      }
    });
  }
  // Set national id and remove previous customer id
  setNationalId(nationalId: string) {
    if (nationalId) { sessionStorage.setItem(Constants.NationalId, nationalId); }
    sessionStorage.removeItem(Constants.CustomerId);
    return this.nationalId.next(nationalId);
  }

  // Set customer id and remove previous national id
  setCustomerId(customerId: string) {
    if (customerId) { sessionStorage.setItem(Constants.CustomerId, customerId); }
    sessionStorage.removeItem(Constants.NationalId);
    return this.customerId.next(customerId);
  }

  // Set Busines Exception Code
  setBusinesExceptionCode(exceptionCode: ErrorValue) {
    return this.businessExceptionCode.next(exceptionCode);
  }

  // Set Selected Agreement
  setSelectedAgreement(selectedAgreement: Agreement) {
    if(Object.keys(selectedAgreement).length > 0) {
      sessionStorage.setItem(Constants.SelectedAgreement, selectedAgreement.AgreementId.toString());
    } else {
      sessionStorage.setItem(Constants.SelectedAgreement, '');
    }
    return this.selectedAgreement.next(selectedAgreement);
  }

  // Set Selected Customer
  setSelectedCustomer(selectedCustomer: Customer) {
    sessionStorage.setItem(Constants.SelectedCustomer, selectedCustomer.CustomerId.toString());
    return this.selectedCustomer.next(selectedCustomer);
  }

  // Set Selected Customer for agreement search
  agreementSetSelectedCustomer(agreementSelectedCustomer: Customer) {
    return this.agreementSelectedCustomer.next(agreementSelectedCustomer);
  }

  // Set Selected Agreement for agreement search
  agreementSetSelectedAgreement(agreementselectedAgreement: Agreement) {
    return this.agreementselectedAgreement.next(agreementselectedAgreement);
  }


  // Get Customer By Customer Id
  getCustomerByCID(customerId, showLoader = true): Observable<Customer[]> {
    const httpHeaderOptions = {
      headers: new HttpHeaders({})
    };
    if (showLoader) {
      this.loaderService.show();
    }
    return this.http.get(environment.domainURLPIP + Constants.UrlGetCustomerbyCid + customerId,
      httpHeaderOptions)
      .map((res: Customer) => {
        if (showLoader) {
          this.loaderService.hide();
        }
        const response: Customer[] = [];
        response.push(res);
        return this.checkResponse(response);
      })
      .catch((exception: HttpErrorResponse) => {
        this.catchError(exception);
        return Observable.throw(exception);
      });
  }

  private catchError(exception: HttpErrorResponse) {
    if (exception.status !== 404) {
      this.srvHttpLocale.setErrorMessage(exception);
    } else {
      this.loaderService.cancel();
      this.customerList.next([]);
    }
  }

  private checkResponse(response: Customer[]) {
    if (response && response.length !== 0) {
      return this.mapCustomerResponse(response);
    }
  }

  // Get Customer By PIN
  getCustomerByPIN(pin, agreementNumber = Constants.Empty, showLoader = true): Observable<Customer[]> {
    const httpHeaderOptions = {
      headers: new HttpHeaders({})
    };
    if (showLoader) {
      this.loaderService.show();
    }
    return this.http.get(environment.domainURLPIP + Constants.UrlGetCustomerbyPin +
      ((pin) ? Constants.Pin : Constants.AgreementNum) + ((pin) ? pin : agreementNumber),
      httpHeaderOptions)
      .map((res: Customer[]) => {
        if (showLoader) {
          this.loaderService.hide();
        }
        this.checkResponse(res);
      })
      .catch((exception: HttpErrorResponse) => {
        this.catchError(exception);
        return Observable.throw(exception);
      });
  }

  // Maps the Insurance to its Respective Agreement
  mapCustomerResponse(response) {
    response.forEach((customerInfo) => {
      this.mapAgreementAndInsurance(customerInfo);
    });
    this.customerList.next(response);

    return response;
  }

  mapAgreementAndInsurance(customerInfo) {
    let insuranceAgreementId = 0;
    if (customerInfo.Insurance) {
      customerInfo.Insurance.forEach((insuranceInfo) => {
        insuranceAgreementId = insuranceInfo.AgreementId;
        customerInfo.Agreements.forEach(agreementInfo => {
          if (agreementInfo.AgreementId === insuranceAgreementId) {
            if (agreementInfo.Insurance === undefined) {
              agreementInfo.Insurance = [];
            }
            agreementInfo.Insurance.push(insuranceInfo);
          }
        });
      });
    }
    return customerInfo;
  }
  // Create the Policy
  createPolicy(policyCreateData: any): Observable<any> {
    const httpHeaderOptions = {
      headers: new HttpHeaders({
        [Constants.ActionRequestHeader]: Constants.ActionAdd
      })
    };
    this.loaderService.show();
    return this.http.post(environment.domainURLPIP + Constants.UrlCreatePolicy, policyCreateData, httpHeaderOptions)
      .map(res => {
        this.loaderService.hide();
        return res;
      })
      .catch((exception: HttpErrorResponse) => {
        this.catchBusinessException(exception);
        return Observable.throw(exception);
      });
  }

  // Update the Policy
  updatePolicy(policyUpdateData: any, policyId: string): Observable<any> {
    const httpHeaderOptions = {
      headers: new HttpHeaders({
        [Constants.ActionRequestHeader]: Constants.ActionUpdate
      })
    };
    this.loaderService.show();
    return this.http.put(environment.domainURLPIP + Constants.UrlUpdatePolicy + policyId, policyUpdateData, httpHeaderOptions)
      .map(res => {
        this.loaderService.hide();
        return res;
      })
      .catch((exception: HttpErrorResponse) => {
        this.catchBusinessException(exception);
        return Observable.throw(exception);
      });
  }

  postPolicyStatus(policyStatus: any, policyId: string, actionHeader): Observable<any> {
    const httpHeaderOptions = {
      headers: new HttpHeaders({
        [Constants.ActionRequestHeader]: actionHeader
      })
    };
    this.loaderService.show();
    return this.http.post(environment.domainURLPIP + Constants.UrlPostPolicies + policyId + Constants.UrlPostStatus
      , policyStatus, httpHeaderOptions)
      .map(res => {
        this.loaderService.hide();
        return res;
      })
      .catch(exception => {
        this.catchBusinessException(exception);
        return Observable.throw(exception);
      });
  }

  // Check Valid Business-Exception Code
  checkValidBusinessException(code: string) {
    if (code && (code === Constants.ErrorPolicyNumberIncorrect
      || code === Constants.WarningDuplicatePolicyNumber
      || code === Constants.ErrorPolicyPendingStatus)) {
      return code;
    }
    return Constants.Empty;
  }

  // Catch Business Exception
  catchBusinessException(exception) {
    this.loaderService.cancel();
    if (exception) {
      const setException = (exception.error.Value) ? exception.error.Value : exception.error;
      if (this.checkValidBusinessException(setException.ExceptionCode)) {
        this.setBusinesExceptionCode(setException);
      } else {
        this.srvHttpLocale.setErrorMessage(exception);
      }
    }
  }

  // Get Customer Policy
  getCustomerPolicy(policyId: string): Observable<CustomerPolicy> {
    const httpHeaderOptions = {
      headers: new HttpHeaders({})
    };
    this.loaderService.show();
    return this.http.get(environment.domainURLPIP + Constants.UrlGetCustomerPolicy + policyId,
      httpHeaderOptions)
      .map((res: CustomerPolicy) => {
        this.loaderService.hide();
        return res;
      })
      .catch((exception: HttpErrorResponse) => {
        this.selectedPolicy.next(new CustomerPolicy);
        this.srvHttpLocale.setErrorMessage(exception);
        return Observable.throw(exception);
      });
  }

  // Format the customer id in the proper format
  getCustomerIdValidFormat(customerId: string) {
    if (customerId.indexOf(Constants.Hypen) !== -1) {
      const customerIdSplit = customerId.split(Constants.Hypen); // split id on the basis of hypen
      let customerIdPart1 = customerIdSplit[0]; // treat it as Dbid
      let customerIdPart2 = customerIdSplit[1]; // customer id
      if (customerIdPart1.length < Constants.DbidLength) {
        customerIdPart1 = UtilityService.pad(Constants.DbidLength, customerIdPart1, Constants.PadZero); // make dbid to 4 digit format
      }
      if (customerIdPart2.length < Constants.CustomerActualIdLength) {  // make customer id to 9 digit format
        customerIdPart2 = UtilityService.pad(Constants.CustomerActualIdLength, customerIdPart2, Constants.PadZero);
      }
      customerId = customerIdPart1 + customerIdPart2; // merge dbid & customer id
    } else {
      customerId = UtilityService.pad(Constants.CustomerIdLength, customerId, Constants.PadZero); // format id to 13 digits
    }
    return customerId;
  }


  ngOnDestroy(): void {
    if (this.subCustomerByPIN) {
      this.subCustomerByPIN.unsubscribe();
    }
    if (this.subCustomerList) {
      this.subCustomerList.unsubscribe();
    }
    if (this.subNationalId) {
      this.subNationalId.unsubscribe();
    }
    if (this.subCustomer) {
      this.subCustomer.unsubscribe();
    }
  }

}
