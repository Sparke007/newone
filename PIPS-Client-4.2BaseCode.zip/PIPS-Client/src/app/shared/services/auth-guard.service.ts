import { Injectable } from '@angular/core';
import { RouterStateSnapshot, ActivatedRouteSnapshot } from '@angular/router';
import { environment } from '../../../environments/environment';
import { Observable } from 'rxjs/Observable';
import { HttpClient, HttpErrorResponse, HttpHeaders, HttpResponse } from '@angular/common/http';
import { Location } from '@angular/common';
import { HttpLocaleService } from './http-locale.service';
import { CanActivate, CanActivateChild } from '@angular/router';

@Injectable()
export class AuthGuard implements CanActivate, CanActivateChild {

  constructor(
    private http: HttpClient,
    private location: Location,
    private srvHttpLocale: HttpLocaleService
  ) { }

  canActivate(_route: ActivatedRouteSnapshot, state: RouterStateSnapshot): Observable<boolean> | boolean {

       // sessionStorage.setItem('authToken', 'eyJhbGciOiJSUzI1NiIsImtpZCI6IjM1NENBM0Q0MkNDODQ0OUFEMDczNkRDODlFREFDMEQwQkIyNzMwM0YiLCJ0eXAiOiJKV1QifQ.eyJzdWIiOiIzOTAwMDE0OTQ2OCIsIm1hcmtldF9pZCI6IlBPTDEiLCJzY29wZXMiOlsiaW5zdXJhbmNlczpyZWFkIiwiaW5zdXJhbmNlczp3cml0ZSJdLCJuYmYiOjE2OTAyNjI3MjMsImV4cCI6MTcyMTc5ODcyMywiaWF0IjoxNjkwMjYyNzIzLCJpc3MiOiJodHRwOi8vYXV0ei5pcGZpbi5sb2NhbCIsImF1ZCI6Imh0dHA6Ly9hdXR6LmlwZmluLmxvY2FsL3Jlc291cmNlcyJ9.nd3pKTtDtYtFHgPh1umSwrkjR-WI4DQmMeuKojGdZSaWZoigk3qFmAwHzWS9kZ4nPUbRCEYvaq7WNsCE9nEymrGDf1E1H0Ur8b-yLSTBHJhMen0gqVP_ypcayzop-oDU2bZtrwWbrrpk3TDBV8kvcTJFi0Wh66NWg_9wwIIcFBp_2y_EabAywEsFo45AmJG6ZdeFtW5F7910RaFnvcfgTSMbcqHxGAUprpzhCF2cKFYffQMcdEArdKrqeCPai-OJn5N90ae4VoQ2f8fdR8P1Ppt2IpP8zacOd7iM6ZfUzSz0HpinDQ3dWwuH3-AfWX9y9WqCyoNEHjVZQGGXv-bMnw');


      //old token
       // sessionStorage.setItem('authToken', 'eyJhbGciOiJSUzI1NiIsImtpZCI6IjM1NENBM0Q0MkNDODQ0OUFEMDczNkRDODlFREFDMEQwQkIyNzMwM0YiLCJ0eXAiOiJKV1QifQ.eyJzdWIiOiIzOTAwMDE0OTQ2OCIsIm1hcmtldF9pZCI6IlBPTDEiLCJzY29wZXMiOlsiaW5zdXJhbmNlczpyZWFkIiwiaW5zdXJhbmNlczp3cml0ZSJdLCJuYmYiOjE2OTAyNjI3MjMsImV4cCI6MTcyMTc5ODcyMywiaWF0IjoxNjkwMjYyNzIzLCJpc3MiOiJodHRwOi8vYXV0ei5pcGZpbi5sb2NhbCIsImF1ZCI6Imh0dHA6Ly9hdXR6LmlwZmluLmxvY2FsL3Jlc291cmNlcyJ9.nd3pKTtDtYtFHgPh1umSwrkjR-WI4DQmMeuKojGdZSaWZoigk3qFmAwHzWS9kZ4nPUbRCEYvaq7WNsCE9nEymrGDf1E1H0Ur8b-yLSTBHJhMen0gqVP_ypcayzop-oDU2bZtrwWbrrpk3TDBV8kvcTJFi0Wh66NWg_9wwIIcFBp_2y_EabAywEsFo45AmJG6ZdeFtW5F7910RaFnvcfgTSMbcqHxGAUprpzhCF2cKFYffQMcdEArdKrqeCPai-OJn5N90ae4VoQ2f8fdR8P1Ppt2IpP8zacOd7iM6ZfUzSz0HpinDQ3dWwuH3-AfWX9y9WqCyoNEHjVZQGGXv-bMnw');

    let authToken = sessionStorage.getItem('authToken');
    if (!authToken) {
      return this.http.get(
        environment.domainURLKong + 'KerberosClientAuth',
        {
          observe: 'response', withCredentials: true, responseType: 'text',
          headers: new HttpHeaders({ 'Content-type': 'application/json' })
        }
      )
        .map((resp: HttpResponse<any>) => {
          authToken = resp.headers.get('X-User-Token');
          sessionStorage.setItem('authToken', authToken);
          return this.validateLocale(state);

        }).catch((exception: HttpErrorResponse) => {
          this.srvHttpLocale.setErrorMessage(exception);
          return Observable.throw(exception);
        });
    }  else {
      return this.validateLocale(state);
    }
  }

  canActivateChild(route: ActivatedRouteSnapshot, state: RouterStateSnapshot): Observable<boolean> | boolean {
    return this.canActivate(route, state);
  }

  validateLocale(state) {

    let currentLocale = sessionStorage.getItem('locale');

    if (currentLocale) {
      const baseHref = (this.location as any)._baseHref;
      const urlLocale = baseHref.substring(1, 3).toLowerCase();
      if (urlLocale !== currentLocale) {
        if (environment.availableLocale.indexOf(urlLocale) !== -1) {
          currentLocale = urlLocale;
          // sessionStorage.setItem('locale', currentLocale);
          this.srvHttpLocale.setLocale(currentLocale);
        } else {
          window.location.href = '/' + currentLocale + '' + state.url;
          return false;
        }
      } else {
        this.srvHttpLocale.setLocale(currentLocale);
      }
    } else {
      const langArr = navigator.language.split('-');
      if (langArr[0] !== '') {
        // sessionStorage.setItem('locale', );
        this.srvHttpLocale.setLocale(langArr[0]);
        window.location.href = '/' + langArr[0] + state.url;
      }
      return false;
    }

    return true;
  }
}
