import { Injectable } from '@angular/core';
import { BehaviorSubject } from 'rxjs/BehaviorSubject';
import { Subject } from 'rxjs/Subject';

import { LoaderState } from '../interfaces/loader';

@Injectable()

export class LoaderService {

    public isLoading = new BehaviorSubject(false);
    private loaderSubject = new Subject<LoaderState>();

    loaderState = this.loaderSubject.asObservable();


    constructor() { }

    show() {
        this.loaderSubject.next(<LoaderState>{ show: true });
    }

    hide() {
        this.loaderSubject.next(<LoaderState>{ show: false });
    }

    cancel() {
        this.loaderSubject.next(<LoaderState>{ cancel: true });
    }
}
