import { HttpEvent, HttpHandler, HttpInterceptor, HttpRequest } from '@angular/common/http';
import { Injectable, Injector } from '@angular/core';
import { Observable } from 'rxjs/Observable';
import { v4 as uuid } from 'uuid';

import { Constants } from '../interfaces/constants';
import { HttpLocaleService } from './http-locale.service';

@Injectable()
export class WinAuthInterceptor implements HttpInterceptor {
  private srvHttpLocale: HttpLocaleService;

  constructor(private injector: Injector) {
    setTimeout(() => {
      this.srvHttpLocale = this.injector.get(HttpLocaleService);
    });
  }
  intercept(req: HttpRequest<any>, next: HttpHandler): Observable<HttpEvent<any>> {

    let currentLocale = sessionStorage.getItem(Constants.Locale);
    const authToken = sessionStorage.getItem(Constants.AuthToken);

    if (this.srvHttpLocale !== undefined) {
      this.srvHttpLocale.setErrorMessage(null);
    }

    if (!currentLocale) {
      currentLocale = Constants.English;
    }

    const currentDate = new Date();
    req = req.clone({
      withCredentials: true,
      setHeaders: {
        [Constants.Timestamp]: currentDate.toISOString(),
        [Constants.CurrencyCode]: currentLocale,
        [Constants.MessageId]: uuid(),
        [Constants.HeaderLocale]: currentLocale + Constants.Hypen + currentLocale.toUpperCase()
      }
    });

    if (authToken) {
      if (!req.headers.has(Constants.ContentType)) { // To prevent token refresh again
        if (sessionStorage.getItem(Constants.AuthToken)) {
          req = req.clone({
            setHeaders: {
              [Constants.Authorization]: Constants.Bearer + sessionStorage.getItem(Constants.AuthToken)
            }
          });
        }
      }
    }
    return next.handle(req);
  }
}
