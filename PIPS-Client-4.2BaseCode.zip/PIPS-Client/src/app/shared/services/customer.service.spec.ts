import { HttpClient } from '@angular/common/http';
import { HttpClientModule } from '@angular/common/http';
import { TestBed } from '@angular/core/testing';

import {  Agreement, Customer } from '../interfaces/customer.interface';
import { CustomerService } from './customer.service';
import { CustomerMock } from '../mock/mock-data/customer.mock';
import { SelectedAgreementMock } from '../mock/mock-data/selected-agreement.mock';

describe('CustomerService', () => {
    let service: CustomerService;
    let mockCustomer: Customer;
    let mockCustomerList: Customer[];
    let mockCustomerAgreement: Agreement;

    beforeEach(() => {
        TestBed.configureTestingModule({
            imports: [HttpClientModule],
            providers: [CustomerService, HttpClient]
        });

        service = TestBed.get(CustomerService);
        mockCustomerAgreement = SelectedAgreementMock.data;
        mockCustomer = CustomerMock.data[0];
        mockCustomerList = CustomerMock.data;
    });

    describe('constructor', () => {
        it('should subscribe to fetch customerList when national ID is non empty', async() => {

        });
    });

    describe('setNationalId', () => {
        it('should call next function', async () => {
            spyOn(service.nationalId, 'next');

            service.setNationalId('123');

            expect(service.nationalId.next).toHaveBeenCalled();
        });
        it('should update NIP', async () => {

            service.setNationalId('123');

            service.nationalId.subscribe(value => {
                expect(service.nationalId.getValue()).toEqual('123');
            });
        });
    });

    describe('setSelectedCustomer', () => {
        it('should call next function', async () => {
            spyOn(service.selectedCustomer, 'next');

            service.setSelectedCustomer(mockCustomer);

            expect(service.selectedCustomer.next).toHaveBeenCalled();
        });
        it('should update selected customer ', async () => {

            service.setSelectedCustomer(mockCustomer);

            service.selectedCustomer.subscribe(value => {
                expect(service.selectedCustomer.getValue()).toEqual(mockCustomer);
            });
        });
    });

    describe('setSelectedAgreement', () => {
        it('should call next function', async () => {
            spyOn(service.selectedAgreement, 'next');

            service.setSelectedAgreement(mockCustomer.Agreements[0]);

            expect(service.selectedAgreement.next).toHaveBeenCalled();
        });
        it('should update selected agreement ', async () => {

            service.setSelectedAgreement(mockCustomer.Agreements[0]);

            service.selectedAgreement.subscribe(value => {
                expect(service.selectedAgreement.getValue()).toEqual(mockCustomerAgreement);
            });
        });
    });

    describe('getCustomerByPIN', () => {
        it('should retrive customer details', async () => {
            service.getCustomerByPIN('59022702344').subscribe(customerList => {
                expect(customerList).toEqual(mockCustomerList);
            });
        });
        it('should retrive customer details', async () => {
            service.getCustomerByPIN('1231235').subscribe(customerList => {
                expect(service.customerList.getValue()).toEqual(mockCustomerList);
            });
        });
    });
});
