import { TestBed, inject } from '@angular/core/testing';

import { InsuranceService } from './insurance.service';
import { HttpClientModule, HttpClient } from '@angular/common/http';
import { Product } from '../interfaces/product.interface';

describe('InsuranceService', () => {
  let service: InsuranceService;
  const mockProduct: Product = {
      ProductId: 3,
      Version: 1,
      MaxAllowed: 2,
      Description: 'Medical',
      MandatoryPackages: [],
      PackageGroups: [],
      PropertyValues: [],
      FilterProperties: []
  };

  beforeEach(() => {
    TestBed.configureTestingModule({
      imports: [HttpClientModule],
      providers: [InsuranceService, HttpClient]
    });
    service = TestBed.get(InsuranceService);
  });

  it('should be created', inject([InsuranceService], (services: InsuranceService) => {
    expect(services).toBeTruthy();
  }));

  describe('setSelectedProduct', () => {
    it('should call next function', async () => {
      spyOn(service.selectedProduct, 'next');
      // 3 = Medical
      service.setSelectedProduct(mockProduct);

      expect(service.selectedProduct.next).toHaveBeenCalled();
    });
    it('should update selected product ', async () => {

      service.setSelectedProduct(mockProduct);

      service.selectedProduct.subscribe(value => {
        expect(service.selectedProduct.getValue()).toEqual(mockProduct);
      });
    });
  });

  describe('getProducts', () => {
    it('should retrive product list', async () => {
      service.getProducts("").subscribe(customerList => {
        expect(customerList.length).toEqual(8);
      });
    });
  });
});
