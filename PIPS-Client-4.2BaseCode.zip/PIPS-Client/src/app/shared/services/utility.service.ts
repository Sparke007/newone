import { HttpErrorResponse } from '@angular/common/http';
import { Injectable } from '@angular/core';

import { HttpLocaleService } from './http-locale.service';
import { Constants } from '../interfaces/constants';

@Injectable()
export class UtilityService {

  constructor() { }

  static validateDate(day: number, month: number, year: number) {
    let errorMessage = Constants.Empty;
    // check data type of the input
    if (isNaN(month) || isNaN(day) || isNaN(year)) {
      return errorMessage = Constants.ErrorInputDateInvalid;
    }
    month = Number(month);
    day = Number(day);
    year = Number(year);
    if (month < 1 || month > 12) { // check month range
      return errorMessage = Constants.ErrorInputDateInvalid;
    }
    if (day < 1 || day > 31) { // check day range
      return errorMessage = Constants.ErrorInputDateInvalid;
    }
    if (year < 1900 || year > 2100) { // check year less than 1900
      return errorMessage = Constants.ErrorInputDateInvalid;
    }
    if ((month === 4 || month === 6 || month === 9 || month === 11) && day === 31) { // check for day 31
      return errorMessage = Constants.ErrorInputDateInvalid;
    }
    if (month === 2) { // check for february 29th
      const isleap = (year % 4 === 0 && (year % 100 !== 0 || year % 400 === 0));
      if (day > 29 || (day === 29 && !isleap)) {
        return errorMessage = Constants.ErrorInputDateInvalid;
      }
    }
    return errorMessage;
  }

  static validateDateRange(inputDate: Date, minDate?: Date, maxDate?: Date) {
    let errorMessage = '';
    inputDate = this.getDate(inputDate);
    minDate = this.getDate(minDate);
    maxDate = this.getDate(maxDate);

    if (minDate !== undefined && maxDate !== undefined) {
      if (minDate > inputDate || inputDate > maxDate) {
        errorMessage = Constants.ErrorDateRangeInvalid;
      }
    } else if (minDate !== undefined) {
      if (minDate > inputDate) {
        errorMessage = Constants.ErrorDateRangeInvalid;
      }
    } else if (maxDate !== undefined) {
      if (maxDate < inputDate) {
        errorMessage = Constants.ErrorDateRangeInvalid;
      }
    }
    return errorMessage;
  }

  static getDate(date: Date) {
    if (date !== undefined) {
      return new Date(date.toDateString());
    }
  }


  static padZero(inputdate, strLength: number = 2) {

    if (!isNaN(inputdate)) {
      if (inputdate && strLength !== inputdate.length) {
        return (String(Constants.PadZero).repeat(strLength) + inputdate).substr((strLength * -1), strLength);
      }
    }
    return inputdate;
  }

  static capitalizeFirst(input: string) {
    input = input.trim();
    return input.charAt(0).toUpperCase() +
      input.substr(1).toLowerCase();

  }

  static validateUserName(username: string) {
    let errorMessage;
    username = username.trim();
    // field cannot be blank
    if (username === undefined) {
      return errorMessage = Constants.ErrorInvalidUserName;
    }
    // should not contain only space
    if (username === Constants.Empty) {
      return errorMessage = Constants.ErrorInvalidUserName;
    }
    // should not contain number in first name
    /*    if (!nameSearchPattern.test(username)) {
         return errorMessage = 'INVALID_USER_NAME';
       } */
  }

  // Return Action COde based on the input action
  static actionHeader(action) {
    switch (action) {
      case (Constants.Cancel): {
        return Constants.ActionCancel;
      }
      case (Constants.Decline): {
        return Constants.ActionDecline;
      }
      case (Constants.Reinstate): {
        return Constants.ActionReinstate;
      }

    }
  }

  static compareValue(inputValue, compareValue, operator) {
    if (!compareValue) { return null; }
    inputValue = (!inputValue) ? Constants.Empty : inputValue;
    let returnStatus = false;
    switch (operator) {
      case Constants.Equal: {
        if (inputValue.toString() === compareValue.toString()) {
          returnStatus = true;
        }
        break;
      }
      case Constants.GreaterThan: {
        if (parseInt(inputValue, 10) > parseInt(compareValue, 10)) {
          returnStatus = true;
        }
        break;
      }
      case Constants.GreaterThanEqualTo: {
        if (parseInt(inputValue, 10) >= parseInt(compareValue, 10)) {
          returnStatus = true;
        }
        break;
      }
      case Constants.LessThan: {
        if (parseInt(inputValue, 10) < parseInt(compareValue, 10)) {
          returnStatus = true;
        }
        break;
      }
      case Constants.LessThanEqualTo: {
        if (parseInt(inputValue, 10) <= parseInt(compareValue, 10)) {
          returnStatus = true;
        }
        break;
      }
      case Constants.NotEqualTo: {
        if (inputValue !== compareValue) {
          returnStatus = true;
        }
        break;
      }
    }
    return returnStatus;
  }

  static decimalRoundOff(inputvalue: string) {
    if (!inputvalue) { return Constants.Empty; }
    inputvalue = inputvalue + Constants.Empty;
    const commaFlag = inputvalue.indexOf(Constants.Comma);
    let input = inputvalue;

    if (commaFlag !== -1) {
      input = input.split(Constants.Comma).join(Constants.Dot);
    }

    const inputSplit = input.split(Constants.Dot);
    if (inputSplit.length <= 2) {

      input = parseFloat(input).toFixed(2);
      if (commaFlag !== -1) {
        input = input.replace(Constants.Dot, Constants.Comma);
      }

      if (input === Constants.NotANumber) {
        input = Constants.Empty;
      }
      return input;
    } return inputvalue;
  }

  // Pad fillstring to the the input string based upon the max length
  static pad(maxLength: number, inputString: string, fillString: string): string {
    let padstring = inputString + Constants.Empty;
    while (padstring.length < maxLength) { padstring = fillString + padstring; }
    return padstring;
  }

  static isCatieAgreement(AgreementNumber) {
    let isCatieAgreement = Number(AgreementNumber) > Constants.CATIEContractRangeMin 
&& Number(AgreementNumber) < Constants.CATIEContractRangeMax ? true : false;
    return isCatieAgreement;
  }

}
