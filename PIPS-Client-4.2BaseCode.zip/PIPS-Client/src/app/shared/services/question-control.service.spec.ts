import { QuestionControlService } from './question-control.service';
import { QuestionGroup } from '../interfaces/question.interface';
import { QuestionGroupBase } from '../interfaces/question-base.interface';

describe('QuestionControlService', () => {
    let service: QuestionControlService;
    let mockQuestionGroup: QuestionGroup[];
    let mockQuestionGroupBase: QuestionGroupBase<any>[];

    beforeEach(() => {
        service = new QuestionControlService();
        // tslint:disable-next-line:max-line-length
        mockQuestionGroup = [{ 'QuestionGroupId': 9, 'Description': 'Protection-Mandatory', 'CanBeCreatedByUser': false, 'Questions':[ { 'QuestionId': 'e5a75c2b-53fa-4e90-beb1-01252a77dabd', 'Description': 'Permission to transfer data on a tangible medium', 'Format': 'Boolean', IsMandatory: true, 'ValidationRules': [] }, { 'QuestionId': 'f6643c5c-ecce-4c16-9a11-9691e21003ca', 'Description': 'Need for insurance', 'Format': 'Boolean', IsMandatory: true, 'ValidationRules': [ { 'ValidationRuleId': '123', 'QuestionFieldName': 'Value', 'Operator': '=', 'Value': 'True', 'RuleLevel': 'Warning', 'FailedMessage': 'APK Document is missing. Do you wish to continue?', 'SuccessMessage': 'Yes, The customer confirmed the need for cover' }] }, { 'QuestionId': 'f6643c5c-ecce-4c16-9a11-9691e21003ca', 'Description': 'Need for insurance', 'Format': 'Boolean', IsMandatory: true, 'ValidationRules': [ { 'ValidationRuleId': '1234', 'QuestionFieldName': 'Value', 'Operator': '=', 'Value': 'True', 'RuleLevel': 'Warning', 'FailedMessage': 'APK Document is missing. Do you wish to continue?', 'SuccessMessage': 'Yes, The customer confirmed the need for cover' }] }] },{ 'QuestionGroupId': 11, 'Description': 'Child', 'CanBeCreatedByUser': true, 'Questions':[ { 'QuestionId': 'e5a75c2b-53fa-4e90-beb1-01252a77dabd', 'Description': 'First name', 'Format': 'Text', IsMandatory: true, 'ValidationRules': [] },{ 'QuestionId': 'e5a75c2b-53fa-4e90-beb1-01252a77dabd', 'Description': 'Birth Date', 'Format': 'DateOfBirth', IsMandatory: true, 'ValidationRules': [] }] },{ 'QuestionGroupId': 11, 'Description': 'Child', 'CanBeCreatedByUser': false, 'Questions':[ { 'QuestionId': 'e5a75c2b-53fa-4e90-beb1-01252a77dabd', 'Description': 'First name', 'Format': 'Text', IsMandatory: true, 'ValidationRules': [] },{ 'QuestionId': 'e5a75c2b-53fa-4e90-beb1-01252a77dabd', 'Description': 'Birth Date', 'Format': 'DateOfBirth', IsMandatory: true, 'ValidationRules': [] }] }]  ;
    });

    it('parseQuestion', () => {
        // spyOn(service, 'parseQuestion');

        const parsedQuestions = service.parseQuestion(mockQuestionGroup, []);

        expect(parsedQuestions.length).toEqual(1);
        expect(parsedQuestions[0].Questions.length).toEqual(2);

        mockQuestionGroupBase = parsedQuestions;
        console.log(parsedQuestions);
    });
    it('toFormGroup', () => {
        // spyOn(service, 'parseQuestion');

        console.log(mockQuestionGroupBase);

        const parsedQuestions = service.toFormGroup(mockQuestionGroupBase, []);

        // expect(parsedQuestions.length).toEqual(1);
        // expect(parsedQuestions[0].Questions.length).toEqual(2);
    });

});
