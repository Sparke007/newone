import { TestBed, inject } from '@angular/core/testing';

import { HttpLocaleService } from './http-locale.service';

describe('LocaleService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [HttpLocaleService]
    });
  });

  it('should be created', inject([HttpLocaleService], (service: HttpLocaleService) => {
    expect(service).toBeTruthy();
  }));
});
