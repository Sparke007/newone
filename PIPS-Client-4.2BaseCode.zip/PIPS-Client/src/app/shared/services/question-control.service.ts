import { Injectable, OnDestroy } from '@angular/core';
import { FormArray, Validators } from '@angular/forms';
import * as _ from 'lodash';
import { BehaviorSubject } from 'rxjs/BehaviorSubject';
import { ISubscription } from 'rxjs/Subscription';
import { v4 as uuid } from 'uuid';

import { CheckboxQuestion } from '../components/dynamic-fields/question-checkbox';
import { DateOfBirthQuestion } from '../components/dynamic-fields/question-date-of-birth';
import { TextboxQuestion } from '../components/dynamic-fields/question-textbox';
import { Constants } from '../interfaces/constants';
import { QuestionBase, QuestionGroupBase } from '../interfaces/question-base.interface';
import {
  Answer,
  QuestionAnswerGroup,
  QuestionFormControl,
  QuestionFormGroup,
  QuestionGroup,
} from '../interfaces/question.interface';
import { Packages } from '../interfaces/product.interface';

@Injectable()
export class QuestionControlService implements OnDestroy {
  public deletedChild = new BehaviorSubject<any[]>([]);
  public deletedChildList = new BehaviorSubject([]);
  subDeletedChild: ISubscription;
  validationDate: Date = new Date();
  constructor() {
    this.subDeletedChild = this.deletedChild.subscribe(childDelete => {
      if (childDelete) {
        const prevChild = this.deletedChildList.getValue();
        if (prevChild !== []) {
          childDelete = prevChild.concat([childDelete]);
        }
        this.deletedChildList.next(childDelete);
      } else { this.deletedChildList.next([]); }
    });
  }

  toFormQuestion(question: QuestionBase<any>) {

    const control = new QuestionFormControl(question.value);

    const validators = [];
    if (question.required) {
      validators.push(Validators.required);
      control.ErrorValidations.push(Constants.Required);
      control.IsMandatory = true;
    } else {
      control.IsMandatory = false;
    }

    if (question.controlType === Constants.DateofBirth) {
      if (question.validationRules.length > 0) {
        question.validationRules.forEach(rule => {
          let validationFunction = Constants.Empty;
          switch (rule.QuestionFieldName.toLowerCase()) {
            case Constants.Age: {
              validators.push(DateOfBirthQuestion.ageValidation(rule, this.validationDate));
              validationFunction = Constants.AgeValidation;
            }
              break;
          }

          if (rule.RuleLevel === Constants.Warning) {
            control.WarningValidations.push(validationFunction);
          } else {
            control.ErrorValidations.push(validationFunction);
          }
        });
        control.ErrorValidations.push(Constants.InvalidDate);
      }
    } else if (question.controlType === Constants.Checkbox) {
      if (question.validationRules.length > 0) {
        question.validationRules.forEach(rule => {
          let validationFunction = Constants.Empty;
          switch (rule.QuestionFieldName.toLowerCase()) {
            case Constants.Value: {
              validators.push(CheckboxQuestion.compareValue(rule));
              validationFunction = Constants.CompareValue;
            }
              break;
          }

          if (rule.RuleLevel === Constants.Warning) {
            control.WarningValidations.push(validationFunction);
          } else {
            control.ErrorValidations.push(validationFunction);
          }
        });
      }
    }
    control.setValidators(validators);
    return control;
  }

  setDeletedChildGroup(deletedChild) {
    return this.deletedChild.next(deletedChild);
  }


  toFormGroupQuestion(questions: QuestionBase<any>[], parsedAnswerGroup: any[]): QuestionFormGroup {
    const group: any = {};
    let questionAnsGroupId = Constants.Empty;
    questions.forEach(question => {
      question = _.cloneDeep(question);
      if (parsedAnswerGroup[question.key]) {
        if (question.controlType === Constants.Checkbox) {
          parsedAnswerGroup[question.key].Answer = (parsedAnswerGroup[question.key].Answer === Constants.True);
        }
        question.value = parsedAnswerGroup[question.key].Answer;
        questionAnsGroupId = parsedAnswerGroup[question.key].QuestionAnswerGroupId;
      } else {
        if (question.controlType === Constants.Checkbox) {
          question.value = false;
        }
      }
      group[question.key] = this.toFormQuestion(question);
    });
    const returnGroup = new QuestionFormGroup(_.cloneDeep(group));
    returnGroup.QuestionAnswerGroupId = questionAnsGroupId;
    return returnGroup;
  }

  toFormGroupQuestionArray(questionGroup: QuestionGroupBase<any>, parsedAnswerGroup: any[]) {
    if (questionGroup.MinItems > 0) {
      let index = 0;
      const controlGroupArr = [];
      while (index < questionGroup.MinItems) {
        let parsedAnswers = [];
        if (parsedAnswerGroup[index]) {
          parsedAnswers = parsedAnswerGroup[index];
        }
        let controlGroup = this.toFormGroupQuestion(questionGroup.Questions, parsedAnswers);
        controlGroup = _.cloneDeep(controlGroup);

        controlGroupArr.push(controlGroup);
        index++;
      }
      return new FormArray(controlGroupArr);
    } else {
      return false;
    }

  }

  toFormGroup(questionGroupBase: QuestionGroupBase<any>[], parsedAnswers: any[]) {
    const qGroup: any = {};

    questionGroupBase.forEach(questionGroup => {
      let returnedGrp;
      let parsedAnswerGroup = [];
      if (parsedAnswers[questionGroup.QuestionGroupId]) {
        parsedAnswerGroup = parsedAnswers[questionGroup.QuestionGroupId];
      }
      if (questionGroup.CanBeCreatedByUser) {
        returnedGrp = this.toFormGroupQuestionArray(questionGroup, parsedAnswerGroup);
      } else {
        if (parsedAnswerGroup.length === 1) {
          parsedAnswerGroup = parsedAnswerGroup[0];
        }
        returnedGrp = this.toFormGroupQuestion(questionGroup.Questions, parsedAnswerGroup);
      }
      qGroup[questionGroup.QuestionGroupId + Constants.Empty] = returnedGrp;

    });
    return new QuestionFormGroup(qGroup);
  }

  parseQuestion(packagesForDescription : Packages[],questionGroup: QuestionGroup[], parsedAnswers: any[]): QuestionGroupBase<any>[] {
    // tslint:disable-next-line:prefer-const
    let parsedQuestions: QuestionGroupBase<any>[] = [];

    if (questionGroup.length > 0) {
      questionGroup.forEach((questionGrp, questionGrpIndex) => {

        // tslint:disable-next-line:prefer-const
        let questionGroupBase = new QuestionGroupBase();
        questionGroupBase.QuestionGroupIndex = questionGrpIndex;
        questionGroupBase.Description = questionGrp.Description;
        questionGroupBase.QuestionGroupId = questionGrp.QuestionGroupId;
        questionGroupBase.CanBeCreatedByUser = questionGrp.CanBeCreatedByUser;
        questionGroupBase.DisplayOrder = questionGrpIndex;
        questionGroupBase.PackageId=questionGrp.PackageId;
        questionGroupBase.Packages = packagesForDescription.find(x=>x.PackageId==questionGrp.PackageId);
        questionGroupBase.DisplayPackageDescription=packagesForDescription.find(x=>x.PackageId==questionGrp.PackageId).IsMandatory ? false
        : parsedQuestions.some(x=>x.PackageId==questionGrp.PackageId) ? false : true;

        if (!parsedAnswers[questionGrp.QuestionGroupId]) {
          if (questionGrp.CanBeCreatedByUser) {
            questionGroupBase.MinItems = Constants.MinimumChildren;
            questionGroupBase.MaxItems = Constants.MaximumChildren;
          } else {
            questionGroupBase.MinItems = Constants.ChildCount;
            questionGroupBase.MaxItems = Constants.ChildCount;
          }
        } else {
          questionGroupBase.MinItems = parsedAnswers[questionGrp.QuestionGroupId].length;
          questionGroupBase.MaxItems = Constants.MaximumChildren;
        }

        questionGroupBase.Questions = [];
        questionGroupBase.ChildGroups = [];
        questionGrp.Questions.forEach((question, questionIndex) => {

          // tslint:disable-next-line:prefer-const
          let questionBase: QuestionBase<any>;

          switch (question.Format.toLowerCase()) {
            case Constants.Boolean: {
              questionBase = new CheckboxQuestion({
                key: question.QuestionId,
                label: question.Description,
                type: Constants.Checkbox,
                required: <boolean>question.IsMandatory,
              });

              break;
            }
            case Constants.DateofBirth: {
              questionBase = new DateOfBirthQuestion({
                key: question.QuestionId,
                label: question.Description,
                type: Constants.Text,
                required: <boolean>question.IsMandatory,
                value: Constants.Empty
              });

              break;
            }
            case Constants.Number:
            case Constants.Text:
            case Constants.Textbox: {
              questionBase = new TextboxQuestion({
                key: question.QuestionId,
                label: question.Description,
                type: Constants.Textbox,
                required: <boolean>question.IsMandatory,
                value: Constants.Empty
              });
              break;
            }
            default: {
              // statements;
              break;
            }
          }

          questionBase.validationRules = <Array<any>>question.ValidationRules;

          questionGroupBase.Questions.push(questionBase);
        });

        if (questionGrp.ChildGroups) {
          const childQGroup = this.parseQuestion(packagesForDescription,questionGrp.ChildGroups, parsedAnswers);
          childQGroup.forEach(qGrp => {
            qGrp.Questions.forEach(element => {
              questionGroupBase.Questions.push(element);
            });
          });
        }
        parsedQuestions[questionGroupBase.QuestionGroupId] = (questionGroupBase);
      });

      parsedQuestions.sort((a, b) => {
        return a.DisplayOrder - b.DisplayOrder;
      });
    }
    return parsedQuestions;
  }

  touchElements(frmGroup: QuestionFormGroup, mandatoryFieldValidity = true) {

    Object.keys(frmGroup.controls).forEach(field => {
      const control = frmGroup.get(field);
      if (control instanceof QuestionFormControl) {
        control.markAsTouched({});

        if (control.errors) {
          Object.keys(control.errors).forEach(error => {
            const isError = (control.ErrorValidations.indexOf(error) !== -1) ? true : false;
            if (mandatoryFieldValidity && isError && !control.valid) {
              mandatoryFieldValidity = false;
            }
          });
        }

      } else if (control instanceof QuestionFormGroup) {
        mandatoryFieldValidity = this.touchElements(control, mandatoryFieldValidity);
      } else if (control instanceof FormArray) {
        Object.keys(control.controls).forEach(arrField => {
          const arrControl = control.get(arrField);
          mandatoryFieldValidity = this.touchElements(<QuestionFormGroup>control.get(arrField), mandatoryFieldValidity);
        });
      }
    });

    return mandatoryFieldValidity;
  }

  convertAnswersArray(questionAnswerGroup: QuestionAnswerGroup[]) {
    const questionGroupArray = [];
    if (questionAnswerGroup !== undefined && questionAnswerGroup.length > 0) {
      questionAnswerGroup.forEach(questionGroup => {

        if (!questionGroupArray[questionGroup.QuestionGroupId]) {
          questionGroupArray[questionGroup.QuestionGroupId] = [];
        }
        const answerArray = [];
        questionGroup.Answers.forEach(answer => {
          answer.QuestionAnswerGroupId = questionGroup.QuestionAnswerGroupId;
          answerArray[answer.QuestionId] = answer;
        });

        questionGroupArray[questionGroup.QuestionGroupId].push(answerArray);
      });
    }
    return questionGroupArray;
  }

  generateResponse(frmEditInsurance: QuestionFormGroup, forceSubmit: boolean = false): any[] {
    let result = [];

    if (frmEditInsurance.valid || forceSubmit) {
      Object.keys(frmEditInsurance.controls).forEach(field => {
        const control = frmEditInsurance.get(field);
        if (control instanceof QuestionFormControl) {
          if (field !== Constants.PolicyNumber) {
            const respAnswer = new Answer;
            respAnswer.Answer = control.value;
            respAnswer.QuestionId = field;
            result.push(respAnswer);
          }
        } else if (control instanceof QuestionFormGroup) {
          const respGroup = new QuestionAnswerGroup;
          respGroup.QuestionGroupId = parseInt(field, 10);
          respGroup.Answers = this.generateResponse(control, forceSubmit);
          respGroup.QuestionAnswerGroupId = control[Constants.QuestionAnswerGroupId] ? control[Constants.QuestionAnswerGroupId] : uuid();
          result.push(respGroup);
        } else if (control instanceof FormArray) {
          const respArr = [];
          Object.keys(control.controls).forEach(arrField => {
            const arrControl = control.get(arrField);
            const respGroup = new QuestionAnswerGroup;
            respGroup.QuestionGroupId = parseInt(field, 10);
            respGroup.Answers = this.generateResponse(<QuestionFormGroup>arrControl, forceSubmit);
            respGroup.QuestionAnswerGroupId = arrControl[Constants.QuestionAnswerGroupId] ?
              arrControl[Constants.QuestionAnswerGroupId] : uuid();
            respGroup.Deleted = false;
            respArr.push(respGroup);
          });
          result = respArr;
        }
      });
    }
    return result;
  }

  ngOnDestroy(): void {
    if (this.subDeletedChild) {
      this.subDeletedChild.unsubscribe();
    }
  }
}


