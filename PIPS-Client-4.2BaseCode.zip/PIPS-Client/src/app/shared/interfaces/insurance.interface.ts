
export class Insurance {
    PolicyId: string;
    PolicyNumber: string;
    AgreementId: number;
    StartDate: string;
    EndDate: string;
    ProductDescription: string;
    Period: number;
    Premium: number;
    Status: string;
    AllowedActions: string[];
    SelectedProduct: SelectedProduct;
    CurrentProcessing: string;
}

export class SelectedProduct {
    ProductId: number;
    Version: number;
}
