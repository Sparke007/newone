import { FormGroup, FormControl } from '@angular/forms';
import { Packages } from './product.interface';

export class QuestionFormGroup extends FormGroup {
    public QuestionAnswerGroupId: string;
    public FormType: string;
}
export class QuestionFormControl extends FormControl {
    public IsMandatory: boolean;
    public WarningValidations: string[] = [];
    public ErrorValidations: string[] = [];
}
export class ValidationRule {
    ValidationRuleId: string;
    QuestionFieldName: string;
    Operator: string;
    Value: string;
    RuleLevel: string;
    FailedMessage: string;
    SuccessMessage: string;
}

export class QuestionGroups {
    QuestionGroups: QuestionGroup[];
}

export class Question {
    QuestionId: string;
    Description: string;
    Format: string;
    IsMandatory: boolean;
    ValidationRules: ValidationRule[];
}

export class Answer {
    QuestionAnswerGroupId?: string;
    Question?: Question;
    QuestionId: string;
    Answer: string;
}

export class QuestionGroup {
    PackageId:number;
    Packages:Packages
    QuestionGroupId: number;
    Description: string;
    CanBeCreatedByUser: boolean;
    DisplayOrder: number;
    ChildGroups?: QuestionGroup[];
    Questions: Question[];
}

export class QuestionAnswerGroup {
    QuestionAnswerGroupId: string;
    QuestionGroupId: number;
    Deleted: boolean;
    Answers: Answer[];
}
