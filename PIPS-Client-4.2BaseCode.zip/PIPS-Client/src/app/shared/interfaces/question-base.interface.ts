import { ValidationRule } from './question.interface';
import { Packages } from './product.interface';


export class QuestionGroupBase<T> {
  DisplayPackageDescription:boolean=true;
  PackageId:number;
  Packages:Packages;
  QuestionGroupId: number;
  QuestionGroupIndex?: number;
  QuestionAnswerGroupId: string;
  MaxItems?: number;
  MinItems?: number;
  Description: string;
  DisplayOrder: number;
  CanBeCreatedByUser: boolean;
  ChildGroups: QuestionGroupBase<T>[];
  Questions: QuestionBase<T>[];
}

export class QuestionBase<T> {
  value: T;
  key: string;
  label: string;
  required: boolean;
  order: number;
  controlType: string;
  validationRules: ValidationRule[];
  inlineMessage: string;
  isValid: boolean;
  dateOptions: {day: string, month: string, year: string};

  constructor(options: {
    value?: T,
    key?: string,
    label?: string,
    required?: boolean,
    order?: number,
    controlType?: string
  } = {}) {
    this.value = options.value;
    this.key = options.key || '';
    this.label = options.label || '';
    this.required = !!options.required;
    this.order = options.order === undefined ? 1 : options.order;
    this.controlType = options.controlType || '';
    this.isValid = true;
    this.dateOptions = {day: '', month: '', year: ''};
  }

  validate() {
    const errorMessage: string[] = [];
    if (this.controlType === 'checkbox') {
      if (this.validationRules.length) {
        this.validationRules.forEach(rule => {
          switch (rule.Operator.toLowerCase()) {
            case '=': {
                if (this.value.toString() !== rule.Value.toLowerCase()) {
                  if (rule.FailedMessage !== '') {
                    errorMessage.push(rule.FailedMessage);
                  }
                } else {
                  if (rule.SuccessMessage !== '') {
                    errorMessage.push(rule.SuccessMessage);
                  }
                }
              break;
            }
          }
        });
      }
    }
    return errorMessage;
  }
}
