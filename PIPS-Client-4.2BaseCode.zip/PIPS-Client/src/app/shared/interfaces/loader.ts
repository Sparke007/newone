export interface LoaderState {
    show: boolean;
    cancel: boolean;
}
