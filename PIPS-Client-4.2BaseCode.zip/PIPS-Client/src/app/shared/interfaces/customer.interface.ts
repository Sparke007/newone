import { Insurance } from './insurance.interface';
import { QuestionAnswerGroup, QuestionGroup } from './question.interface';
import { Packages, ProductReturn } from './product.interface';
import { PackagesGroupDetail } from './product.interface';

export class ContactDetails {
    ShortAddress: string;
    EmailAddress: string;
    Telephone: Telephone[];
}

export class Telephone {
    PhoneNumber: string;
    PhoneNumberType: string;
}

export class Agreement {
    AgreementNumber: string;
    AgreementId: number;
    AgreementStatus: string;
    IssueDate: string;
    Term?: number;
    IssueValue: number;
    DistributionTypeDescription: string;
    CollectionMethodTypeDescription: string;
    IssuerId: number;
    ProductTermType: string;
    Insurance?: Insurance[];
    FirstPaymentDueDate: string;
    EndDate: string;
    ExtendedStatus: string;
    ProductDescription: string;
    IsCancellationProduct: Boolean;
}

export class CustomerLoan {
    AgreementNumber: string;
    AgreementId: number;
    AgreementStatus: string;
    IssueDate: string;    
    IssueValue: number;   
    IssuerId: number;
    EndDate: string;    
    ProductDescription: string;    
    MappedAgreementStatus : string;
}

export class Search {
    Pin: string;
    CustomerId: string;
}

export class Customer {

    Pin: string;
    CustomerId: number;
    DisplayName: string;
    CustomerStatusCode?: string;
    BirthDate: string;
    ContactDetails: ContactDetails;
    Agreements: Agreement[];
    Insurance: Insurance[];
    constructor() { }
}

export class CustomerList {
    CustomerList: Customer[];
}

export class ProductLink {
    ProductId: number;
    Version: number;
}

export class CustomerPolicy {
    PolicyId: string;
    DistributionTypeDescription: string;
    PolicyNumber: string;
    AgreementId: number;
    ProductDescription: string;
    IssuingRepresentativeId: number;
    Premium: number;
    StartDate: string;
    EndDate: string;
    Term: number;
    ProductTermType: string;
    Status: string;
    ProductLink: ProductLink;
    PackageDetails: Packages[];
    PolicyDetailsGroup : PackagesGroupDetail[];
    PremiumReturn: ProductReturn;
    QuestionGroups: QuestionGroup[];
    QuestionAnswersGroups: QuestionAnswerGroup[];
    Description?: string;
}

export class ErrorValue {
    ExceptionCode: string;
    Message: string;
}
