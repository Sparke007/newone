import { QuestionAnswerGroup } from './question.interface';
import { Agreement } from './customer.interface';

export class MandatoryPackages {
    PackageId: number;
    Version: number;
    Description?: string;
    IsMandatory:boolean;
}

export class Packages {
    PackageId: number;
    Version: number;
    Description?: string;
    IsMandatory:boolean;
}

export class PackagesGroupDetail{
    Packages: PackagesDetail[];
}

export class PackagesDetail {
    PackageId: number;
    Amount: number;
    Description?: string;
    IsMandatory: boolean;
}

export class PackageGroups {
    Packages: Packages[];
}

export class PropertyValues {
    PropertyCode: string;
    PropertyValueCode: string;
}

export class Values {
    Code: string;
    Description: string;
}

export class FilterProperties {
    Code: string;
    Description: string;
    Values: Values[];
}

export class Product {
    ProductId: number;
    Version: number;
    Description: string;
    MaxAllowed: number;
    MaxAge: number;
    MinAge: number;
    PolicyNumBasicValidationRule: string;
    PolicyNumCheckDigitAlgorithm: string;
    ProductTerms: ProductTerm[];
    MandatoryPackages: MandatoryPackages[];
    PackageGroups: PackageGroups[];
    PropertyValues: PropertyValues[];
    FilterProperties: FilterProperties[];
}

export class Products {
    Products: Product[];
}


export class ProductTerm {
  ProductTermType: string;
  Term: number;
  IsActive: boolean;
}



export class ProductUpdate {
    CustomerId: number;
    CustomerDOB?: string;
    PolicyNumber: string;
    StartDate: string;
    SkipPolicyNumberValidation: Boolean;
    AgreementId?: number;
    Agreement: Agreement;
    PreviousAgreement: Agreement;
    SelectedProduct: {
        ProductId: number;
        Version: number;
    };
    SelectedPackages?: Packages[];
    QuestionAnswers?: QuestionAnswerGroup[];
    PremiumReturn?: ProductReturn;
    BusinessRulesExceptions?: any[];
}

export class ProductReturn {
    PremiumReturnId: string;
    PremiumReturnDate: string;
    PremiumReturnType: string;
    Amount: number;
    Status: string;
    Representative: {
        RepresentativeId: number;
        RepresentativeName: string;
    };
}

export class PolicyStatus {
    CustomerId: number;
    StatusCode: string;
    PremiumReturn: ProductReturn;
}
