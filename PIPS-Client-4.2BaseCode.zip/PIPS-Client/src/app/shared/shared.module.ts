import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { RouterModule } from '@angular/router';

import { CustomerDetailsComponent } from '../customer/customer-details/customer-details.component';
import { DFQuestionGroupComponent } from './components/dynamic-fields/df-question-group.component';
import { DFQuestionComponent } from './components/dynamic-fields/df-question.component';
import { FooterComponent } from './components/footer/footer.component';
import { HeaderComponent } from './components/header/header.component';
import { CapitalizeFirstDirective } from './directives/capitalize-first.directive';
import { DecimalFormatterDirective } from './directives/decimal-formatter.directive';
import { InputRestricterDirective } from './directives/input-restricter.directive';
import { StrPadDirective } from './directives/str-pad.directive';
import { UppercaseDirective } from './directives/uppercase.directive';


@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    ReactiveFormsModule
  ],
  declarations: [
    HeaderComponent,
    FooterComponent,
    UppercaseDirective,
    CustomerDetailsComponent,
    DFQuestionComponent,
    DFQuestionGroupComponent,
    UppercaseDirective,
    StrPadDirective,
    CapitalizeFirstDirective,
    InputRestricterDirective,
    DecimalFormatterDirective,
  ],
  exports: [
    CommonModule,
    FormsModule,
    ReactiveFormsModule,
    RouterModule,
    UppercaseDirective,
    StrPadDirective,
    CapitalizeFirstDirective,
    InputRestricterDirective,
    DecimalFormatterDirective,
    HeaderComponent,
    FooterComponent,
    CustomerDetailsComponent,
    DFQuestionComponent,
    DFQuestionGroupComponent
  ]
})
export class SharedModule { }
