import { CapitalizeFirstDirective } from './capitalize-first.directive';

describe('CapitalizeFirstDirective', () => {
 /*  it('should create an instance', () => {
    const directive = new CapitalizeFirstDirective();
    expect(directive).toBeTruthy();
  }); */
});
