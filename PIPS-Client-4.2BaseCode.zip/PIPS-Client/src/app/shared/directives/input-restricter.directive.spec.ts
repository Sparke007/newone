import { InputRestricterDirective } from './input-restricter.directive';

describe('InputRestricterDirective', () => {
 /*  it('should create an instance', () => {
    const directive = new InputRestricterDirective();
    expect(directive).toBeTruthy();
  }); */
});
