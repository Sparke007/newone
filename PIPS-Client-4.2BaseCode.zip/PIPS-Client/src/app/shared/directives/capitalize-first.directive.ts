import { Directive, ElementRef, HostListener } from '@angular/core';
import { UtilityService } from '../services/utility.service';
import { NgControl } from '@angular/forms';

@Directive({
  selector: '[appCapitalizeFirst]'
})
export class CapitalizeFirstDirective {

  constructor(private el: ElementRef, private control: NgControl) { }

  @HostListener('blur') onBlur() {
    // this.el.nativeElement.value = UtilityService.capitalizeFirst(this.el.nativeElement.value);
    this.control.control.setValue(UtilityService.capitalizeFirst(this.control.value));
  }
}
