import { StrPadDirective } from './str-pad.directive';

describe('StrPadDirective', () => {
 /*  it('should create an instance', () => {
    const directive = new StrPadDirective();
    expect(directive).toBeTruthy();
  }); */
});
