import { Directive, ElementRef, HostListener, Input } from '@angular/core';
import { UtilityService } from '../services/utility.service';
import { NgControl } from '@angular/forms';

@Directive({
  selector: '[appStrPad]'
})
export class StrPadDirective {

  // tslint:disable-next-line:no-input-rename
  @Input('appStrPad') isYear: boolean;

  constructor(private el: ElementRef, private control: NgControl) { }

  @HostListener('blur') onBlur() {
    // const input = this.el.nativeElement.value;
    // this.el.nativeElement.value =  UtilityService.padZero(input);
    this.control.control.setValue(UtilityService.padZero(this.control.value));
  }

}
