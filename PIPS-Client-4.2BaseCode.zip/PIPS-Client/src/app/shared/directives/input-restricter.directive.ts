import { Directive, ElementRef, HostListener, Input, Renderer } from '@angular/core';

import { Constants } from '../interfaces/constants';

@Directive({
  selector: '[appInputRestricter]'
})
export class InputRestricterDirective {

  // tslint:disable-next-line:no-input-rename
  @Input('appInputRestricter') selector: string;


  constructor(private renderer: Renderer, private el: ElementRef) { }

  @HostListener('keypress', ['$event']) onKeyPress(event) {
    const e = <KeyboardEvent>event;
    switch (this.selector) {
      case 'number': // allow only number
        if (!new RegExp(Constants.NumberRegEx).test(String.fromCharCode(event.charCode))) {
          e.preventDefault();
        }
        break;
      case 'amount': // allow number and dot ( '.' ) and comma ( ',' )
        if (!new RegExp(Constants.AmountRegEx).test(String.fromCharCode(event.charCode))) {
          e.preventDefault();
        }
        break;
      case 'customerId': // allow number and hyphen ( '-' )
        const enteredText = event.currentTarget.value;
        if (String.fromCharCode(event.charCode) === Constants.Hypen) {
          if (enteredText.indexOf(Constants.Hypen) > -1 || enteredText.length === 0) {
            e.preventDefault();
            return;
          }
        }
        if (!new RegExp(Constants.CustomerIdRegEx).test(String.fromCharCode(event.charCode))) {
          e.preventDefault();
        }
        break;
      /*
            case 'string': // allow alphabet along with hyphen ( '-' ) ,dot ( '.' ) and space
              if (!/^[A-Za-z-.\s]*$/.test(String.fromCharCode(event.charCode))) {
                e.preventDefault();
              }
              break; */

      default:
        this.el.nativeElement.value = this.el.nativeElement.value;
        break;
    }

  }
}

