import { UppercaseDirective } from './uppercase.directive';

describe('UppercaseDirective', () => {
  xit('should create an instance', () => {
    // const directive = new UppercaseDirective();
    // expect(directive).toBeTruthy();
  });
});
