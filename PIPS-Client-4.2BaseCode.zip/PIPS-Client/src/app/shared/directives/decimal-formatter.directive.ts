import { Directive, ElementRef, HostListener } from '@angular/core';
import { NgControl } from '@angular/forms';

import { UtilityService } from '../services/utility.service';

@Directive({
  selector: '[appDecimalFormatter]'
})
export class DecimalFormatterDirective {

  constructor(private el: ElementRef, private control: NgControl) { }

  @HostListener('blur') onBlur() {

    if (this.control.value) {
      this.control.control.setValue(UtilityService.decimalRoundOff(this.control.value));
    }
  }
}
