import { Directive, ElementRef, HostListener } from '@angular/core';
import { NgControl } from '@angular/forms';

@Directive({
  selector: '[appUppercase]'
})
export class UppercaseDirective {

  constructor(private el: ElementRef, private control: NgControl) { }

  @HostListener('keyup') onKeyUp() {
    // this.el.nativeElement.value = this.el.nativeElement.value.toUpperCase();
    this.control.control.setValue(this.control.value.toUpperCase());
  }

}
