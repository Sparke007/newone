import { DecimalFormatterDirective } from './decimal-formatter.directive';

describe('DecimalFormatterDirective', () => {
  it('should create an instance', () => {
    const directive = new DecimalFormatterDirective();
    expect(directive).toBeTruthy();
  });
});
