import { Injectable, OnDestroy } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { v4 as uuid } from 'uuid';

import { BehaviorSubject } from 'rxjs/BehaviorSubject';
import { Observable } from 'rxjs/Observable';
import { ISubscription } from 'rxjs/Subscription';
import 'rxjs/add/operator/catch';
import 'rxjs/add/operator/map';
import 'rxjs/add/observable/throw';

import { Agreement, Customer, CustomerPolicy } from '../../interfaces/customer.interface';
import { CustomerMock } from '../mock-data/customer.mock';
import { CustomerPolicyMock } from '../mock-data/customer-policy.mock';


@Injectable()
export class CustomerServiceMock  {

  public nationalId = new BehaviorSubject<string>('');
  public customerList = new BehaviorSubject<Customer[]>([]);
  public selectedCustomer = new BehaviorSubject<Customer>(new Customer);
  public selectedAgreement = new BehaviorSubject<Agreement>(new Agreement);
  public selectedPolicy = new BehaviorSubject<CustomerPolicy>(new CustomerPolicy);

  subNationalId: ISubscription;
  subCustomerByPIN: ISubscription;
  subCustomerList: ISubscription;

  constructor(private http: HttpClient) {
    this.subNationalId = this.nationalId.subscribe(nationalId => {
      if (nationalId !== '') {
        this.subCustomerByPIN = this.getCustomerByPIN(nationalId).subscribe(customerList => {
          // console.log(customerList);
          // this.customerList.next(customerList);
        });
      } else {
        this.customerList.next([]);
      }
    });

    this.subCustomerList = this.customerList.subscribe(customerList => {
      const selectedCustomer = this.selectedCustomer.getValue();
      if (selectedCustomer !== undefined && (selectedCustomer.CustomerId) && customerList.length > 0) {
        customerList.forEach((customer: Customer) => {
          if (selectedCustomer.CustomerId === customer.CustomerId) {
            this.setSelectedCustomer(customer);
          }
        });
      }
    });
  }

  setNationalId(nationalId: string) {
    return this.nationalId.next(nationalId);
  }

  setSelectedAgreement(selectedAgreement: Agreement) {
    return this.selectedAgreement.next(selectedAgreement);
  }

  setSelectedCustomer(selectedCustomer: Customer) {
    return this.selectedCustomer.next(selectedCustomer);
  }

  getCustomerByPIN(pin): Observable<Customer[]> {
    //  return this.http.get(environment.domainURLPIP + 'Customer/' + '59022702344' , // '30041015534'
     return Observable.of(CustomerMock.data)
      .map((res: Customer[]) => {
        if (res.length !== 0) {
          let insuranceAgreementId = 0;
          res.forEach((customerInfo, customerIndex) => {
            customerInfo.Insurance.forEach((insuranceInfo, insuranceIndex) => {
              insuranceAgreementId = insuranceInfo.AgreementId;

              customerInfo.Agreements.forEach(agreementInfo => {
                if (agreementInfo.AgreementId === insuranceAgreementId) {
                  if (agreementInfo.Insurance === undefined) {
                    agreementInfo.Insurance = [];
                  }
                  agreementInfo.Insurance.push(insuranceInfo);
                }
              });
            });
          });

          this.customerList.next(res);
          return res;
        } else {
          throw new Error('Customer Not found');
        }
      })
      .catch(error => {
        this.customerList.next([]);
        return Observable.throw(error);
      });
  }

  createPolicy(policyCreateData: any): Observable<any> {
    return Observable.of(CustomerMock.data)
      .map(res => {
        return res;
      });
  }

  updatePolicy(policyUpdateData: any, policyId: string): Observable<any> {
    return Observable.of(CustomerMock.data)
      .map(res => {
        return res;
      });
  }

  getCustomerPolicy(policyId: string): Observable<CustomerPolicy> {
    return Observable.of(CustomerPolicyMock.data)
      .map((res: CustomerPolicy) => {
        return res;
      })
      .catch(error => {
        this.selectedPolicy.next(new CustomerPolicy);
        return Observable.throw(error);
      });
  }
}
