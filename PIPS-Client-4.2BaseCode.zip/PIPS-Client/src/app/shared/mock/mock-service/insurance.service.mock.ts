import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { BehaviorSubject } from 'rxjs/BehaviorSubject';
import { Observable } from 'rxjs/Observable';
import 'rxjs/add/observable/throw';
import 'rxjs/add/observable/of';

import { Product, Products, PolicyStatus } from '../../interfaces/product.interface';
import { SelectedProductMock } from '../mock-data/selected-product.mock';
import { InsuranceService } from '../../services/insurance.service';
import { PolicyDetailsMock } from '../mock-data/policy-details.mock';


@Injectable()
export class InsuranceServiceMock  {

  public selectedAgreement = new BehaviorSubject<string>('');
  public selectedProduct = new BehaviorSubject<Product>(new Product);

  public Product = new BehaviorSubject<object>(Object);
  public payBackOptions = new BehaviorSubject<object>(Object);
  public agentList = new BehaviorSubject<object>(Object);

  constructor() {
    // super(null);
  }

  setSelectedProduct(selectedProduct: Product) {
    return this.selectedProduct.next(selectedProduct);
  }

  policyCalculate(policyCalculate: any): Observable<any> {
    return Observable.of(PolicyDetailsMock.data);
  }
}
