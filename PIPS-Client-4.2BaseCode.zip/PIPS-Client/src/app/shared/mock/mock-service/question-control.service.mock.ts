import { Injectable } from '@angular/core';
import { FormArray, Validators } from '@angular/forms';
import * as _ from 'lodash';
import { v4 as uuid } from 'uuid';

import { CheckboxQuestion } from '../../components/dynamic-fields/question-checkbox';
import { DateOfBirthQuestion } from '../../components/dynamic-fields/question-date-of-birth';
import { TextboxQuestion } from '../../components/dynamic-fields/question-textbox';
import { QuestionBase, QuestionGroupBase } from '../../interfaces/question-base.interface';
import {
  Answer, Question, QuestionAnswerGroup,
  QuestionFormGroup, QuestionGroup, QuestionFormControl
} from '../../interfaces/question.interface';

@Injectable()
export class QuestionControlServiceMock {

  validationDate: Date = new Date();

  constructor() { }

  toFormQuestion(question: QuestionBase<any>) {

    const control = new QuestionFormControl(question.value);

    const validators = [];
    if (question.required) {
      validators.push(Validators.required);
      control.IsMandatory = true;
    } else {
      control.IsMandatory = false;
    }

    if (question.controlType === 'dateofbirth') {
      if (question.validationRules.length > 0) {
        question.validationRules.forEach(rule => {
          let validationFunction = '';
          switch (rule.QuestionFieldName.toLowerCase()) {
            case 'age': {
              validators.push(DateOfBirthQuestion.ageValidation(rule, this.validationDate));
              validationFunction = 'ageValidation';
            }
            break;
          }

          if (rule.RuleLevel === 'WA') {
            control.WarningValidations.push(validationFunction);
          } else {
            control.ErrorValidations.push(validationFunction);
          }
        });
        control.ErrorValidations.push('invalidDate');
      }
    } else if (question.controlType === 'checkbox') {
      if (question.validationRules.length > 0) {
        question.validationRules.forEach(rule => {
          let validationFunction = '';
          switch (rule.QuestionFieldName.toLowerCase()) {
            case 'value': {
              validators.push(CheckboxQuestion.compareValue(rule));
              validationFunction = 'compareValue';
            }
            break;
          }

          if (rule.RuleLevel === 'WA') {
            control.WarningValidations.push(validationFunction);
          } else {
            control.ErrorValidations.push(validationFunction);
          }
        });
      }
    }
    control.setValidators(validators);
    return control;
  }

  toFormGroupQuestion(questions: QuestionBase<any>[], parsedAnswerGroup: any[]): QuestionFormGroup {
    const group: any = {};

    questions.forEach(question => {
      question = _.cloneDeep(question);
      if (parsedAnswerGroup[question.key]) {
        if (question.controlType === 'checkbox') {
          parsedAnswerGroup[question.key].Answer = (parsedAnswerGroup[question.key].Answer === 'true');
        }
        question.value = parsedAnswerGroup[question.key].Answer;
      } else {
        if (question.controlType === 'checkbox') {
          question.value = false;
        }
      }
      group[question.key] = this.toFormQuestion(question);
    });
    return new QuestionFormGroup(_.cloneDeep(group));
  }

  toFormGroupQuestionArray(questionGroup: QuestionGroupBase<any>, parsedAnswerGroup: any[]) {
    if (questionGroup.MinItems > 0) {
      let index = 0;
      const controlGroupArr = [];
      while (index < questionGroup.MinItems) {
        let parsedAnswers = [];
        if (parsedAnswerGroup[index]) {
          parsedAnswers = parsedAnswerGroup[index];
        }
        let controlGroup = this.toFormGroupQuestion(questionGroup.Questions, parsedAnswers);
        controlGroup = _.cloneDeep(controlGroup);

        controlGroupArr.push(controlGroup);
        index++;
      }

      // const controlGroupArr = Array(questionGroup.MinItems).fill(_.cloneDeep(controlGroup));
      return new FormArray(controlGroupArr);
    } else {
      return false;
    }

  }

  toFormGroup(questionGroupBase: QuestionGroupBase<any>[], parsedAnswers: any[]) {
    const qGroup: any = {};

    questionGroupBase.forEach(questionGroup => {
      let returnedGrp;
      let parsedAnswerGroup = [];
      if (parsedAnswers[questionGroup.QuestionGroupId]) {
        parsedAnswerGroup = parsedAnswers[questionGroup.QuestionGroupId];
      }
      if (questionGroup.CanBeCreatedByUser) {
        returnedGrp = this.toFormGroupQuestionArray(questionGroup, parsedAnswerGroup);
      } else {
        if (parsedAnswerGroup.length === 1) {
          parsedAnswerGroup = parsedAnswerGroup[0];
        }
        returnedGrp = this.toFormGroupQuestion(questionGroup.Questions, parsedAnswerGroup);
      }
      qGroup[questionGroup.QuestionGroupId + ''] = returnedGrp;

    });
    return new QuestionFormGroup(qGroup);
  }

  parseQuestion(questionGroup: QuestionGroup[], parsedAnswers: any[]): QuestionGroupBase<any>[] {
    // tslint:disable-next-line:prefer-const
    let parsedQuestions: QuestionGroupBase<any>[] = [];

    if (questionGroup.length > 0) {
      questionGroup.forEach((questionGrp, questionGrpIndex) => {

        // tslint:disable-next-line:prefer-const
        let questionGroupBase = new QuestionGroupBase();
        questionGroupBase.QuestionGroupIndex = questionGrpIndex;
        questionGroupBase.Description = questionGrp.Description;
        questionGroupBase.QuestionGroupId = questionGrp.QuestionGroupId;
        questionGroupBase.CanBeCreatedByUser = questionGrp.CanBeCreatedByUser;

        if (!parsedAnswers[questionGrp.QuestionGroupId]) {
          if (questionGrp.CanBeCreatedByUser) {
            questionGroupBase.MinItems = 2;
            questionGroupBase.MaxItems = 18;
          } else {
            questionGroupBase.MinItems = 1;
            questionGroupBase.MaxItems = 1;
          }
        } else {
          questionGroupBase.MinItems = parsedAnswers[questionGrp.QuestionGroupId].length;
          questionGroupBase.MaxItems = 18;
        }

        questionGroupBase.Questions = [];
        questionGroupBase.ChildGroups = [];
        questionGrp.Questions.forEach((question, questionIndex) => {

          // tslint:disable-next-line:prefer-const
          let questionBase: QuestionBase<any>;

          switch (question.Format.toLowerCase()) {
            case 'boolean': {
              questionBase = new CheckboxQuestion({
                key: question.QuestionId,
                label: question.Description,
                type: 'checkbox',
                required: <boolean>question.IsMandatory,
              });

              break;
            }
            case 'dateofbirth': {
              questionBase = new DateOfBirthQuestion({
                key: question.QuestionId,
                label: question.Description,
                type: 'text',
                required: <boolean>question.IsMandatory,
                value: ''
              });

              break;
            }
            case 'number':
            case 'text':
            case 'textbox': {
              questionBase = new TextboxQuestion({
                key: question.QuestionId,
                label: question.Description,
                type: 'textbox',
                required: <boolean>question.IsMandatory,
                value: ''
              });
              break;
            }
            default: {
              // statements;
              break;
            }
          }

          questionBase.validationRules = <Array<any>>question.ValidationRules;

          questionGroupBase.Questions.push(questionBase);
        });

        if (questionGrp.ChildGroups) {
          const childQGroup = this.parseQuestion(questionGrp.ChildGroups, parsedAnswers);
          childQGroup.forEach(qGrp => {
            qGrp.Questions.forEach(element => {
              questionGroupBase.Questions.push(element);
            });
          });
        }
        parsedQuestions[questionGroupBase.QuestionGroupId] = (questionGroupBase);
      });
    }

    return parsedQuestions;
  }

  touchElements(frmGroup: QuestionFormGroup, mandatoryFieldValidity = true) {

    Object.keys(frmGroup.controls).forEach(field => {
      const control = frmGroup.get(field);
      if (control instanceof QuestionFormControl) {
        control.markAsTouched({});

        if (control.errors) {
          Object.keys(control.errors).forEach(error => {
            const isError = (control.ErrorValidations.indexOf(error) !== -1) ? true : false;
            if (mandatoryFieldValidity && isError && !control.valid) {
              mandatoryFieldValidity = false;
            }
          });
        }

      } else if (control instanceof QuestionFormGroup) {
        mandatoryFieldValidity = this.touchElements(control, mandatoryFieldValidity);
      } else if (control instanceof FormArray) {
        Object.keys(control.controls).forEach(arrField => {
          const arrControl = control.get(arrField);
          mandatoryFieldValidity = this.touchElements(<QuestionFormGroup>control.get(arrField), mandatoryFieldValidity);
        });
      }
    });

    return mandatoryFieldValidity;
  }

  convertAnswersArray(questionAnswerGroup: QuestionAnswerGroup[]) {
    const questionGroupArray = [];
    if (questionAnswerGroup !== undefined && questionAnswerGroup.length > 0) {
      questionAnswerGroup.forEach(questionGroup => {

        if (!questionGroupArray[questionGroup.QuestionGroupId]) {
          questionGroupArray[questionGroup.QuestionGroupId] = [];
        }
        const answerArray = [];
        questionGroup.Answers.forEach(answer => {
          answerArray[answer.QuestionId] = answer;
        });

        questionGroupArray[questionGroup.QuestionGroupId].push(answerArray);
      });
    }
    return questionGroupArray;
  }

  generateResponse(frmEditInsurance: QuestionFormGroup, forceSubmit: boolean = false): any[] {
    let result = [];

    if (frmEditInsurance.valid || forceSubmit) {
      Object.keys(frmEditInsurance.controls).forEach(field => {
        const control = frmEditInsurance.get(field);
        if (control instanceof QuestionFormControl) {
          if (field !== 'policyNumber') {
            const respAnswer = new Answer;
            // respAnswer.Question = new Question;
            // respAnswer.Question.QuestionId = field;
            respAnswer.Answer = control.value;
            respAnswer.QuestionId = field;
            result.push(respAnswer);
          }
        } else if (control instanceof QuestionFormGroup) {
          const respGroup = new QuestionAnswerGroup;
          respGroup.QuestionGroupId = parseInt(field, 10);
          respGroup.QuestionAnswerGroupId = uuid();
          respGroup.Answers = this.generateResponse(control, forceSubmit);
          result.push(respGroup);
        } else if (control instanceof FormArray) {
          const respArr = [];
          Object.keys(control.controls).forEach(arrField => {
            const arrControl = control.get(arrField);

            const respGroup = new QuestionAnswerGroup;

            respGroup.QuestionGroupId = parseInt(field, 10);
            respGroup.QuestionAnswerGroupId = uuid();
            respGroup.Answers = this.generateResponse(<QuestionFormGroup>arrControl, forceSubmit);
            respArr.push(respGroup);
          });
          result = respArr;
        }
      });
    }
    return result;
  }
}
