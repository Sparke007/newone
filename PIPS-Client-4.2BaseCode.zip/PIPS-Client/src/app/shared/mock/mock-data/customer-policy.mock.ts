import { CustomerPolicy } from '../../interfaces/customer.interface';


export class CustomerPolicyMock {
    public static data: CustomerPolicy = {
        'PolicyId': '5fa8a22b-5e6e-426f-89d1-00425d212973',
        'PolicyNumber': 'MAA123456798',
        'AgreementId': 36000472899,
        'ProductDescription': 'Health',
        'IssuingRepresentativeId': 36000122022,
        'Premium': 1200.0,
        'StartDate': '2018-02-18T00:00:00',
        'EndDate': '2018-09-22T00:00:00',
        'DistributionTypeDescription': 'Home Issued',
        'Term': 30,
        'ProductTermType': 'WE',
        'Status': 'Expired',
        'ProductLink': {
            'ProductId': 3,
            'Version': 1
        },
        'PackageDetails': [
            {
                'PackageId': 1,
                'Version': 1,
                'Description': 'Own',
                'IsMandatory': false
            }
        ],
        'PremiumReturn': {
            'PremiumReturnId': '8a720793-5e98-434d-bbc4-f50220591cb6',
            'PremiumReturnDate': '2018-12-18T00:00:00',
            'PremiumReturnType': 'BT',
            'Amount': 105.0,
            'Status': 'NA',
            'Representative': {
                'RepresentativeId': 36,
                'RepresentativeName': 'Wala Michal'
            }
        },
        'QuestionGroups': [
            /* {
                'QuestionGroupId': 3,
                'Description': 'NFH PFT',
                'CanBeCreatedByUser': false,
                'Questions': [
                    {
                        'QuestionId': 'e5a75c2b-53fa-4e90-beb1-01252a77dabd',
                        'Description': 'Permission to transfer data on a tangible medium',
                        'Format': 'Boolean',
                        'IsMandatory': false,
                        'ValidationRules': [
                            {
                                'ValidationRuleId': '1111',
                                'QuestionFieldName': 'Value',
                                'Operator': '=',
                                'Value': 'true',
                                'RuleLevel': 'WA',
                                'FailedMessage': null,
                                'SuccessMessage': null
                            }
                        ]
                    },
                    {
                        'QuestionId': 'bbe88bf3-e504-4e99-bfc1-5764af4a96a4',
                        'Description': 'Need for insurance',
                        'Format': 'Boolean',
                        'IsMandatory': false,
                        'ValidationRules': [
                            {
                                'ValidationRuleId': '1111',
                                'QuestionFieldName': 'Value',
                                'Operator': '=',
                                'Value': 'true',
                                'RuleLevel': 'WA',
                                'FailedMessage': 'Customer Health Statement is not valid.  Do you wish to continue?',
                                'SuccessMessage': 'Yes, the customer confirmed the need for cover'
                            }
                        ]
                    }
                ]
            } */
        ],
        'QuestionAnswersGroups': [
            /* {
                'QuestionAnswerGroupId': '3ccf9843-60f9-4e4c-9f87-49cdca00067d',
                'QuestionGroupId': 3,
                'Answers': [
                    {
                        'QuestionId': 'e5a75c2b-53fa-4e90-beb1-01252a77dabd',
                        'Answer': 'true'
                    },
                    {
                        'QuestionId': 'bbe88bf3-e504-4e99-bfc1-5764af4a96a4',
                        'Answer': 'true'
                    }
                ]
            } */
        ],
        'PolicyDetailsGroup':[
            {
                'Packages' : [{
                    'PackageId': 123,
                    'Amount': 345,
                    'Description': "test",
                    'IsMandatory' : true
                   }
                ]
            }
        ]
    };
}
