import {
    Product
} from '../../interfaces/product.interface';

export class PolicyDetailsMock {
    public static data = {
        'StartDate': '2017-05-21T00:00:00',
        'EndDate': '2019-06-07T00:00:00',
        'Premium': 2640.0,
        'QuestionGroups': [
            {
                'QuestionGroupId': 3,
                'Description': 'NFH PFT',
                'CanBeCreatedByUser': false,
                'Questions': [
                    {
                        'QuestionId': 'e5a75c2b-53fa-4e90-beb1-01252a77dabd',
                        'Description': 'Permission to transfer data on a tangible medium',
                        'Format': 'Boolean',
                        'IsMandatory': false,
                        'ValidationRules': [
                            {
                                'ValidationRuleId': 'sdf33532342sdf',
                                'QuestionFieldName': 'Value',
                                'Operator': '=',
                                'Value': 'true',
                                'RuleLevel': 'WA',
                                'FailedMessage': null,
                                'SuccessMessage': null
                            }
                        ]
                    },
                    {
                        'QuestionId': 'bbe88bf3-e504-4e99-bfc1-5764af4a96a4',
                        'Description': 'Need for insurance',
                        'Format': 'Boolean',
                        'IsMandatory': false,
                        'ValidationRules': [
                            {
                                'ValidationRuleId': 'sdfsdf',
                                'QuestionFieldName': 'Value',
                                'Operator': '=',
                                'Value': 'true',
                                'RuleLevel': 'WA',
                                'FailedMessage': 'Customer Health Statement is not valid.  Do you wish to continue?',
                                'SuccessMessage': 'Yes, the customer confirmed the need for cover'
                            }
                        ]
                    }
                ]
            },
            {
                'QuestionGroupId': 1,
                'Description': 'Child',
                'CanBeCreatedByUser': false,
                'Questions': [
                    {
                        'QuestionId': '5922812b-ebd0-4a0c-a77a-2dea2d756f08',
                        'Description': 'Date of birth',
                        'Format': 'DateOfBirth',
                        'IsMandatory': true,
                        'ValidationRules': [
                            {
                                'ValidationRuleId': 'sdsdfsdfsdffsdf',
                                'QuestionFieldName': 'Age',
                                'Operator': '<',
                                'Value': '1',
                                'RuleLevel': 'WA',
                                'FailedMessage': 'Child/Grandchild age does not meet Insurance Policy criteria. Do you wish to continue?',
                                'SuccessMessage': null
                            },
                            {
                                'ValidationRuleId': 'sdf3333sdf',
                                'QuestionFieldName': 'Age',
                                'Operator': '>',
                                'Value': '18',
                                'RuleLevel': 'WA',
                                'FailedMessage': 'Child/Grandchild age does not meet Insurance Policy criteria. Do you wish to continue?',
                                'SuccessMessage': null
                            }
                        ]
                    },
                    {
                        'QuestionId': 'e36a857b-9420-4134-a1e6-57ed5681084d',
                        'Description': 'First Name',
                        'Format': 'Text',
                        'IsMandatory': true,
                        'ValidationRules': []
                    },
                    {
                        'QuestionId': 'd3421b09-a9ed-4aab-a961-59cc53899237',
                        'Description': 'Last Name',
                        'Format': 'Text',
                        'IsMandatory': true,
                        'ValidationRules': []
                    }
                ]
            },
            {
                'QuestionGroupId': 2,
                'Description': 'Child',
                'CanBeCreatedByUser': true,
                'Questions': [
                    {
                        'QuestionId': '5922812b-ebd0-4a0c-a77a-2dea2d756f08',
                        'Description': 'Date of birth',
                        'Format': 'DateOfBirth',
                        'IsMandatory': true,
                        'ValidationRules': [
                            {
                                'QuestionFieldName': 'Age',
                                'Operator': '<',
                                'Value': '1',
                                'RuleLevel': 'WA',
                                'FailedMessage': 'Child/Grandchild age does not meet Insurance Policy criteria. Do you wish to continue?',
                                'SuccessMessage': null
                            },
                            {
                                'QuestionFieldName': 'Age',
                                'Operator': '>',
                                'Value': '18',
                                'RuleLevel': 'WA',
                                'FailedMessage': 'Child/Grandchild age does not meet Insurance Policy criteria. Do you wish to continue?',
                                'SuccessMessage': null
                            }
                        ]
                    },
                    {
                        'QuestionId': 'e36a857b-9420-4134-a1e6-57ed5681084d',
                        'Description': 'First Name',
                        'Format': 'Text',
                        'IsMandatory': true,
                        'ValidationRules': []
                    },
                    {
                        'QuestionId': 'd3421b09-a9ed-4aab-a961-59cc53899237',
                        'Description': 'Last Name',
                        'Format': 'Text',
                        'IsMandatory': true,
                        'ValidationRules': []
                    }
                ]
            }
        ]
    };
}
