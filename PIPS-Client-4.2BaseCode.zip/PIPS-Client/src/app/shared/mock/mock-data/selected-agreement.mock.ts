import { Agreement } from '../../interfaces/customer.interface';

export class SelectedAgreementMock {
    public static data: Agreement = {
      'AgreementId': 36000472893,
      'ProductDescription': 'bez',
      'AgreementNumber': '202505808',
      'AgreementStatus': 'AC',
      'IssueDate': '2017-05-20T00:00:00',
      'IssuerId': 36000123292,
      'Term': 24,
      'IssueValue': 2000.0,
      'FirstPaymentDueDate': '2017-07-07T00:00:00',
      'ProductTermType': 'MO',
      'DistributionTypeDescription': 'Home Collected',
      'EndDate': '2017-07-07T00:00:00',
      'ExtendedStatus': 'Active',
      'CollectionMethodTypeDescription': 'Cash',
      'IsCancellationProduct': false
    };
}
