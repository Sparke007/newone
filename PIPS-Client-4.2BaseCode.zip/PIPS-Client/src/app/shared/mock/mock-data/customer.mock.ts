import { Customer } from '../../interfaces/customer.interface';
import { Insurance } from '../../interfaces/insurance.interface';


export class CustomerMock {
    public static data: Customer[] = [
        {
            'CustomerId': 36000318090,
            'BirthDate': '1988-05-17T00:00:00',
            'Pin': '96969696969',
            'CustomerStatusCode': 'AA',
            'DisplayName': 'Pan Yuvraj Singh',
            'ContactDetails': {
                'EmailAddress': null,
                'ShortAddress': 'Street Name Of India House Numb/ 44 58-995 Navi Mumbai',
                'Telephone': [
                    {
                        'PhoneNumberType': 'HO',
                        'PhoneNumber': '02192265651'
                    }
                ]
            },
            'Agreements': [
                {
                  'AgreementId': 36000472893,
                  'AgreementNumber': '202505808',
                  'AgreementStatus': 'AC',
                  'IssueDate': '2017-05-20T00:00:00',
                  'ProductDescription': 'bez',
                  'CollectionMethodTypeDescription': 'Cash',
                  'IssuerId': 36000123292,
                  'Term': 24,
                  'IssueValue': 2000.0,
                  'FirstPaymentDueDate': '2017-07-07T00:00:00',
                  'ProductTermType': 'MO',
                  'DistributionTypeDescription': 'Home Collected',
                  'EndDate': '2017-07-07T00:00:00',
                  'ExtendedStatus': 'Active',
                  'IsCancellationProduct': false
                }
            ],
            'Insurance': [
                {
                    'PolicyId': '59674f19-e9c1-4eec-b474-0cacfb27714e',
                    'AgreementId': 36000472893,
                    'PolicyNumber': 'PAR000000001',
                    'StartDate': '05/21/2017 00:00:00',
                    'EndDate': '05/21/2017 00:00:00',
                    'ProductDescription': 'Health',
                    'Status': 'Active',
                    'Period': 1,
                    'Premium': 1,
                    'CurrentProcessing': 'ReinstatePending',
                    'SelectedProduct': {
                        'ProductId': 1,
                        'Version': 1
                    },
                    'AllowedActions': [
                        'View',
                        'Update',
                        'Cancel',
                        'Decline'
                    ]
                },
                {
                    'PolicyId': 'b975457b-ed7a-4024-b712-1da0a9e5cbbf',
                    'AgreementId': 36000472893,
                    'PolicyNumber': 'PAR000000002',
                    'StartDate': '05/21/2017 00:00:00',
                    'EndDate': '05/21/2017 00:00:00',
                    'ProductDescription': 'Health',
                    'Status': 'Expired',
                    'CurrentProcessing': 'ReinstatePending',
                    'Period': 31,
                    'Premium': 31,
                    'SelectedProduct': {
                        'ProductId': 1,
                        'Version': 1
                    },
                    'AllowedActions': [
                        'View',
                        'Update',
                        'Cancel',
                        'Decline'
                    ]
                },
            ]
        }
    ];
}
