import { Product } from '../../interfaces/product.interface';

export class SelectedProductMock {
    public static data: Product = {
        'ProductId': 1,
        'Version': 1,
        'MaxAge': 75,
        'MinAge': 20,
        'ProductTerms': [],
        'PolicyNumBasicValidationRule': '',
        'PolicyNumCheckDigitAlgorithm': '',
        'Description': 'Health',
        'MaxAllowed': 1,
        'MandatoryPackages': [
            {
                'PackageId': 1,
                'Version': 1,
                'Description': 'Own',
                'IsMandatory':true
            }
        ],
        'PackageGroups': [
            {
                'Packages': [
                    {
                        'PackageId': 2,
                        'Version': 1,
                        'Description': 'Child',
                        'IsMandatory':false
                    }
                ]
            }
        ],
        'PropertyValues': [
            {
                'PropertyCode': 'SM',
                'PropertyValueCode': 'IN'
            },
            {
                'PropertyCode': 'TY',
                'PropertyValueCode': 'PE'
            }
        ],
        FilterProperties: []
    };
  }
