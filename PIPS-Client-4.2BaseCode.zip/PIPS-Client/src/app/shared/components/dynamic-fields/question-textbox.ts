import { QuestionBase } from '../../interfaces/question-base.interface';

export class TextboxQuestion extends QuestionBase<string> {
  controlType = 'textbox';
  type: string;

  constructor(options: {} = {}) {
    super(options);
    this.type = 'text';
  }
}
