import { ChangeDetectorRef, Component, Input, OnInit } from '@angular/core';
import { FormArray } from '@angular/forms';
import * as _ from 'lodash';

import { Constants } from '../../interfaces/constants';
import { QuestionGroupBase } from '../../interfaces/question-base.interface';
import { QuestionFormGroup } from '../../interfaces/question.interface';
import { QuestionControlService } from '../../services/question-control.service';


@Component({
  selector: 'app-df-question-group',
  templateUrl: './df-question-group.component.html'
})
export class DFQuestionGroupComponent implements OnInit {
  @Input() cloneQuestionGroup: QuestionGroupBase<any>;
  @Input() form: QuestionFormGroup;
  @Input() groupType: string;
  @Input() groupIndex: number;
  questionGroup: QuestionGroupBase<any>;

  questionGroupCounter: number;

  constructor(private srvQuestionCtrlService: QuestionControlService, private ref: ChangeDetectorRef) {
  }

  ngOnInit(): void {
    this.questionGroup = _.cloneDeep(this.cloneQuestionGroup);

    if (this.questionGroup.Description === null) {
      this.questionGroup.Description = Constants.Empty;
    }
    // Hide Text for checkbox
    if (this.questionGroup.Questions.some(x => x.controlType === Constants.Checkbox)) {
      this.questionGroup.Description = Constants.Empty;
    }

    if (this.groupType === Constants.FormArray) {
      this.questionGroupCounter = Object.keys((<FormArray>this.form.controls[this.cloneQuestionGroup.QuestionGroupId]).controls).length;
    } else {
      this.questionGroupCounter = 0;
    }
  }

  deleteGroup(groupIndex) {
    const formGroup = (<FormArray>this.form.controls[this.questionGroup.QuestionGroupId]);
    if (formGroup && formGroup.at(groupIndex)[Constants.QuestionAnswerGroupId]) {
      formGroup.at(groupIndex)[Constants.QuestionGroupId] = this.questionGroup.QuestionGroupId;
      this.srvQuestionCtrlService.setDeletedChildGroup(<FormArray>formGroup.at(groupIndex));
    }
    (formGroup).removeAt(groupIndex);
  }
}
