import { ChangeDetectorRef, Component, Input, OnInit } from '@angular/core';
import { AbstractControl } from '@angular/forms';
import * as _ from 'lodash';

import { Constants } from '../../interfaces/constants';
import { QuestionBase, QuestionGroupBase } from '../../interfaces/question-base.interface';
import { QuestionFormGroup } from '../../interfaces/question.interface';
import { UtilityService } from '../../services/utility.service';

@Component({
  selector: 'app-df-question',
  templateUrl: './df-question.component.html'
})
export class DFQuestionComponent implements OnInit {
  @Input() questionGroup: QuestionGroupBase<any>;
  @Input() cloneQuestion: QuestionBase<any>;
  @Input() form: QuestionFormGroup;
  @Input() groupType: string;
  @Input() groupIndex: number;
  @Input() groupFieldKey: number;

  @Input() canBeCreatedByUser: boolean;

  datefield = [];
  question: QuestionBase<any>;

  currentElem: AbstractControl;

  objectKeys = Object.keys;

  get isValid() {
    return true;
  }

  constructor(private ref: ChangeDetectorRef) {
  }

  ngOnInit(): void {
    this.question = _.cloneDeep(this.cloneQuestion);

    this.setCurrentValue();

    if (this.question.controlType === Constants.DateofBirth) {
      this.resetDate();
    }
    if (this.question.controlType === Constants.Checkbox) {
      if (this.form.FormType !== Constants.Add) {
        this.toggleCheck(!this.currentElem.value, this.question);
      }
    }
    this.canBeCreatedByUser = this.questionGroup.CanBeCreatedByUser;
  }

  toggleCheck(ev, question: QuestionBase<any>) {
    question.inlineMessage = Constants.Empty;

    if (this.currentElem.valid && question.validationRules.length > 0) {
      question.validationRules.forEach(rule => {
        if (rule.SuccessMessage !== Constants.Empty) {
          question.inlineMessage = rule.SuccessMessage;
        }
      });
    }
  }

  updateDate(options) {
    const groupId = this.questionGroup.QuestionGroupId.toString();
    const curDate = options.year + Constants.Hypen +
      UtilityService.padZero(options.month) + Constants.Hypen + UtilityService.padZero(options.day);
    this.currentElem.setValue(curDate);
    this.currentElem.markAsTouched();
  }

  resetDate() {

    const curDate = this.currentElem.value;

    const optionsArr = curDate.split(Constants.Hypen);
    this.question.dateOptions.day = optionsArr[2];
    this.question.dateOptions.month = optionsArr[1];
    this.question.dateOptions.year = optionsArr[0];
  }

  onInputEntry(event, nextInput) {
    const input = event.target;
    if (input.value.length >= input.attributes.maxlength.value) {
      nextInput.focus();
    }
  }

  setCurrentValue() {
    const groupId = this.questionGroup.QuestionGroupId.toString();

    if (this.groupType === Constants.FormArray) {
      this.currentElem = this.form.get(groupId).get(this.groupIndex.toString()).get(this.question.key);
    } else {
      this.currentElem = this.form.get(groupId).get(this.question.key);
    }
  }
}
