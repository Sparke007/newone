import { QuestionBase } from '../../interfaces/question-base.interface';
import { ValidationRule } from '../../interfaces/question.interface';
import { ValidatorFn, AbstractControl } from '@angular/forms';
import { UtilityService } from '../../services/utility.service';

export class CheckboxQuestion extends QuestionBase<string> {
  controlType = 'checkbox';
  type: string;

  constructor(options: {} = {}) {
    super(options);
    this.type = options['type'] || '';
  }

  static compareValue(rule: ValidationRule): ValidatorFn {

    return (control: AbstractControl): { [key: string]: any } => {

      let returnValue = { 'compareValue': rule.FailedMessage  };
      if (UtilityService.compareValue(control.value, rule.Value, rule.Operator)) {
        returnValue = null;
      }

      return returnValue;
    };
  }
}

