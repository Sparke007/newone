import { ValidatorFn } from '@angular/forms';
import * as _ from 'lodash';

import { Constants } from '../../interfaces/constants';
import { QuestionBase } from '../../interfaces/question-base.interface';
import { QuestionFormControl, ValidationRule } from '../../interfaces/question.interface';
import { UtilityService } from '../../services/utility.service';

export class DateOfBirthQuestion extends QuestionBase<string> {
  controlType = Constants.DateofBirth;
  type: string;

  constructor(options: {} = {}) {
    super(options);
    this.type = Constants.Text;
  }

  static ageValidation(rule: ValidationRule, validationDate: Date): ValidatorFn {

    return (control: QuestionFormControl): { [key: string]: any } => {
      if (!control.value) { return null; }
      const optionsArr = control.value.split(Constants.Hypen);
      const inputDate = optionsArr[2];
      const inputMonth = optionsArr[1];
      const inputYear = optionsArr[0];

      let returnValue = {};
      if (UtilityService.validateDate(inputDate, inputMonth, inputYear) === Constants.Empty &&
        UtilityService.validateDateRange(new Date(inputYear, inputMonth - 1, inputDate), undefined
          , new Date(new Date().toDateString())) === Constants.Empty) {

        returnValue = { [Constants.AgeValidation]: rule.FailedMessage };

        const dateObj = new Date(new Date(control.value).toDateString());
        let validateAgainstDate: Date = new Date;
        if (validationDate instanceof Date) {
          let nValidationDate = _.cloneDeep(validationDate);
          nValidationDate = new Date(nValidationDate.setFullYear(nValidationDate.getFullYear() - parseInt(rule.Value, 10)));
          nValidationDate.setDate(nValidationDate.getDate() + 1);
          validateAgainstDate = nValidationDate;
        }
        let forbidden;
        if (rule.Operator === Constants.GreaterThan) {
          forbidden = UtilityService.validateDateRange(dateObj, validateAgainstDate);
        } else if (rule.Operator === Constants.LessThan) {
          forbidden = UtilityService.validateDateRange(dateObj, undefined, validateAgainstDate);
        }
        if (forbidden === Constants.Empty) {
          returnValue = null;
        }
      } else {
        const text = sessionStorage.getItem(Constants.Locale);
        returnValue = {
          [Constants.InvalidDate]: (text === Constants.English) ?
            Constants.InvalidDateEn : ((text === Constants.Polish)) ? Constants.InvalidDatePl : Constants.Empty
        };
      }
      return returnValue;
    };
  }
}
