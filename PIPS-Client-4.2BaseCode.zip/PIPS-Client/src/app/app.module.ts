import { DatePipe, Location } from '@angular/common';
import { HTTP_INTERCEPTORS, HttpClientModule } from '@angular/common/http';
import { LOCALE_ID, NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';

import { AppComponent } from './app.component';
import { CustomerModule } from './customer/customer.module';
import { InsuranceModule } from './insurance/insurance.module';
import { RoutingModule } from './routing.module';
import { AuthGuard } from './shared/services/auth-guard.service';
import { CustomerService } from './shared/services/customer.service';
import { HttpLocaleService } from './shared/services/http-locale.service';
import { InsuranceService } from './shared/services/insurance.service';
import { LoaderService } from './shared/services/loader.service';
import { QuestionControlService } from './shared/services/question-control.service';
import { WinAuthInterceptor } from './shared/services/win-auth.interceptor';
import { SharedModule } from './shared/shared.module';

@NgModule({
  declarations: [
    AppComponent,
  ],
  imports: [
    SharedModule,
    BrowserModule,
    HttpClientModule,
    RoutingModule,
    NgbModule.forRoot(),
    CustomerModule,
    InsuranceModule
  ],
  providers: [
    CustomerService,
    InsuranceService,
    QuestionControlService,
    HttpLocaleService,
    AuthGuard,
    LoaderService,
    Location,
    DatePipe,
    { provide: LOCALE_ID, useValue: sessionStorage.getItem('locale')},
    { provide: HTTP_INTERCEPTORS, useClass: WinAuthInterceptor, multi: true },
  ],
  bootstrap: [AppComponent]
})
export class AppModule { }
