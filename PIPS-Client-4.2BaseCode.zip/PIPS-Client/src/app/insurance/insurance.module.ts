import { NgModule } from '@angular/core';
import { RouterModule } from '@angular/router';

import { SharedModule } from '../shared/shared.module';
import { AgreementSearchComponent } from './agreement-search/agreement-search.component';
import { InsuranceCancelComponent } from './insurance-action/insurance-cancel/insurance-cancel.component';
import { InsuranceEditComponent } from './insurance-action/insurance-edit/insurance-edit.component';
import { InsuranceManageComponent } from './insurance-action/insurance-manage/insurance-manage.component';
import { InsurancePackageComponent } from './insurance-package/insurance-package.component';
import { InsuranceRoutingModule } from './insurance-routing.module';
import { InsuranceWrapperComponent } from './insurance-wrapper/insurance-wrapper.component';


@NgModule({
  imports: [
    SharedModule,
    RouterModule,
    InsuranceRoutingModule
  ],
  declarations: [
    InsuranceWrapperComponent,
    InsurancePackageComponent,
    InsuranceEditComponent,
    InsuranceManageComponent,
    InsuranceCancelComponent,
    AgreementSearchComponent,
  ],
})
export class InsuranceModule { }
