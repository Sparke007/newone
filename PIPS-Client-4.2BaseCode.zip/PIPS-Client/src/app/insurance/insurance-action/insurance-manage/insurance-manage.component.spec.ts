import { ComponentFixture, TestBed } from '@angular/core/testing';
import { NO_ERRORS_SCHEMA } from '@angular/core';
import { Location } from '@angular/common';
import { ActivatedRoute } from '@angular/router';
import { CustomerService } from '../../../shared/services/customer.service';
import { InsuranceManageComponent } from './insurance-manage.component';

describe('InsuranceManageComponent', () => {
    let comp: InsuranceManageComponent;
    let fixture: ComponentFixture<InsuranceManageComponent>;

    beforeEach(() => {
        const locationStub = {
            back: () => ({})
        };
        const activatedRouteStub = {
            params: {
                subscribe: () => ({})
            }
        };
        const customerServiceStub = {
            selectedAgreement: {
                subscribe: () => ({})
            }
        };
        TestBed.configureTestingModule({
            declarations: [ InsuranceManageComponent ],
            schemas: [ NO_ERRORS_SCHEMA ],
            providers: [
                { provide: Location, useValue: locationStub },
                { provide: ActivatedRoute, useValue: activatedRouteStub },
                { provide: CustomerService, useValue: customerServiceStub }
            ]
        });
        fixture = TestBed.createComponent(InsuranceManageComponent);
        comp = fixture.componentInstance;
    });

    it('can load instance', () => {
        expect(comp).toBeTruthy();
    });

    describe('BtnClick', () => {
        it('makes expected calls', () => {
            const locationStub: Location = fixture.debugElement.injector.get(Location);
            spyOn(locationStub, 'back');
            comp.BtnClick();
            expect(locationStub.back).toHaveBeenCalled();
        });
    });

});
