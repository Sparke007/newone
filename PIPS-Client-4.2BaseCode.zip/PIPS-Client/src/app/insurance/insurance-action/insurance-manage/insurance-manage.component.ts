import { Location } from '@angular/common';
import { Component, OnInit } from '@angular/core';
import { OnDestroy } from '@angular/core/src/metadata/lifecycle_hooks';
import { ActivatedRoute } from '@angular/router';
import { ISubscription } from 'rxjs/Subscription';

import { Agreement } from '../../../shared/interfaces/customer.interface';
import { Insurance } from '../../../shared/interfaces/insurance.interface';
import { CustomerService } from '../../../shared/services/customer.service';

@Component({
  selector: 'app-insurance-manage',
  templateUrl: './insurance-manage.component.html',
  styleUrls: ['./insurance-manage.component.css']
})
export class InsuranceManageComponent implements OnInit, OnDestroy {
  insurance: Insurance;
  loanAgreement: Agreement;
  subSelectedAgreement: ISubscription;
  action: string;

  constructor(private srvCustomer: CustomerService, private activatedRoute: ActivatedRoute,
    private location: Location) { }

  ngOnInit() {
    this.subSelectedAgreement = this.srvCustomer.selectedAgreement.subscribe(agreementDetails => {
      this.loanAgreement = agreementDetails;
      this.activatedRoute.params.subscribe(params => {
        this.action = params.action !== undefined ? params.action : 'cancel';
        if (agreementDetails.Insurance !== undefined) {
          const selectedinsurance = agreementDetails.Insurance.filter(x => x.PolicyId === params.policyId);
          if (selectedinsurance !== undefined && selectedinsurance.length > 0) {
            this.insurance = selectedinsurance[0];
            window.scrollTo(0, 0);
          }
        }
      });
    });
  }

  BtnClick() {
    this.location.back();
  }

  ngOnDestroy(): void {
    this.subSelectedAgreement.unsubscribe();
  }

}
