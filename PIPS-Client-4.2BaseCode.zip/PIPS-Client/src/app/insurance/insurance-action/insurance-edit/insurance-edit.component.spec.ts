import { ComponentFixture, TestBed, inject } from '@angular/core/testing';
import { NO_ERRORS_SCHEMA } from '@angular/core';
import { ChangeDetectorRef } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { Router } from '@angular/router';
import { InsuranceService } from '../../../shared/services/insurance.service';
import { CustomerService } from '../../../shared/services/customer.service';
import { QuestionControlService } from '../../../shared/services/question-control.service';
import { InsuranceEditComponent } from './insurance-edit.component';
import { SharedModule } from '../../../shared/shared.module';
import { QuestionFormGroup } from '../../../shared/interfaces/question.interface';
import { async } from '@angular/core/testing';
import { of } from 'rxjs/observable/of';
import { Product } from '../../../shared/interfaces/product.interface';
import { Observable } from 'rxjs/Observable';
import { HttpClient } from '@angular/common/http';
import { HttpClientModule } from '@angular/common/http';
import { SelectedProductMock } from '../../../shared/mock/mock-data/selected-product.mock';
import { InsuranceServiceMock } from '../../../shared/mock/mock-service/insurance.service.mock';
import { CustomerServiceMock } from '../../../shared/mock/mock-service/customer.service.mock';
import { SelectedAgreementMock } from '../../../shared/mock/mock-data/selected-agreement.mock';
import { CustomerMock } from '../../../shared/mock/mock-data/customer.mock';
import { QuestionControlServiceMock } from '../../../shared/mock/mock-service/question-control.service.mock';
import { DFQuestionGroupComponent } from '../../../shared/components/dynamic-fields/df-question-group.component';
import { DFQuestionComponent } from '../../../shared/components/dynamic-fields/df-question.component';
import { BehaviorSubject } from 'rxjs/BehaviorSubject';
import { FormArray } from '@angular/forms';

describe('InsuranceEditComponent', () => {
    let comp: InsuranceEditComponent;
    let fixture: ComponentFixture<InsuranceEditComponent>;
    let customerServiceStub: CustomerService;
    let insuranceServiceStub: InsuranceService;
    let questionControlServiceStub: QuestionControlService;
    let routeStub: ActivatedRoute;
    let element;
    let action: BehaviorSubject<String> = new BehaviorSubject<String>('add');

    beforeEach(() => {
        TestBed.configureTestingModule({
            declarations: [InsuranceEditComponent],
            schemas: [NO_ERRORS_SCHEMA],
            imports: [SharedModule, HttpClientModule],
            providers: [
                { provide: ChangeDetectorRef },
                { provide: ActivatedRoute, useValue: { params: Observable.of(action.getValue()) } },
                { provide: Router },
                HttpClient,
                { provide: InsuranceService, useClass: InsuranceServiceMock },
                { provide: CustomerService, useClass: CustomerServiceMock },
                QuestionControlService
            ]
        }).compileComponents();
        // insuranceServiceStub = TestBed.get(QuestionControlService);
        insuranceServiceStub = TestBed.get(InsuranceService);
        customerServiceStub = TestBed.get(CustomerService);
        questionControlServiceStub = TestBed.get(QuestionControlService);
        routeStub = TestBed.get(ActivatedRoute);

        routeStub.params = Observable.of({ action: 'add' });

        customerServiceStub.nationalId.next('123');
        customerServiceStub.setSelectedCustomer(CustomerMock.data[0]);
        customerServiceStub.setSelectedAgreement(CustomerMock.data[0].Agreements[0]);
        insuranceServiceStub.setSelectedProduct(SelectedProductMock.data);
    });

    beforeEach(inject([InsuranceService, CustomerService], (i, s) => {

        fixture = TestBed.createComponent(InsuranceEditComponent);
        comp = fixture.componentInstance;

        element = fixture.nativeElement;

        action.next('add');

        routeStub.params.subscribe((params) => {
            comp.action = params.action;
        });
    }));

    describe('initEditModule', () => {
        it('makes expected calls and data setup - Add', async(a => {

            spyOn(insuranceServiceStub, 'selectedProduct');

            routeStub.params = Observable.of({ action: 'add' });

            comp.frmEditInsuranceGroup = new QuestionFormGroup({});

            fixture.detectChanges();

            comp.initEditModule({ policyId: '100' });

            fixture.detectChanges();

            expect(Object.keys(comp.frmEditInsuranceGroup.controls).length).toEqual(4);
        }));

        it('makes expected calls and data setup - Update', async(a => {

            spyOn(insuranceServiceStub, 'selectedProduct');

            routeStub.params = Observable.of({ action: 'update' });

            comp.frmEditInsuranceGroup = new QuestionFormGroup({});

            fixture.detectChanges();

            comp.initEditModule({ policyId: '100' });

            fixture.detectChanges();

            expect(Object.keys(comp.frmEditInsuranceGroup.controls).length).toEqual(1);
        }));

        it('Add child', () => {
            spyOn(insuranceServiceStub, 'selectedProduct');

            routeStub.params = Observable.of({ action: 'add' });

            comp.frmEditInsuranceGroup = new QuestionFormGroup({});

            fixture.detectChanges();

            comp.initEditModule({ policyId: '100' });
            comp.addGroup(2);

            fixture.detectChanges();

            expect((<FormArray>comp.frmEditInsuranceGroup.controls[2]).controls.length).toEqual(3);
        });

        it('Delete child ', () => {

            routeStub.params = Observable.of({ action: 'add' });
            comp.frmEditInsuranceGroup = new QuestionFormGroup({});

            fixture.detectChanges();

            comp.initEditModule({ policyId: '100' });
            comp.addGroup(2);
            comp.deleteGroup(2, 2);

            fixture.detectChanges();

            expect((<FormArray>comp.frmEditInsuranceGroup.controls[2]).controls.length).toEqual(2);
        });

        it('Update Policy ', () => {

            routeStub.params = Observable.of({ action: 'update' });
            comp.frmEditInsuranceGroup = new QuestionFormGroup({});

            fixture.detectChanges();

            comp.initEditModule({ policyId: '100' });
            comp.saveInsurance(true);

            fixture.detectChanges();

            expect(Object.keys(comp.frmEditInsuranceGroup.controls).length).toEqual(1);
        });
    });

    /* describe('handlePolicyAction', () => {
        it('makes expected calls', () => {
            const routerStub: Router = fixture.debugElement.injector.get(Router);
            spyOn(comp, 'saveInsurance');
            spyOn(routerStub, 'navigate');
            comp.handlePolicyAction();
            expect(comp.saveInsurance).toHaveBeenCalled();
            expect(routerStub.navigate).toHaveBeenCalled();
        });
    }); */

});
