import { Component, OnDestroy, OnInit, ViewChild } from '@angular/core';
import { FormArray, AbstractFormGroupDirective } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import * as _ from 'lodash';
import { ISubscription } from 'rxjs/Subscription';
import { v4 as uuid } from 'uuid';
import { Constants } from '../../../shared/interfaces/constants';
import { Agreement, CustomerPolicy, ProductLink,Customer } from '../../../shared/interfaces/customer.interface';
import { Insurance } from '../../../shared/interfaces/insurance.interface';
import { PolicyStatus, Product, ProductReturn, ProductUpdate, Packages, ProductTerm } from '../../../shared/interfaces/product.interface';
import { QuestionGroupBase } from '../../../shared/interfaces/question-base.interface';
import {
  QuestionAnswerGroup,
  QuestionFormControl,
  QuestionFormGroup,
  QuestionGroup,
} from '../../../shared/interfaces/question.interface';
import { CustomerService } from '../../../shared/services/customer.service';
import { HttpLocaleService } from '../../../shared/services/http-locale.service';
import { InsuranceService } from '../../../shared/services/insurance.service';
import { QuestionControlService } from '../../../shared/services/question-control.service';
import { UtilityService } from '../../../shared/services/utility.service';
import { PackagesGroupDetail } from '../../../shared/interfaces/product.interface';


@Component({
  selector: 'app-insurance-edit',
  templateUrl: './insurance-edit.component.html',
  styleUrls: ['./insurance-edit.component.css']
})
export class InsuranceEditComponent implements OnInit, OnDestroy {
  policyResponseData: CustomerPolicy;
  customer:Customer;
  activePolicyCount: Number;
  currentPackageType: string;
  errorMessageList = [];
  optionalFieldWarnings = [];
  policyNumber: string;
  agreementNumber: number;
  customerConfirmation = false;
  showConfirmationBtn = false;
  mandatoryFieldError = false;
  frmDisable = false;
  policyError = false;
  agreementChange;
  agreementDetails: Agreement;
  previousagreementDetails: Agreement;
  selectedPackage: Product = new Product();
  selectedProductTerm: ProductTerm = new ProductTerm();
  package:Packages=new Packages();
  selectedProductforEdit: Product = new Product();
  insuranceQuestions: QuestionGroupBase<any>[];
  packageGroupDetails: PackagesGroupDetail;
  frmEditInsuranceGroup: QuestionFormGroup;
  selectedProduct = { ProductLink: new ProductLink(), Package: [] = [], ProductTerm: new ProductTerm() };
  payload: string;
  action: string;
  pendingStatus: string;

  selectedpayBack: Object = {};

  subSelectedProduct: ISubscription;
  subSelectedProductTerm: ISubscription;
  subSelectedAgreement: ISubscription;
  subPolicyDetails: ISubscription;
  subPolicyControl: ISubscription;
  subRoute: ISubscription;
  subCustomerPolicy: ISubscription;
  subDeletedChildList: ISubscription;
  subExceptionCode: ISubscription;

  frmBtnDisabled: boolean;
  productTermValidationRule;

  policyData = {
    [Constants.StartDate]: '',
    [Constants.EndDate]: '',
    [Constants.Premium]: 0,
    [Constants.ProductTermType]: '',
    [Constants.Term]: 0,
    [Constants.QuestionGroups]: [] = []
  };

  insuranceDetails: Insurance = new Insurance();
  @ViewChild(Constants.ElmPolicyNumber) elmPolicyNumber: any;

  constructor(private srvInsurance: InsuranceService,
    private srvCustomer: CustomerService,
    private route: ActivatedRoute,
    private router: Router,
    private srvQuestionCtrlService: QuestionControlService,
    private srvHttpLocale: HttpLocaleService
  ) {
  }

  ngOnInit() {
    this.frmEditInsuranceGroup = new QuestionFormGroup({});
    this.srvQuestionCtrlService.deletedChild.next(null);
    this.srvCustomer.businessExceptionCode.next(null);
    this.frmEditInsuranceGroup.addControl(Constants.PolicyNumber, new QuestionFormControl({}));
    this.frmBtnDisabled = false;
    this.subRoute = this.route.params.subscribe(params => {
      this.action = params.action;

      if (this.action !== Constants.Add) {
        this.initEditModule(params);
      }
    });
  }


  // Dispaly error message from agreement search component
  agreementSearch(event) {
    if (event.text) {
      this.errorMessageList.push(event.text);
    } else {
      this.errorMessageList = [];
    }
  }

  // Enable/Disable Confirm Btn on agreement search input event
  enableDisableConfirmBtn(event) {
    this.frmBtnDisabled = event;
  }

  initEditModule(params?) {
    this.customerConfirmation = false;
    this.showConfirmationBtn = false;
    this.mandatoryFieldError = false;
    this.policyError = false;
    this.errorMessageList = [];
    this.optionalFieldWarnings = [];
    this.frmEditInsuranceGroup.reset();
    this.frmEditInsuranceGroup.markAsUntouched();
    const previousAction = this.action !== Constants.View ? this.action : Constants.Empty;

    if (this.action !== Constants.Add && params && params.policyId) {
      const getCustomerPolicy = this.srvCustomer.getCustomerPolicy(params.policyId);
      if (this.srvHttpLocale.checkTokenLifeTime()) {
        this.srvHttpLocale.getNewToken()
          .subscribe(token => {
            if (token) {
              this.subCustomerPolicy = getCustomerPolicy.subscribe(policyResponse => {
                  let packagesForDescription : Packages[]=[];
                  policyResponse.PackageDetails.forEach(pkg=>{
                  let packageForDescription = new Packages;
                  packageForDescription= this.getPackageForDescription(packageForDescription,pkg);
                  packagesForDescription.push(packageForDescription);
                });
                this.onCompleteGetCustomerPolicy(packagesForDescription,policyResponse);
              });
            }
          });
      } else {
        this.subCustomerPolicy = getCustomerPolicy.subscribe(policyResponse => {
                  let packagesForDescription : Packages[]=[];
                  policyResponse.PackageDetails.forEach(pkg=>{
                  let packageForDescription = new Packages;
                  packageForDescription= this.getPackageForDescription(packageForDescription,pkg);
                  packagesForDescription.push(packageForDescription);
                });
          this.onCompleteGetCustomerPolicy(packagesForDescription,policyResponse);
        });
      }
    }
    if (this.action === Constants.Add || (this.action === Constants.Update && !params)) {
      this.srvQuestionCtrlService.deletedChild.next(null);
      this.subSelectedProduct = this.srvInsurance.selectedProduct.subscribe(packageDetails => {
        if (Object.keys(packageDetails).length > 0) {
          let packagesForDescription : Packages[]=[];
          this.selectedPackage = packageDetails;
          this.currentPackageType = packageDetails.Description;
          this.agreementDetails = this.srvCustomer.selectedAgreement.getValue();
          this.selectedProductTerm = this.srvInsurance.selectedProductTerm.getValue();
          const packageData: any[] = [];
          if (packageDetails !== undefined) {
            if (packageDetails.MandatoryPackages !== undefined && packageDetails.MandatoryPackages.length > 0) {
              packageDetails.MandatoryPackages.forEach(data => {
                packageData.push(data);
                let packageForDescription = new Packages;
                packageForDescription= this.getPackageForDescription(packageForDescription,data);
                packageForDescription.IsMandatory=true;
                packagesForDescription.push(packageForDescription);
              });
            }
            if (packageDetails.PackageGroups !== undefined && packageDetails.PackageGroups.length > 0) {

              packageDetails.PackageGroups.forEach(pckgGroup=>{
                pckgGroup.Packages.forEach(pckg => {
                packageData.push(pckg);
                let packageForDescription = new Packages;
                packageForDescription= this.getPackageForDescription(packageForDescription,pckg);
                packageForDescription.IsMandatory=false;
                packagesForDescription.push(packageForDescription);
                });
              });
              // packageDetails.PackageGroups[0].Packages.forEach(data => {
              //   packageData.push(data);
              // });
            }
          }
          const agreementData = {
            [Constants.StartDate]: this.agreementDetails.IssueDate,
            [Constants.Term]: this.selectedProductTerm.Term,
            [Constants.ProductTermType]: this.selectedProductTerm.ProductTermType,
          };

          const policyCalculate = this.srvInsurance.policyCalculate({
            [Constants.AgreementDetails]: agreementData,
            [Constants.SelectedPackages]: packageData,
            [Constants.PolicyId]: (this.action === Constants.Update) ? this.policyResponseData.PolicyId : Constants.EmptyGuid
          });
          if (this.srvHttpLocale.checkTokenLifeTime()) {
            this.srvHttpLocale.getNewToken()
              .subscribe(token => {
                if (token) {
                  this.subPolicyDetails = policyCalculate
                    .subscribe(policydata => {
                      this.onCompletePolicyCalculate(packagesForDescription,policydata);
                    });
                }
              });
          } else {
            this.subPolicyDetails = policyCalculate
              .subscribe(policydata => {
                this.onCompletePolicyCalculate(packagesForDescription,policydata);
              });
          }
        }
      });
    }

    this.subSelectedAgreement = this.srvCustomer.selectedAgreement.subscribe(agreementDetails => {
      if (Object.keys(agreementDetails).length) {
        this.agreementDetails = agreementDetails;
      }
      if (this.agreementDetails === undefined) {
        this.action = Constants.View;
      } else if (previousAction) {
        this.action = previousAction;
      }
      this.checkAgreementChange();
    });
  }

  onCompletePolicyCalculate(packagesForDescription : Packages [],policydata) {
    this.policyData = policydata;
    this.policyData.Term = policydata.Term;
    this.policyData.ProductTermType = policydata.ProductTermType;
    this.policyData.DistributionTypeDescription = Constants.StrCash;
    this.srvQuestionCtrlService.validationDate = new Date(this.agreementDetails.IssueDate);
    this.insuranceQuestions = this.srvQuestionCtrlService.parseQuestion(packagesForDescription,this.policyData.QuestionGroups as QuestionGroup[], []);
    const temp = this.srvQuestionCtrlService.toFormGroup(this.insuranceQuestions, []);
    temp.addControl(Constants.PolicyNumber, new QuestionFormControl(((this.policyResponseData &&
      this.policyResponseData.PolicyNumber) ? this.policyResponseData.PolicyNumber : Constants.Empty)));
    this.frmEditInsuranceGroup = temp;
    this.frmEditInsuranceGroup.FormType = this.action;
    this.onChanges();
  }

  onCompleteGetCustomerPolicy(packagesForDescription : Packages [],policyResponse) {
    
    this.selectedProduct.ProductLink = policyResponse.ProductLink;
    this.selectedProduct.Package = policyResponse.PackageDetails;
    this.selectedProduct.ProductTerm.Term = policyResponse.Term;
    this.selectedProduct.ProductTerm.ProductTermType = policyResponse.ProductTermType;
    this.policyData.StartDate = policyResponse.StartDate;
    this.policyData.EndDate = policyResponse.EndDate;
    this.policyData.Premium = policyResponse.Premium;
    this.policyData.Term = policyResponse.Term;
    this.policyData.ProductTermType = policyResponse.ProductTermType;
    this.policyData.DistributionTypeDescription = policyResponse.DistributionTypeDescription;
    this.policyResponseData = policyResponse;
    const parsedAnswers = this.srvQuestionCtrlService.convertAnswersArray(policyResponse.QuestionAnswersGroups);
    this.insuranceQuestions = this.srvQuestionCtrlService.parseQuestion(packagesForDescription,policyResponse.QuestionGroups, parsedAnswers);
    const temp = this.srvQuestionCtrlService.toFormGroup(this.insuranceQuestions, parsedAnswers);
    this.packageGroupDetails =  new PackagesGroupDetail();
    this.packageGroupDetails.Packages = policyResponse.PolicyDetailsGroup;

    this.selectedProductTerm = {
      ProductTermType: policyResponse.ProductTermType,
      Term:  policyResponse.Term,
      IsActive: true
    };
    this.srvInsurance.setSelectedProductTerm(this.selectedProductTerm as ProductTerm);

    temp.addControl(Constants.PolicyNumber, new QuestionFormControl(policyResponse.PolicyNumber));
    this.frmEditInsuranceGroup = temp;
    this.frmEditInsuranceGroup.FormType = this.action;
    
    if(this.agreementDetails != null){
      this.previousagreementDetails = this.agreementDetails;
      this.previousagreementDetails.Term=policyResponse.Term;
    }
    this.onChanges();
    if (this.action !== Constants.Update) {
      this.frmEditInsuranceGroup.disable();
    }
    this.checkAgreementChange();
    this.currentPackageType = policyResponse.ProductDescription;
  }

  checkAgreementChange() {
    if (this.action === Constants.View || this.action === Constants.Cancel) {
      if (this.policyResponseData !== undefined && this.agreementDetails !== undefined) {
        const policyStartDate = new Date(this.policyResponseData.StartDate);
        if (this.agreementDetails.IssuerId !== this.policyResponseData.IssuingRepresentativeId ||
          new Date(policyStartDate.setDate(policyStartDate.getDate() - 1)).toDateString()
          !== new Date(this.agreementDetails.IssueDate).toDateString() ) {
          this.agreementChange = true;
        } else { this.agreementChange = false; }
      }
    }
  }

  addGroup(groupId, groupIndex) {
    const tempQGB = (this.insuranceQuestions[groupIndex]);
    const tempFG = this.srvQuestionCtrlService.toFormGroupQuestion(tempQGB.Questions, []);
    (<FormArray>this.frmEditInsuranceGroup.controls[groupId]).push(tempFG);
  }

  deleteGroup(groupId, groupIndex) {
    (<FormArray>this.frmEditInsuranceGroup.controls[groupId]).removeAt(groupIndex);
    // delete (<FormArray>this.frmEditInsuranceGroup.controls[groupId]).controls[groupIndex];
  }

  selectedProductforEditEvent(event) {
    if (event.text) {
      this.selectedProductforEdit = event.text;
    }

  }
  saveInsurance(forceSubmit: boolean = false) {    
    this.errorMessageList = [];
    this.srvCustomer.setBusinesExceptionCode(null);
    const policyNumberVal = this.frmEditInsuranceGroup.controls.policyNumber.value.toUpperCase();
    if (!policyNumberVal || policyNumberVal.trim() === Constants.Empty) {
      this.policyError = true;
      this.errorMessageList.push(Constants.ErrorInvalidInsuranceNumber);
    } else {
      if (this.selectedPackage.PolicyNumBasicValidationRule) {
        if (!policyNumberVal.match(this.selectedPackage.PolicyNumBasicValidationRule)) {
          this.policyError = true;
          this.errorMessageList.push(Constants.ErrorPolicyNumberIncorrect);
        }
      } else if (this.selectedProductforEdit && this.selectedProductforEdit.PolicyNumBasicValidationRule) {
        if (!policyNumberVal.match(this.selectedProductforEdit.PolicyNumBasicValidationRule)) {
          this.policyError = true;
          this.errorMessageList.push(Constants.ErrorPolicyNumberIncorrect);
        }
      }
    }

    const validRequiredFields = this.srvQuestionCtrlService.touchElements(this.frmEditInsuranceGroup);
    const validationStatus = (!this.errorMessageList.length && validRequiredFields);

    if ((this.frmEditInsuranceGroup.valid || forceSubmit) && validationStatus) {
      this.mandatoryFieldError = false;
      const requestObj = new ProductUpdate();
      const customerDetails = (this.action === Constants.Update) ?
        this.srvCustomer.agreementSelectedCustomer.getValue() : this.srvCustomer.selectedCustomer.getValue();
      requestObj.Agreement = (this.action === Constants.Update) ?
        _.cloneDeep(this.srvCustomer.agreementselectedAgreement.getValue()) : _.cloneDeep(this.agreementDetails);
      delete requestObj.Agreement[Constants.Insurance];
      requestObj.PolicyNumber = this.frmEditInsuranceGroup.get(Constants.PolicyNumber).value.toUpperCase();      
      this.selectedProductTerm = this.srvInsurance.selectedProductTerm.getValue();
      requestObj.Agreement.Term = this.selectedProductTerm.Term;
      requestObj.Agreement.ProductTermType = this.selectedProductTerm.ProductTermType;
      requestObj.Agreement.DistributionTypeDescription = Constants.StrCash;
      requestObj.QuestionAnswers = this.srvQuestionCtrlService.generateResponse(this.frmEditInsuranceGroup, forceSubmit);
      this.subDeletedChildList = this.srvQuestionCtrlService.deletedChildList.subscribe(deletedChild => {
        deletedChild.forEach(element => {
          const respGroup = new QuestionAnswerGroup;
          respGroup.QuestionGroupId = element[Constants.QuestionGroupId];
          respGroup.Answers = this.srvQuestionCtrlService.generateResponse(element, forceSubmit);
          respGroup.QuestionAnswerGroupId = element[Constants.QuestionAnswerGroupId] ? element[Constants.QuestionAnswerGroupId] : uuid();
          respGroup.Deleted = true;
          requestObj.QuestionAnswers.push(respGroup);
        });
      });
      requestObj.CustomerId = customerDetails.CustomerId;
      requestObj.CustomerDOB = customerDetails.BirthDate;
      const selectedproduct = this.selectedPackage;
      if (selectedproduct && selectedproduct.ProductId) {
       const optpckg = this.getOptionalPackageArray(selectedproduct.PackageGroups);
        const optionalPackage = (selectedproduct.PackageGroups.length > 0) ?
             optpckg : undefined;
        const mandatoryPackage = selectedproduct.MandatoryPackages[0];
        requestObj.SelectedPackages = [];
        if (optionalPackage !== undefined) {
          optionalPackage.forEach(pkg=>{
            delete pkg[Constants.Description];
          });
          optionalPackage.forEach(pkg=>{
            requestObj.SelectedPackages.push(pkg);
          });
        }
        delete mandatoryPackage[Constants.Description];
        requestObj.SelectedPackages.push(mandatoryPackage);
        requestObj.SelectedProduct = { ProductId: selectedproduct.ProductId, Version: selectedproduct.Version };
      } else if (this.policyResponseData && this.policyResponseData.ProductLink && this.policyResponseData.PackageDetails) {
        requestObj.SelectedPackages = this.policyResponseData.PackageDetails;
        requestObj.SelectedProduct = this.policyResponseData.ProductLink;
      }
      requestObj.SkipPolicyNumberValidation = (this.optionalFieldWarnings.includes(Constants.WarningDuplicatePolicyNumber)
        && forceSubmit) ? true : false;
      if (this.action === Constants.Add) {
        const businessWarning = [];
        this.VerifyBusinessValidation(requestObj, businessWarning);

        if (businessWarning.length && !(_.isEqual(businessWarning, this.optionalFieldWarnings) || forceSubmit)) {
          this.showConfirmationBtn = true;
          this.optionalFieldWarnings = [];
          this.optionalFieldWarnings = businessWarning;
          return false;
        }
        this.logWarningDuplicatePolicyNumber(requestObj, this.optionalFieldWarnings);
        this.logWarningCustomerAgeWithInsurancePolicy(requestObj, this.optionalFieldWarnings);
        this.frmEditInsuranceGroup.disable();
        this.frmBtnDisabled = this.frmEditInsuranceGroup.disabled;
        this.frmDisable = true;
        this.subscribeBasedonToken(this.srvCustomer.createPolicy(requestObj));
        this.handlePolicyBusinessException();
      } else if (this.action === Constants.Update) {
        requestObj.PremiumReturn = new ProductReturn();
        const businessWarning = [];
        this.VerifyBusinessValidation(requestObj, businessWarning);
        if (businessWarning.length && !(_.isEqual(businessWarning, this.optionalFieldWarnings) || forceSubmit)) {
          this.showConfirmationBtn = true;
          this.optionalFieldWarnings = [];
          this.optionalFieldWarnings = businessWarning;
          return false;
        }
        this.logWarningDuplicatePolicyNumber(requestObj, this.optionalFieldWarnings);
        this.logWarningCustomerAgeWithInsurancePolicy(requestObj, this.optionalFieldWarnings);
        this.frmEditInsuranceGroup.disable();
        this.frmDisable = true;
        this.frmBtnDisabled = this.frmEditInsuranceGroup.disabled;        
        requestObj.PreviousAgreement = this.previousagreementDetails;
        delete requestObj.PreviousAgreement[Constants.Insurance];
        this.subscribeBasedonToken(this.srvCustomer.updatePolicy(requestObj, this.policyResponseData.PolicyId));
        this.handlePolicyBusinessException();
      }
    } else if (validationStatus) {
      this.showConfirmationBtn = true;
      this.mandatoryFieldError = false;
      const businessWarning = [];
      this.VerifyBusinessValidation(new ProductUpdate, businessWarning);
      this.optionalFieldWarnings = [];
      if (this.action === Constants.Add && businessWarning.length && !_.isEqual(businessWarning, this.optionalFieldWarnings)) {
        this.optionalFieldWarnings = businessWarning;
        this.optionalFieldWarnings.push(Constants.ErrorMissingDetails);
        return false;
      } else {
        this.optionalFieldWarnings.push(Constants.ErrorMissingDetails);
      }
    } else {
      if (this.errorMessageList.length) {
        this.setDefaultFocus();
      }
      this.mandatoryFieldError = true;
    }
    return;
  }

  getOptionalPackageArray(packageGroup) {
    const selectedOptPackages = [];
    packageGroup.forEach(pkg => {
      pkg.Packages.forEach(pckg=>{
        selectedOptPackages.push(pckg);
      });
    });
    return selectedOptPackages;
  }

  getPackageForDescription(newPackage:Packages,assignFrom : Packages){
    newPackage.PackageId=assignFrom.PackageId;
    newPackage.Version=assignFrom.Version;
    newPackage.Description=assignFrom.Description;
    newPackage.IsMandatory=assignFrom.IsMandatory;
    return newPackage;
  }


  // subscribe Based on Token
  subscribeBasedonToken(requestCall) {
    if (this.srvHttpLocale.checkTokenLifeTime()) {
      this.srvHttpLocale.getNewToken()
        .subscribe(token => {
          if (token) {
            this.subPolicyControl = requestCall.subscribe(() => {
              this.router.navigate([Constants.NavLinkLoanAgreement, Constants.Refresh]);
            });
          }
        });
    } else {
      this.subPolicyControl = requestCall.subscribe(() => {
        this.router.navigate([Constants.NavLinkLoanAgreement, Constants.Refresh]);
      });
    }

  }

  // log Business Rules Exceptions for Duplicate Policy Number
  logWarningDuplicatePolicyNumber(requestObj: ProductUpdate, optionalFieldWarnings: any) {
    if (optionalFieldWarnings.includes(Constants.WarningDuplicatePolicyNumber)) {
      if (!requestObj.BusinessRulesExceptions) {
        requestObj.BusinessRulesExceptions = [];
      }
      requestObj.BusinessRulesExceptions.push(Constants.WarningDuplicatePolicyNumberMessage);
    }
  }

  logWarningCustomerAgeWithInsurancePolicy(requestObj: ProductUpdate, optionalFieldWarnings: any) {
    if (optionalFieldWarnings.includes(Constants.WarningCustomerAgeWithInsurancePolicy)) {
      if (!requestObj.BusinessRulesExceptions) {
        requestObj.BusinessRulesExceptions = [];
      }
      requestObj.BusinessRulesExceptions.push(Constants.WarningCustomerAgeWithInsurancePolicy);
    }
  }

  // handle Policy Business Exception
  handlePolicyBusinessException() {
    this.subExceptionCode = this.srvCustomer.businessExceptionCode.subscribe(error => {
      if (error) {
        this.frmDisable = false;
        this.frmEditInsuranceGroup.enable();
        this.policyError = true;
        this.frmBtnDisabled = this.frmEditInsuranceGroup.enabled;
        this.setDefaultFocus();
        if (error.ExceptionCode.charAt(0) === Constants.CheckIfError) {
          if (error.ExceptionCode === Constants.ErrorPolicyPendingStatus) {
            this.displayPendingStatusException(error);
          } else {
            this.displayPolicyErrorException(error.ExceptionCode);
          }
        } else if (error.ExceptionCode.charAt(0) === Constants.CheckIfWarning) {
          this.displayPolicyErrorWarning(error.ExceptionCode);
        }
      }
    });
  }
  // Display Pending Status Exception & Disable the form
  displayPendingStatusException(error?) {
    if (error.text) {
      error = error.text;
    }
    if (error.Message && error.Message.split(Constants.VerticalBar)[0]) {
      this.errorMessageList = [];
      this.pendingStatus = error.Message.split(Constants.VerticalBar)[0].trim();
      this.errorMessageList.push(error.ExceptionCode);
      this.frmDisable = true;
      this.frmEditInsuranceGroup.disable();
      this.policyError = false;
    }
  }

  // Display Policy Error Exception
  displayPolicyErrorException(exceptionCode) {
    this.errorMessageList = [];
    this.showConfirmationBtn = false;
    this.frmBtnDisabled = false;
    this.mandatoryFieldError = true;
    this.errorMessageList.push(exceptionCode);
  }

  // Display Policy Error Warning
  displayPolicyErrorWarning(exceptionCode) {
    this.optionalFieldWarnings = [];
    this.showConfirmationBtn = true;
    this.frmBtnDisabled = false;
    this.optionalFieldWarnings.push(Constants.ErrorMissingDetails);
    this.optionalFieldWarnings.push(exceptionCode);
  }

  handlePolicyAction() {
    if (this.action === Constants.Add || this.action === Constants.Update) {
      this.saveInsurance();
    } else {
      this.frmBtnDisabled = true;
      const policyStatus = new PolicyStatus();
      policyStatus.CustomerId = this.srvCustomer.selectedCustomer.getValue().CustomerId;
      policyStatus.StatusCode = this.action === Constants.Decline ? Constants.Declined : this.action === Constants.Reinstate
        ? Constants.Active : Constants.Empty;
      policyStatus.PremiumReturn = new ProductReturn();
      policyStatus.PremiumReturn.PremiumReturnId = uuid();
      policyStatus.PremiumReturn.PremiumReturnDate = new Date().toDateString();
      policyStatus.PremiumReturn.PremiumReturnType = Constants.NotRequired;
      policyStatus.PremiumReturn.Amount = +this.policyData.Premium;
      policyStatus.PremiumReturn.Status = Constants.NotApplicable;
      policyStatus.PremiumReturn.Representative = null;
      this.subscribeBasedonToken(this.srvCustomer.postPolicyStatus(policyStatus, this.policyResponseData.PolicyId,
        UtilityService.actionHeader(this.action)));
      this.handlePolicyBusinessException();
    }
  }

  setDefaultFocus() {
    this.elmPolicyNumber.nativeElement.focus();
  }

  onChanges(): void {
    this.frmEditInsuranceGroup.valueChanges.subscribe(val => {
      if (!this.frmBtnDisabled) {
        this.showConfirmationBtn = false;
      }
    });
  }

  resetConfirmBtn() {
    this.showConfirmationBtn = false;
    this.optionalFieldWarnings = [];
  }

  VerifyBusinessValidation(requestObject: ProductUpdate, businessWarning) {
    // Max Allowed validation
    requestObject.BusinessRulesExceptions = [];
    const customer = this.srvCustomer.selectedCustomer.getValue();
    this.validatePolicyCount(requestObject, businessWarning);
    if(requestObject!=null)
    {
    if(requestObject.SelectedPackages.length==1)
    {
      this.package=requestObject.SelectedPackages[0];
    }
    else
    {
      this.package=requestObject.SelectedPackages.filter(x => !x.IsMandatory)[0];
    }
    if (customer.BirthDate) {
      const customerAge = this.GetCustomerAge(customer.BirthDate);
      if (!this.ValidateCustomerAge(customerAge, requestObject.SelectedProduct)) {
        businessWarning.push(Constants.ErrorCustomerAge);
      }
      if (!this.ValidateCustomerAge(customerAge, this.package)) {
        businessWarning.push(Constants.ErrorCustomerAge);
      }
    }
  }
  }

  GetCustomerAge(birthdate) {
    const today = new Date(this.policyData.StartDate.toString());
    const birthDate = new Date(birthdate);
    let age = today.getFullYear() - birthDate.getFullYear();
    const m = today.getMonth() - birthDate.getMonth();
    if (m < 0 || (m === 0 && today.getDate() < birthDate.getDate())) {
      age--;
    }
    return age;
  }

  ValidateCustomerAge(customerAge, product) {
    return (product.MinAge == null || customerAge >= product.MinAge) && (product.MaxAge == null || customerAge <= product.MaxAge);
  }

  // check if policy exceeded then the max allowed
  validatePolicyCount(requestObject: ProductUpdate, businessWarning) {
    requestObject.BusinessRulesExceptions = [];
    if (this.selectedPackage && this.selectedPackage.MaxAllowed > 0) {
      this.customer = this.srvCustomer.selectedCustomer.getValue();
      if (this.customer.Insurance && this.customer.Insurance.filter(x => x.SelectedProduct.ProductId === this.selectedPackage.ProductId &&
        x.Status === Constants.Active).length
        >= this.selectedPackage.MaxAllowed) { 
            this.activePolicyCount=this.customer.Insurance.filter(x=> x.Status ===Constants.Active).length; 
            businessWarning.push(Constants.ErrorActivePolicyExceed);
            requestObject.BusinessRulesExceptions.push('For '+  this.customer.CustomerId +' was already sold '+ this.activePolicyCount +' policies. Do you wish to continue?'); 
            businessWarning.push(Constants.ErrorPolicyExceed);      
            requestObject.BusinessRulesExceptions.push('Number of '+ this.selectedPackage.Description + ' greater than ' +
            this.selectedPackage.MaxAllowed + '. Do you wish to continue?');        
      }
    }
  }
  productSelectionChanged(){

  }
  ngOnDestroy() {
    if (this.subSelectedProduct) {
      this.subSelectedProduct.unsubscribe();
    }
    if (this.subCustomerPolicy) {
      this.subCustomerPolicy.unsubscribe();
    }
    if (this.subRoute) {
      this.subRoute.unsubscribe();
    }
    if (this.subPolicyDetails) {
      this.subPolicyDetails.unsubscribe();
    }
    if (this.subPolicyControl) {
      this.subPolicyControl.unsubscribe();
    }
    if (this.subSelectedAgreement) {
      this.subSelectedAgreement.unsubscribe();
    }
    if (this.subDeletedChildList) {
      this.subDeletedChildList.unsubscribe();
    }
    if (this.subExceptionCode) {
      this.subExceptionCode.unsubscribe();
    }
  }

  ShowHeader()
  {
      if (this.action != Constants.Add)
      {
        if(this.packageGroupDetails.Packages.filter(x=> x.Amount >0 ).length > 0)
          return true;
        else
          return false;
      }
  }
}
