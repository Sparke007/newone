import { Component, EventEmitter, Input, OnDestroy, OnInit, Output, ViewChild } from '@angular/core';
import { NgForm } from '@angular/forms';
import { Router } from '@angular/router';
import * as _ from 'lodash';
import { ISubscription } from 'rxjs/Subscription';
import { v4 as uuid } from 'uuid';

import { Constants } from '../../../shared/interfaces/constants';
import { Agreement } from '../../../shared/interfaces/customer.interface';
import { PolicyStatus, ProductReturn, ProductUpdate } from '../../../shared/interfaces/product.interface';
import { CustomerService } from '../../../shared/services/customer.service';
import { HttpLocaleService } from '../../../shared/services/http-locale.service';
import { InsuranceService } from '../../../shared/services/insurance.service';
import { UtilityService } from '../../../shared/services/utility.service';

@Component({
  selector: 'app-insurance-cancel',
  templateUrl: './insurance-cancel.component.html',
  styleUrls: ['./insurance-cancel.component.css']
})
export class InsuranceCancelComponent implements OnInit, OnDestroy {
  @ViewChild(Constants.CancelForm) frmCancelForm: NgForm;

  subPayBackOptions: ISubscription;
  subSelectedAgreement: ISubscription;
  subAgentSearch: ISubscription;
  subPolicyControl: ISubscription;
  subExceptionCode: ISubscription;

  @Input() policyResponseData: any;
  @Input() action: any;
  @Output() errorException = new EventEmitter();
  frmBtnDisabled: boolean;

  payBackOptions: any[];
  agentList: any[];

  selectedpayBack: Object = {};
  selectedAgent: Object = {};
  agreementDetails: Agreement;

  day: string;
  month: string;
  year: string;
  errorMessage: string;
  firstname: string;
  lastname: string;
  idnumber: string;
  amount: string;
  premiumReturnType: string;
  disableform = false;
  isMandatory = false;

  @ViewChild(Constants.PayBackselect) payBackselect: any;

  constructor(private srvCustomer: CustomerService, private srvInsurance: InsuranceService,
    private srvHttpLocale: HttpLocaleService, private router: Router) {
    this.errorMessage = Constants.Empty;
    this.selectedpayBack = Constants.Empty;
    this.firstname = this.lastname = this.idnumber = Constants.Empty;
  }

  ngOnInit() {
    if (this.policyResponseData !== undefined && this.policyResponseData.PremiumReturn !== null && this.action !== Constants.Cancel) {
      const premiumdata = this.policyResponseData.PremiumReturn;
      this.selectedpayBack = this.premiumReturnType = premiumdata.PremiumReturnType;
      const premiumdate = new Date(premiumdata.PremiumReturnDate);
      this.day = UtilityService.pad(2, premiumdate.getDate().toString(), Constants.PadZero);
      this.month = UtilityService.pad(2, (premiumdate.getMonth() + 1).toString(), Constants.PadZero);
      this.year = premiumdate.getFullYear().toString();
      if (premiumdata.PremiumReturnType === Constants.Cash && premiumdata.Representative !== null) {
        this.agentList = [{
          DisplayName: premiumdata.Representative.RepresentativeName
          , RepresentativeId: premiumdata.Representative.RepresentativeId
        }];
        this.selectedAgent = this.agentList[0];
      }
      this.amount = UtilityService.decimalRoundOff(premiumdata.Amount);
      this.isMandatory = (this.action === Constants.UpdateCancel) ? true : false;
    }
    // subscribe pay back drop down options
    this.subPayBackOptions = this.srvInsurance.getPayBackOptions().subscribe(options => {
      this.payBackOptions = options;
    });

    this.subSelectedAgreement = this.srvCustomer.selectedAgreement.subscribe(agreementDetails => {
      this.disableform = false;
      if (Object.keys(agreementDetails).length) {
        this.agreementDetails = agreementDetails;
        this.disableform = (this.action === Constants.Cancel || this.action === Constants.UpdateCancel) ? false : true;
      } else {
        this.disableform = true;
      }
    });

  }

  onSubmit(formValues) {
    this.errorMessage = Constants.Empty;
    // check valid date
    this.inputValidDateCheck(formValues.day, formValues.month, formValues.year);

    if (this.errorMessage === Constants.Empty && this.action === Constants.UpdateCancel && this.selectedpayBack === Constants.Cash
      && this.selectedAgent[Constants.RepresentativeId] === undefined && this.isMandatory) {
      return this.errorMessage = Constants.ErrorInvalidAgent;
    }

    // check if amount is valid or not
    if ((this.errorMessage === Constants.Empty || this.errorMessage === undefined) &&
      ((formValues.amount !== undefined && formValues.amount !== Constants.Empty && formValues.amount !== null) ||
        (this.action === Constants.UpdateCancel && this.isMandatory))) {
      this.inputValidateAmountCheck(formValues.amount);
    }
    // if no error, then redirect to previous page
    if (this.errorMessage === Constants.Empty) {
      const agreement = this.srvCustomer.selectedAgreement.getValue();
      const policyStatus = new PolicyStatus();
      policyStatus.CustomerId = this.srvCustomer.selectedCustomer.getValue().CustomerId;
      policyStatus.StatusCode = Constants.Cancelled;
      policyStatus.PremiumReturn = new ProductReturn();
      policyStatus.PremiumReturn.PremiumReturnId = uuid();
      policyStatus.PremiumReturn.PremiumReturnDate = new Date(formValues.year, formValues.month - 1, formValues.day).toDateString();
      policyStatus.PremiumReturn.PremiumReturnType = this.selectedpayBack.toString();
      policyStatus.PremiumReturn.Amount = (formValues.amount) ? formValues.amount.replace(Constants.Comma, Constants.Dot) : null;
      policyStatus.PremiumReturn.Status = Constants.NotRequired;
      if (this.selectedAgent[Constants.RepresentativeId] !== undefined) {
        policyStatus.PremiumReturn.Representative = {
          RepresentativeId: this.selectedAgent[Constants.RepresentativeId],
          RepresentativeName: this.selectedAgent[Constants.DisplayName]
        };
      } else { policyStatus.PremiumReturn.Representative = null; }

      this.frmBtnDisabled = true;
      if (this.action === Constants.UpdateCancel) {
        const requestObj = new ProductUpdate();
        requestObj.Agreement = _.cloneDeep(agreement);
        const selectedProductTerm = this.srvInsurance.selectedProductTerm.getValue();
        requestObj.Agreement.Term = selectedProductTerm.Term;
        requestObj.Agreement.ProductTermType = selectedProductTerm.ProductTermType;
        delete requestObj.Agreement[Constants.Insurance];
        requestObj.PolicyNumber = this.policyResponseData.PolicyNumber;
        requestObj.CustomerId = policyStatus.CustomerId;
        requestObj.PremiumReturn = policyStatus.PremiumReturn;
        requestObj.SelectedProduct = this.policyResponseData.ProductLink;
        this.subscribeBasedonToken(this.srvCustomer.updatePolicy(requestObj, this.policyResponseData.PolicyId));
        this.handleException();
      } else {
        this.subscribeBasedonToken(this.srvCustomer.postPolicyStatus(policyStatus, this.policyResponseData.PolicyId,
          UtilityService.actionHeader(this.action)));
        this.handleException();
      }
    }
  }

  subscribeBasedonToken(requestCall) {
    if (this.srvHttpLocale.checkTokenLifeTime()) {
      this.srvHttpLocale.getNewToken()
        .subscribe(token => {
          if (token) {
            this.subPolicyControl = requestCall.subscribe(() => {
              this.onComplete();
            });
          }
        });
    } else {
      this.subPolicyControl = requestCall.subscribe(() => {
        this.onComplete();
      });
    }

  }

  onComplete() {
    this.router.navigate([Constants.NavLinkLoanAgreement, Constants.Refresh]);
    this.frmBtnDisabled = false;
  }

  handleException() {
    this.subExceptionCode = this.srvCustomer.businessExceptionCode.subscribe(error => {
      if (error) {
        if (error.ExceptionCode.charAt(0) === Constants.CheckIfError) {
          if (error.ExceptionCode === Constants.ErrorPolicyPendingStatus) {
            this.errorException.emit({ [Constants.Text]: error });
          }
        }
      }
    });
  }

  inputValidateAmountCheck(amount) {
    // check input as number
    if (amount === Constants.Empty || amount === undefined || amount === null ||
      (amount !== null && isNaN(Number(amount.replace(Constants.Comma, Constants.Dot))))) {
      return this.errorMessage = Constants.ErrorInvalidAmount;
    }
    // check amount is less than insurance cost
    const amountvalue = Number(amount.replace(Constants.Comma, Constants.Dot));
    if (amountvalue > (this.policyResponseData.Premium) || amountvalue < 0) {
      return this.errorMessage = Constants.ErrorInvalidAmount;
    }
  }

  onSearchAgent() {
    // validate if correct input's are provided
    this.validateSearchInput();
    // if it's a valid search bind the agent list that has to displayed on the UI
    if (this.errorMessage === undefined || this.errorMessage === Constants.Empty) {
      // subscribe pay back drop down options
      const agentSearch = this.srvInsurance.getAgent(this.idnumber, this.firstname, this.lastname);
      if (this.srvHttpLocale.checkTokenLifeTime()) {
        this.srvHttpLocale.getNewToken()
          .subscribe(token => {
            if (token) {
              this.subAgentSearch = agentSearch.subscribe(options => {
                this.agentSearchCompete(options);
              });
            }
          });
      } else {
        this.subAgentSearch = agentSearch.subscribe(options => {
          this.agentSearchCompete(options);
        });
      }
    } else {
      this.agentList = [];
    }
  }


  agentSearchCompete(options) {
    this.agentList = options;
    // set first value as default selection
    if (this.agentList.length) {
      this.selectAgent(this.agentList[0]);
    } else {
      return this.errorMessage = Constants.ErrorInvalidAgent;
    }

  }

  validateSearchInput() {
    this.errorMessage = Constants.Empty;

    // all fields cannot be blank
    if (this.firstname === undefined && this.lastname === undefined && this.idnumber === undefined) {
      return this.errorMessage = Constants.ErrorInvalidAgent;
    }
    if (this.idnumber !== undefined) {
      this.idnumber = this.idnumber.trim();
      if (this.idnumber !== Constants.Empty) {
        if (isNaN(Number(this.idnumber))) { // check id number is numeric
          return this.errorMessage = Constants.ErrorInvalidAgent;
        }
        // id number in range 10 to 13
        if (!isNaN(Number(this.idnumber)) && (this.idnumber.length < 10 || this.idnumber.length > 13)) {
          return this.errorMessage = Constants.ErrorInvalidAgent;
        }
      }
    }

    if (this.firstname !== undefined) {
      this.firstname = this.firstname.trim();
      if (this.firstname !== Constants.Empty) {
        const checkValidFirstName = UtilityService.validateUserName(this.firstname);
        if (checkValidFirstName !== undefined) {
          return this.errorMessage = Constants.ErrorInvalidAgent;
        }
      }
    }
    if (this.lastname !== undefined) {
      this.lastname = this.lastname.trim();
      if (this.lastname !== Constants.Empty) {
        const checkValidLastName = UtilityService.validateUserName(this.lastname);
        if (checkValidLastName !== undefined) {
          return this.errorMessage = Constants.ErrorInvalidAgent;
        }
      }
    }
    if (this.firstname === Constants.Empty && this.lastname === Constants.Empty && this.idnumber === Constants.Empty) {
      return this.errorMessage = Constants.ErrorInvalidAgent;
    }
  }

  selectAgent(agent) {
    // set the selected agent
    this.selectedAgent = agent;
  }

  inputValidDateCheck(day: number, month: number, year: number) {
    // check valid date
    const checkValidDate = UtilityService.validateDate(day, month, year);
    if (checkValidDate !== undefined && checkValidDate !== Constants.Empty) {
      return this.errorMessage = checkValidDate;
    }
    // check date range for start and end date of insurance
    const checkValidDateRange = UtilityService.validateDateRange(new Date(year, month - 1, day),
      new Date(this.policyResponseData.StartDate), new Date(this.policyResponseData.EndDate));
    if (checkValidDateRange !== undefined && checkValidDateRange !== Constants.Empty) {
      return this.errorMessage = checkValidDateRange;
    }
    // check date range for input date and current date
    const checkValidDateRangeforCurrentDate = UtilityService.validateDateRange(new Date(year, month - 1, day), undefined
      , new Date(new Date().toDateString()));
    if (checkValidDateRangeforCurrentDate !== undefined || checkValidDateRangeforCurrentDate !== Constants.Empty) {
      return this.errorMessage = checkValidDateRangeforCurrentDate;
    }
  }

  payBackSelection() {
    const selectedpayback = this.selectedpayBack;
    // reset all form values
    this.frmCancelForm.reset();
    this.errorMessage = Constants.Empty;
    this.agentList = [];
    this.selectedpayBack = selectedpayback;
    this.isMandatory = (selectedpayback === this.premiumReturnType);
  }

  onInputEntry(event, nextInput) {
    const input = event.target;
    if (input.value.length >= input.attributes.maxlength.value) {
      nextInput.focus();
    }
  }

  ngOnDestroy(): void {
    if (this.subPayBackOptions) {
      this.subPayBackOptions.unsubscribe();
    }
    if (this.subSelectedAgreement) {
      this.subSelectedAgreement.unsubscribe();
    }
    if (this.subPolicyControl) {
      this.subPolicyControl.unsubscribe();
    }
    if (this.subAgentSearch) {
      this.subAgentSearch.unsubscribe();
    } if (this.subExceptionCode) {
      this.subExceptionCode.unsubscribe();
    }
  }
}
