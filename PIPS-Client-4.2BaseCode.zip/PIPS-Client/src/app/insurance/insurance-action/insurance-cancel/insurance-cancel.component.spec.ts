import { ComponentFixture, TestBed } from '@angular/core/testing';
import { NO_ERRORS_SCHEMA } from '@angular/core';
import { Location } from '@angular/common';
import { ActivatedRoute } from '@angular/router';
import { Router } from '@angular/router';
import { CustomerService } from '../../../shared/services/customer.service';
import { InsuranceService } from '../../../shared/services/insurance.service';
import { InsuranceCancelComponent } from './insurance-cancel.component';
import { SharedModule } from '../../../shared/shared.module';
import { Insurance } from '../../../shared/interfaces/insurance.interface';

describe('InsuranceCancelComponent', () => {
  let comp: InsuranceCancelComponent;
  let fixture: ComponentFixture<InsuranceCancelComponent>;

  beforeEach(() => {
    const locationStub = {
      back: () => ({})
    };
    const activatedRouteStub = {
      params: {
        subscribe: () => ({})
      }
    };
    const routerStub = {
      navigate: () => ({})
    };
    const customerServiceStub = {
      selectedAgreement: {
        subscribe: () => ({})
      }
    };
    const insuranceServiceStub = {
      getPayBackOptions: () => ({
        subscribe: () => ({})
      }),
      getAgent: () => ({
        subscribe: () => ({})
      })
    };
    TestBed.configureTestingModule({
      declarations: [InsuranceCancelComponent],
      schemas: [NO_ERRORS_SCHEMA],
      providers: [
        { provide: Location, useValue: locationStub },
        { provide: ActivatedRoute, useValue: activatedRouteStub },
        { provide: Router, useValue: routerStub },
        { provide: CustomerService, useValue: customerServiceStub },
        { provide: InsuranceService, useValue: insuranceServiceStub }
      ],
      imports: [SharedModule]
    });
    fixture = TestBed.createComponent(InsuranceCancelComponent);
    comp = fixture.componentInstance;
  });

  it('can load instance', () => {
    expect(comp).toBeTruthy();
  });
  describe('inputValidateAmountCheck', () => {
    it('blank input', () => {
      comp.inputValidateAmountCheck('');
      expect(comp.errorMessage).toEqual('INVALID_AMOUNT');
    });
    it('string as input', () => {
      comp.inputValidateAmountCheck('abc');
      expect(comp.errorMessage).toEqual('INVALID_AMOUNT');
    });
    it('amount  greater than insurance cost', () => {
      comp.insurance = new Insurance();
      comp.insurance.Cost = 123;
      comp.inputValidateAmountCheck('124');
      expect(comp.errorMessage).toEqual('INVALID_AMOUNT');
    });
    it('amount  less than insurance cost', () => {
      comp.insurance = new Insurance();
      comp.insurance.Cost = 123.00;
      comp.inputValidateAmountCheck('122,00');
      expect(comp.errorMessage).toEqual('');
    });
  });
  xdescribe('ngOnInit', () => {
    it('makes expected calls', () => {
      const routerStub: Router = fixture.debugElement.injector.get(Router);
      const insuranceServiceStub: InsuranceService = fixture.debugElement.injector.get(InsuranceService);
      spyOn(routerStub, 'navigate');
      spyOn(insuranceServiceStub, 'getPayBackOptions');
      comp.ngOnInit();
      expect(routerStub.navigate).toHaveBeenCalled();
      expect(insuranceServiceStub.getPayBackOptions).toHaveBeenCalled();
    });
  });

  describe('onSearchAgent', () => {
    it('makes expected calls', () => {
      comp.errorMessage = '';
      spyOn(comp, 'validateSearchInput');
      comp.onSearchAgent();
      expect(comp.validateSearchInput).toHaveBeenCalled();
    });
    it('agent list []', () => {
      comp.errorMessage = 'ERROR';
      comp.onSearchAgent();
      expect(comp.agentList).toEqual([]);
    });
  });

  describe('validateSearchInput', () => {
    it('blank input', () => {
      comp.firstname = comp.lastname = comp.idnumber = undefined;
      comp.validateSearchInput();
      expect(comp.errorMessage).toEqual('INVALID_AGENT');
    });
    it('id number non numeric', () => {
      comp.idnumber = 'abc';
      comp.validateSearchInput();
      expect(comp.errorMessage).toEqual('INVALID_AGENT');
    });
    it('id number numeric less than 10 digit', () => {
      comp.idnumber = '123456789';
      comp.validateSearchInput();
      expect(comp.errorMessage).toEqual('INVALID_AGENT');
    });
    it('id number numeric greater than 13 digit', () => {
      comp.idnumber = '12345678912345';
      comp.validateSearchInput();
      expect(comp.errorMessage).toEqual('INVALID_AGENT');
    });
    it('valid id number numeric', () => {
      comp.idnumber = '12345678900';
      comp.validateSearchInput();
      expect(comp.errorMessage).toEqual('');
    });
    it('First name check with blank', () => {
      comp.firstname = '';
      comp.validateSearchInput();
      expect(comp.errorMessage).toEqual('INVALID_AGENT');
    });
    it('First name check', () => {
      comp.firstname = '123';
      comp.validateSearchInput();
      expect(comp.errorMessage).toEqual('INVALID_AGENT');
    });
    it('First name check valid', () => {
      comp.firstname = 'abc';
      comp.validateSearchInput();
      expect(comp.errorMessage).toEqual('');
    });
    it('Last name check with blank', () => {
      comp.lastname = '';
      comp.validateSearchInput();
      expect(comp.errorMessage).toEqual('INVALID_AGENT');
    });
    it('Last name check', () => {
      comp.lastname = '123';
      comp.validateSearchInput();
      expect(comp.errorMessage).toEqual('INVALID_AGENT');
    });
    it('last name check valid', () => {
      comp.lastname = 'xyz';
      comp.validateSearchInput();
      expect(comp.errorMessage).toEqual('');
    });
  });

  describe('selectAgent', () => {
    it('set selected agent', () => {
      comp.selectAgent('123456');
      expect(comp.selectedAgent).toEqual('123456');
    });
  });

  describe('payBackSelection', () => {
    it('payback selection to cash', () => {
      comp.selectedpayBack = [{ 'code': 'cash' }][0];
      comp.firstname = 'abc';
      comp.payBackSelection();
      expect(comp.firstname).toEqual('');
    });
    it('payback selection to bank', () => {
      comp.selectedpayBack = [{ 'code': 'bank' }][0];
      comp.firstname = 'abc';
      comp.payBackSelection();
      expect(comp.firstname).toEqual('abc');
    });
  });

  describe('inputValidDateCheck', () => {
    it('invalid input date', () => {
      comp.inputValidDateCheck(2, 13, 1234);
      expect(comp.errorMessage).toEqual('INPUT_DATE_INVALID');
    });
    it('valid input date', () => {
      comp.insurance = new Insurance();
      this.date = new Date();
      comp.insurance.StartDate = new Date().toDateString();
      comp.insurance.EndDate = new Date().toDateString();
      comp.inputValidDateCheck(this.date.getDate(), this.date.getMonth() + 1, this.date.getFullYear());
      expect(comp.errorMessage).toEqual('');
    });
    it('invalid input date range', () => {
      comp.insurance = new Insurance();
      this.date = new Date();
      comp.insurance.StartDate = this.date.setDate(this.date.getDate() - 3);
      comp.insurance.EndDate = (this.date.setDate(this.date.getDate() + 30));
      comp.inputValidDateCheck(this.date.getDate(), this.date.getMonth() + 1, this.date.getFullYear() + 1);
      expect(comp.errorMessage).toEqual('DATE_RANGE_INVALID');
    });
  });

  describe('onSubmit', () => {
    it('input date instance called', () => {
      spyOn(comp, 'inputValidDateCheck');
      comp.onSubmit({});
      expect(comp.inputValidDateCheck).toHaveBeenCalled();
    });
    it('input amount check  instance called', () => {
      spyOn(comp, 'inputValidateAmountCheck');
      this.date = new Date();
      comp.insurance = new Insurance();
      comp.insurance.StartDate = new Date().toDateString();
      comp.insurance.EndDate = new Date().toDateString();

      comp.errorMessage = '';
      const formvalues = {
        day: this.date.getDate(),
        month: this.date.getMonth() + 1,
        year: this.date.getFullYear()
      };
      comp.onSubmit(formvalues);
      expect(comp.inputValidateAmountCheck).toHaveBeenCalled();
    });
  });
});
