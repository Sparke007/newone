import { Component, OnDestroy, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { ISubscription } from 'rxjs/Subscription';

import { CustomerService } from '../../shared/services/customer.service';

@Component({
  selector: 'app-insurance-wrapper',
  templateUrl: './insurance-wrapper.component.html',
  styleUrls: ['./insurance-wrapper.component.css']
})
export class InsuranceWrapperComponent implements OnInit, OnDestroy {

  subSelectedCustomer: ISubscription;
  customerSelected = false;
  // @ViewChild('insuranceFormHost', { read: ViewContainerRef }) insuranceFormHost;

  constructor(private srvCustomer: CustomerService,
    private activatedRoute: ActivatedRoute,
    private router: Router
  ) {
  }

  ngOnInit() {
    this.activatedRoute.firstChild.params.subscribe(params => {
     /*  this.srvCustomer.getCustomerPolicy(params.policyId).subscribe(customerPolicy => {
      }); */
    });
    this.subSelectedCustomer = this.srvCustomer.selectedCustomer.subscribe(selectedCustomer => {
      this.customerSelected = false;
      if (isNaN(selectedCustomer.CustomerId)) {
      } else {
        this.customerSelected = true;
      }
    });
  }

  loadComponent(componentName: any): any {
  }

  ngOnDestroy() {
    this.subSelectedCustomer.unsubscribe();
  }
}
