import { Location } from '@angular/common';
import { NO_ERRORS_SCHEMA } from '@angular/core';
import { ComponentFactoryResolver } from '@angular/core';
import { ComponentFixture, TestBed } from '@angular/core/testing';

import { InsuranceService } from '../../shared/services/insurance.service';
import { InsuranceWrapperComponent } from './insurance-wrapper.component';

describe('InsuranceWrapperComponent', () => {
    let comp: InsuranceWrapperComponent;
    let fixture: ComponentFixture<InsuranceWrapperComponent>;

    beforeEach(() => {
        const componentFactoryResolverStub = {
            resolveComponentFactory: () => ({})
        };
        const locationStub = {
            back: () => ({})
        };
        const insuranceServiceStub = {
            selectedProduct: {
                subscribe: () => ({}),
                next: () => ({})
            }
        };
        TestBed.configureTestingModule({
            declarations: [ InsuranceWrapperComponent ],
            schemas: [ NO_ERRORS_SCHEMA ],
            providers: [
                { provide: ComponentFactoryResolver, useValue: componentFactoryResolverStub },
                { provide: Location, useValue: locationStub },
                { provide: InsuranceService, useValue: insuranceServiceStub }
            ]
        });
        fixture = TestBed.createComponent(InsuranceWrapperComponent);
        comp = fixture.componentInstance;
    });

    xit('can load instance', () => {
        expect(comp).toBeTruthy();
    });

    describe('ngOnInit', () => {
        xit('makes expected calls', () => {
            spyOn(comp, 'loadComponent');
            comp.ngOnInit();
            expect(comp.loadComponent).toHaveBeenCalled();
        });
    });
});
