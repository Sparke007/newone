import { AfterViewInit, Component, EventEmitter, OnDestroy, OnInit, Output } from '@angular/core';
import { NavigationStart, Router } from '@angular/router';
import { ISubscription } from 'rxjs/Subscription';

import { Constants } from '../../shared/interfaces/constants';
import { Agreement, Customer } from '../../shared/interfaces/customer.interface';
import { CustomerService } from '../../shared/services/customer.service';
import { HttpLocaleService } from '../../shared/services/http-locale.service';
import { UtilityService } from '../../shared/services/utility.service';


@Component({
    selector: 'app-agreement-search',
    templateUrl: './agreement-search.component.html',
    styleUrls: ['./agreement-search.component.css']
})
export class AgreementSearchComponent implements OnInit, OnDestroy, AfterViewInit {

    @Output() errorMessage = new EventEmitter();
    @Output() frmBtnReadOnly = new EventEmitter();
    isToggled = false;
    agreementNumber: string = Constants.Empty;
    subAgreementNum: ISubscription;
    agreementError: Boolean = false;
    searchedAgreementCustomer: Customer[];
    previousCustomer: Customer;
    previousAgreement: Agreement;
    previousCustomerList: Customer[];
    subRoute: ISubscription;
    isCatieAgreement : Boolean = false;

    constructor(private srvCustomer: CustomerService, private srvHttpLocale: HttpLocaleService,  private router: Router) { }

    ngOnInit() {
        this.previousCustomer = this.srvCustomer.selectedCustomer.getValue();
        this.srvCustomer.agreementSetSelectedCustomer(this.previousCustomer);
        this.previousAgreement = this.srvCustomer.selectedAgreement.getValue();
        this.srvCustomer.agreementSetSelectedAgreement(this.previousAgreement); // Select First Agreement
        this.previousCustomerList = this.srvCustomer.customerList.getValue();
        this.isCatieAgreement = UtilityService.isCatieAgreement(this.previousAgreement.AgreementId);
    }

    ngAfterViewInit(): void {
        this.subRoute = this.router.events
            .subscribe((event) => {
                if (event instanceof NavigationStart) {
                    if (event.url.includes(Constants.NavLinkLoanAgreement)) {
                        this.srvCustomer.selectedCustomer.next(this.srvCustomer.mapAgreementAndInsurance(this.previousCustomer));
                    }
                }
            });
    }

    toggle() {
        this.isToggled = !this.isToggled;
    }

    // Disable Confirm button based on Agreement Number textbox
    onAgreementInput(searchValue: string) {
        if (!searchValue) {
            this.frmBtnReadOnly.emit(false);
        } else {
            this.frmBtnReadOnly.emit(true);
        }
    }

    // Search for the new agreement
    agreementSearch() {
        const agreementNumber = this.agreementNumber;
        this.agreementError = false;
        this.errorMessage.emit({ [Constants.Text]: Constants.Empty });
        // Check if valid agreement no.
        if (!agreementNumber || agreementNumber.length < Constants.AgreementLengthCheck || isNaN(Number(agreementNumber))) {
            this.errorMessage.emit({ [Constants.Text]: Constants.ErrorAgreementNumber });
            this.agreementError = true;
        } else if (agreementNumber) {
            this.srvHttpLocale.subscribeBasedonToken(this.srvCustomer.getCustomerByPIN(Constants.Empty, agreementNumber));
            this.subAgreementNum = this.srvCustomer.customerList.subscribe(customerList => {
                this.errorMessage.emit({ [Constants.Text]: Constants.Empty });
                this.searchedAgreementCustomer = [];
                this.agreementError = false;
                if (this.previousCustomerList !== customerList) {
                    if (customerList && customerList.length && customerList.filter(x => x.Agreements).length > 0) {
                        // Filter out agreemnets whose contractual term is expired
                        customerList.forEach(x => {
                            x.Agreements = x.Agreements
                            .filter(y => Date.parse(y.EndDate) >= new Date().setHours(0,0,0,0));
                        });
                        customerList = customerList.filter(x => x.Agreements.length > 0);
                        if (customerList.length === 0 || (customerList.filter(x => x.Agreements).length = 0)) {
                            this.showError();
                        } else {
                            if (customerList.length > 1) {
                                this.isToggled = true;
                            }
                            this.searchedAgreementCustomer = customerList;
                            this.selectCustomer(0);
                        }

                    } else {
                        this.showError();
                    }
                }
            });
        }
    }

    showError() {
        this.agreementError = true;
        window.scrollTo(0, 500);
        this.frmBtnReadOnly.emit(true);
        this.srvCustomer.agreementSetSelectedCustomer(this.previousCustomer);
        this.srvCustomer.agreementSetSelectedAgreement(this.previousAgreement);
        this.errorMessage.emit({ [Constants.Text]: Constants.ErrorAgreementNotFound });
    }

    selectCustomer(customerIndex) {
        this.frmBtnReadOnly.emit(false); // Enable confirm button
        this.srvCustomer.agreementSetSelectedCustomer(this.searchedAgreementCustomer[customerIndex]);
        this.srvCustomer.agreementSetSelectedAgreement(this.searchedAgreementCustomer[customerIndex].Agreements[0]);

    }

    ngOnDestroy() {
        if (this.subAgreementNum) {
            this.subAgreementNum.unsubscribe();
        }
        if (this.subRoute) {
            this.subRoute.unsubscribe();
        }
    }
}
