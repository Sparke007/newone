import { ComponentFixture, TestBed } from '@angular/core/testing';
import { NO_ERRORS_SCHEMA } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { Router } from '@angular/router';
import { InsuranceService } from '../../shared/services/insurance.service';
import { CustomerService } from '../../shared/services/customer.service';
import { InsurancePackageComponent } from './insurance-package.component';

describe('InsurancePackageComponent', () => {
    let comp: InsurancePackageComponent;
    let fixture: ComponentFixture<InsurancePackageComponent>;

    beforeEach(() => {
        const activatedRouteStub = {};
        const routerStub = {};
        const insuranceServiceStub = {
            getProducts: () => ({
                subscribe: () => ({})
            }),
            setSelectedProduct: () => ({})
        };
        const customerServiceStub = {
            selectedAgreement: {
                subscribe: () => ({})
            }
        };
        TestBed.configureTestingModule({
            declarations: [ InsurancePackageComponent ],
            schemas: [ NO_ERRORS_SCHEMA ],
            providers: [
                { provide: ActivatedRoute, useValue: activatedRouteStub },
                { provide: Router, useValue: routerStub },
                { provide: InsuranceService, useValue: insuranceServiceStub },
                { provide: CustomerService, useValue: customerServiceStub }
            ]
        });
        fixture = TestBed.createComponent(InsurancePackageComponent);
        comp = fixture.componentInstance;
    });

    it('can load instance', () => {
        expect(comp).toBeTruthy();
    });

    it('packageGroup defaults to: []', () => {
        expect(comp.packageGroup).toEqual([]);
    });

    it('mandatoryPackage defaults to: []', () => {
        expect(comp.mandatoryPackage).toEqual([]);
    });

    describe('ngOnInit', () => {
        xit('makes expected calls', () => {
            const insuranceServiceStub: InsuranceService = fixture.debugElement.injector.get(InsuranceService);
            spyOn(comp, 'filterSubtype');
            spyOn(insuranceServiceStub, 'getProducts');
            comp.ngOnInit();
            expect(comp.filterSubtype).toHaveBeenCalled();
            expect(insuranceServiceStub.getProducts).toHaveBeenCalled();
        });
    });

    describe('subtypeSelected', () => {
        it('makes expected calls', () => {
            spyOn(comp, 'enableSelectInsuranceBtn');
            spyOn(comp, 'resetPackages');
            comp.subtypeSelected();
            expect(comp.enableSelectInsuranceBtn).toHaveBeenCalled();
            expect(comp.resetPackages).toHaveBeenCalled();
        });
    });

    describe('optionsSelected', () => {
        it('makes expected calls', () => {
            spyOn(comp, 'filterSubtype');
            spyOn(comp, 'enableSelectInsuranceBtn');
            comp.optionsSelected();
            expect(comp.filterSubtype).toHaveBeenCalled();
            expect(comp.enableSelectInsuranceBtn).toHaveBeenCalled();
        });
    });
    describe('setSelectedProduct', () => {
        it('makes expected calls', () => {
            comp.selectedSubtype = {
                ProductId: 3,
                PackageGroups: [{
                    Packages: []
                }]
            };
            comp.selectedPackageGroup = 'Child';

            const insuranceServiceStub: InsuranceService = fixture.debugElement.injector.get(InsuranceService);
            spyOn(insuranceServiceStub, 'setSelectedProduct');
            comp.setSelectedProduct();
            expect(insuranceServiceStub.setSelectedProduct).toHaveBeenCalled();
        });
    });

    describe('enableSelectInsuranceBtn', () => {
        it('select button status should be active when all dropdowns selected', () => {
            comp.enableSelectInsuranceBtn('Group', 'Medical');
            expect(comp.enableSelectInsurance).toBeTruthy();
        });

        it('select button status should be disabled when any of dropdowns not selected', () => {
            comp.enableSelectInsuranceBtn('Group', '');
            expect(comp.enableSelectInsurance).toBeFalsy();
        });
    });

    describe('optionsSelected', () => {
        it('when called should filter sub types and make select button active', () => {
            spyOn(comp, 'filterSubtype');
            spyOn(comp, 'enableSelectInsuranceBtn');

            comp.optionsSelected();

            expect(comp.filterSubtype).toHaveBeenCalled();
            expect(comp.enableSelectInsuranceBtn).toHaveBeenCalled();
        });

    });
    describe('resetPackages', () => {
        it('should reset package group and mandatory packages', () => {

            comp.resetPackages();

            expect(comp.packageGroup).toEqual([]);
            expect(comp.mandatoryPackage).toEqual([]);
        });

    });

});
