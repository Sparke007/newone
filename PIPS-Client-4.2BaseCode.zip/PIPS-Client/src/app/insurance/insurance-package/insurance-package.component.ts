import { Component, EventEmitter, Input, OnInit, Output, ViewChild } from '@angular/core';
import { OnDestroy } from '@angular/core/src/metadata/lifecycle_hooks';
import * as _ from 'lodash';
import { ISubscription } from 'rxjs/Subscription';

import { Constants } from '../../shared/interfaces/constants';
import { Product, ProductTerm, Values } from '../../shared/interfaces/product.interface';
import { CustomerService } from '../../shared/services/customer.service';
import { HttpLocaleService } from '../../shared/services/http-locale.service';
import { InsuranceService } from '../../shared/services/insurance.service';
import {Agreement} from '../../shared/interfaces/customer.interface'

@Component({
  selector: 'app-insurance-package',
  templateUrl: './insurance-package.component.html',
  styleUrls: ['./insurance-package.component.css']
})
export class InsurancePackageComponent implements OnInit, OnDestroy {

  productTypes: any[];
  salesModel: Values[] = [];
  productDescription: any[] = [];
  productTerm: any[] = [];
  filteredSaleModelProduct: any[];
  subType: Values[] = [];
  productsData: any[];
  packageGroup: any[] = [];
  mandatoryPackage: any[] = [];
  errorMessageList = [];
  filterProperties: any[] = [];

  selectedProductType: Object = {};
  selectedSalesModel: Object = {};
  selectedDescription: Object = {};
  selectedSubType: Object = {};
  selectedProductTerm: Object = {};
  selectedPackageGroup: any[] = [];

  enableSelectInsurance: boolean;
  selectedPackages: any[] = [];
  selectedProductData: Product;
  initialupdateLoad = false;

  subProducts: ISubscription;
  subSelectedAgreement: ISubscription;
  agreementData: Agreement;

  @Input() action: any;
  @Input() selectedProduct: any;
  @Output() selectedProductforEdit = new EventEmitter();
  @Output() changeProduct = new EventEmitter();

  @ViewChild(Constants.Productselect) Productselect: any;

  constructor(private srvInsurance: InsuranceService, private srvCustomer: CustomerService, private srvHttpLocale: HttpLocaleService) {
    this.selectedSalesModel = this.selectedDescription =  this.selectedSubType = this.selectedProductTerm = Constants.Empty;
    this.selectedPackageGroup = [];
    this.enableSelectInsurance = false;
  }

  ngOnInit() {
    this.Productselect.nativeElement.focus();

    if (this.action === Constants.Update) {
      this.subSelectedAgreement = this.srvCustomer.agreementselectedAgreement.subscribe(agreementDetails => {
        if(Object.keys(agreementDetails).length) {
          this.checkAgreementWarningMessage(agreementDetails);
          this.agreementData = agreementDetails;

          this.refreshProductList(this.agreementData.IssueDate);

          if (this.errorMessageList.length) {
            window.scrollTo(0, 0);
          } else {
            window.scrollTo(0, 500);
          }
        }
      });
    } else {
      this.subSelectedAgreement = this.srvCustomer.selectedAgreement.subscribe(agreementDetails => {

        if(Object.keys(agreementDetails).length) {
          this.checkAgreementWarningMessage(agreementDetails);
          this.agreementData = agreementDetails;
          this.refreshProductList(this.agreementData.IssueDate);
        }
      });
    }
  }

  refreshProductList(issueDate) {
    if (this.srvHttpLocale.checkTokenLifeTime())
    {
      this.srvHttpLocale.getNewToken()
        .subscribe(token => {
          if (token) {
            this.subProducts = this.srvInsurance.getProducts(issueDate).subscribe(options => {
              this.onCompleteProductGet(options);
            });
          }
        });
    } else {
      this.subProducts = this.srvInsurance.getProducts(issueDate).subscribe(options => {
        this.onCompleteProductGet(options);
      });
    }
  }

  checkAgreementWarningMessage(agreementDetails) {
    if (Object.keys(agreementDetails).length > 0) {
      this.errorMessageList = [];
      if (agreementDetails.AgreementStatus && agreementDetails.AgreementStatus !== Constants.Active) {
        this.errorMessageList.push(Constants.InActiveAgreement);
      }
      // if (agreementDetails.ProductDescription && agreementDetails.ProductDescription.includes(Constants.IsWithInsurance)) {
      //   this.errorMessageList.push(Constants.ErrorWithoutInsurance);
      // }
    }
  }

  onCompleteProductGet(data) {

    this.productsData = data.Products;
    this.filterProperties = data.FilterProperties;
    const selectedProductLink = this.selectedProduct.ProductLink;
    this.selectedPackages = this.selectedProduct.Package;
    if (this.action === Constants.Update) {
      this.initialupdateLoad = true;
    }
    const productData = this.productsData.filter(x => x.ProductId === selectedProductLink.ProductId
      && x.Version === selectedProductLink.Version);
    if (productData && productData[0]) {
      this.selectedProductData = productData[0];
      this.selectedProductforEdit.emit({ [Constants.Text]: productData[0] });
    }
    this.loadInsuranceType(data);
  }
  // Fill Insurance type dropdown
  loadInsuranceType(data) {
    data.FilterProperties.forEach(filterdata => {
      if (filterdata.Code === Constants.Type) {
        this.productTypes = filterdata.Values;
        if (this.selectedProductData) {
          const productype = filterdata.Values.filter(x => this.selectedProductData.PropertyValues
            .some(y => x.Code === y.PropertyValueCode));
          if (productype && productype[0]) {
            this.selectedProductType = productype[0];
          }
        } else {
          this.selectedProductType = filterdata.Values.length > 0 ? filterdata.Values[0] : Constants.Empty;
        }
        if (this.selectedProductType) {
          this.salesModel = this.loadSalesModel(data);
        }
      }
    });
  }

  // Fill Sales Model type dropdown
  loadSalesModel(data) {
    const salesModelList: Values[] = [];
    const filtersalesmodel = this.filterProperties.filter(x => x.Code === Constants.SalesModel);
    data.Products.forEach(elem => {
      elem.PropertyValues.forEach(property => {
        if (property.PropertyCode === Constants.SalesModel && !salesModelList.some(x => x.Code === property.PropertyValueCode)
          && filtersalesmodel && filtersalesmodel[0]) {
          const description = filtersalesmodel[0].Values.filter(x => x.Code === property.PropertyValueCode);
          if (description && description[0]) {
            salesModelList.push(description[0]);
          }
        }
      });
    });
    if (this.selectedProductData) {
      const salesmodel = salesModelList.filter(x => this.selectedProductData.PropertyValues
        .some(y => x.Code === y.PropertyValueCode));
      if (salesmodel && salesmodel[0]) {
        this.selectedSalesModel = salesmodel[0];
      }
      this.salesModelSelected();
    }
    return salesModelList;
  }

  // Event when Insurance - Type is selected
  insuranceTypeSelected() {
    this.selectedDescription = this.selectedSubType = Constants.Empty;
    this.productDescription = this.selectedPackageGroup = [];
    this.productTerm = [];
    this.selectedProductTerm = Constants.Empty;
    this.resetPackages();
  }



  // Event when Sales Model is selected
  salesModelSelected() {
    // Filter Products based on Sales Model & Subtype selection
    this.subType = [];
    this.filteredSaleModelProduct = [];
    // Get Products based on Sales Model Selection
    this.filteredSaleModelProduct = this.getProductsBasedonPropertyValueCode(this.productsData, this.selectedSalesModel[Constants.Code]);
    this.selectedDescription = this.selectedSubType = Constants.Empty;
    this.productDescription = this.selectedPackageGroup = [];
    this.productTerm = [];
    this.selectedProductTerm = Constants.Empty;
    this.resetPackages();

    // Fill Subtype Dropdown
    this.subType = this.loadSubType(this.filteredSaleModelProduct);
    this.enableSelectInsuranceBtn(this.selectedSalesModel[Constants.Code],
      this.selectedSubType[Constants.Code], this.selectedDescription[Constants.Description],
      this.selectedProductTerm[Constants.Code]);
  }

  // Fill Subtype Dropdown
  loadSubType(filteredProduct) {
    const subTypeList: Values[] = [];
    const filtersubType = this.filterProperties.filter(x => x.Code === Constants.SubType);

    filteredProduct.forEach(data => {
      data.PropertyValues.forEach(property => {
        if (property.PropertyCode === Constants.SubType && !subTypeList.some(x => x.Code === property.PropertyValueCode) && filtersubType && filtersubType[0]) {
          const description = filtersubType[0].Values.filter(x => x.Code === property.PropertyValueCode);
          if (description && description[0]) {
            subTypeList.push(description[0]);
          }
        }
      });
    });
    if (this.selectedProductData) {
      const subtype = subTypeList.filter(x => this.selectedProductData.PropertyValues
        .some(y => x.Code === y.PropertyValueCode));
      if (subtype && subtype[0]) {
        this.selectedSubType = subtype[0];
      }
      this.subtypeSelected();
    }
    return subTypeList;
  }

  // Get Products Based on PropertyValueCode
  getProductsBasedonPropertyValueCode(products: any, valuecode: string) {
    const filterProduct: any[] = [];
    products.forEach(data => {
      data.PropertyValues.forEach(description => {
        if (description.PropertyValueCode === valuecode) {
          filterProduct.push(data);
        }
      });
    });
    return filterProduct;
  }

  // Event when Sub-Type is selected
  subtypeSelected(event?) {
    if (event) {
      this.initialupdateLoad = false;
    }
    // Fill Description drop-down based on subtype selection
    this.productDescription = this.getProductsBasedonPropertyValueCode(this.filteredSaleModelProduct, this.selectedSubType[Constants.Code]);
    if (this.productDescription.length > 0 && this.initialupdateLoad) {
      this.selectedDescription = this.selectedProductData;
      this.productTerm = [];
      this.descriptionSelected();
    } else {
      this.selectedDescription = Constants.Empty;
      this.selectedProductTerm = Constants.Empty;
      this.resetPackages();
    }
    this.enableSelectInsuranceBtn(this.selectedSalesModel[Constants.Code], this.selectedSubType[Constants.Code],
      this.selectedDescription[Constants.Description], this.selectedProductTerm[Constants.Code]);
  }

  // Event when Description is selected
  descriptionSelected() {
    this.enableSelectInsuranceBtn(this.selectedSalesModel[Constants.Code], this.selectedSubType[Constants.Code],
      this.selectedDescription[Constants.Description], this.selectedProductTerm[Constants.Term]);
    this.resetPackages();
    if(this.selectedDescription)
    {
      this.productTerm = this.selectedDescription[Constants.ProductTerms];
      if (this.selectedProduct.ProductTerm && this.initialupdateLoad) {
        const terms = this.selectedProductData.ProductTerms.filter(x =>x.Term === this.selectedProduct.ProductTerm.Term
          && x.ProductTermType === this.selectedProduct.ProductTerm.ProductTermType);
        if (terms && terms[0]) {
          this.selectedProductTerm =terms[0];
        }
        else{
          // Add selected product term if missing incase of created policy's product term is deactivated after policy issue
          this.selectedProductTerm = {
            ProductTermType: this.selectedProduct.ProductTerm.ProductTermType,
            Term:  this.selectedProduct.ProductTerm.Term,
            IsActive: true
          };
          this.productTerm.push(this.selectedProductTerm);
        }
        this.productTermSelected();
      } else {
        this.selectedProductTerm = Constants.Empty;
        this.resetPackages();
      }
      this.srvInsurance.setSelectedProductTerm(this.selectedProductTerm as ProductTerm);
      this.productTerm.sort((a,b)=> a.ProductTermType.localeCompare(b.ProductTermType) || (a.Term - b.Term));
    }
  }

  // Event when Product Term is selected
  productTermSelected(){
    this.enableSelectInsuranceBtn(this.selectedSalesModel[Constants.Code], this.selectedSubType[Constants.Code],
      this.selectedDescription[Constants.Description], this.selectedProductTerm[Constants.Code]);
    this.resetPackages();
    if (this.selectedProductTerm !== Constants.Empty && this.selectedProductTerm !== undefined) {
      if (this.selectedDescription[Constants.PackageGroups] !== undefined && this.selectedDescription[Constants.PackageGroups].length > 0) {
        // this.packageGroup = this.selectedDescription[Constants.PackageGroups][0].Packages;
        this.selectedDescription[Constants.PackageGroups].forEach(pkgGroup => {

          pkgGroup.Packages.forEach(element => { element.ischecked = false; });

          if(pkgGroup.PackageGroupId == 0){
            pkgGroup.Packages.forEach(pkg=>{
              const optPkg=[];
              optPkg.push(pkg);
              this.packageGroup.push({
                isError: false,
                packageGroupId: pkg.PackageId,
                packages: optPkg
              });
            })
          }
          else{
          this.packageGroup.push({
            isError: false,
            packageGroupId: pkgGroup.PackageGroupId,
            packages: pkgGroup.Packages
          });
        }
        });
      }
      if (this.selectedDescription[Constants.MandatoryPackages] !== undefined) {
        this.mandatoryPackage = this.selectedDescription[Constants.MandatoryPackages];
      }
    }

    if (this.selectedPackages && this.packageGroup) {
      //prechecked the checkboxes
      this.packageGroup.forEach(pkgGroup=>{
        pkgGroup.packages.forEach(pkg=>{
          this.selectedPackages.some(x=>x.PackageId==pkg.PackageId)?pkg.ischecked=true:pkg.ischecked=false
        })
      });
      this.selectedPackages.forEach(selPkg=>{
        this.packageGroup.forEach(pkgGroup=>{
         const pkgsel = pkgGroup.packages.find(pkg=> pkg.PackageId == selPkg.PackageId)
         if(pkgsel != undefined){
            const pkgGroupKey = pkgsel.PackageGroupId==0 ? "PK"+ pkgsel.PackageId:"PG" + pkgsel.PackageGroupId;
            selPkg.PackageGroupId = pkgsel.PackageGroupId;
            const newSelPkg = _.cloneDeep(pkgsel);
            delete this.selectedPackageGroup[pkgGroupKey];
            this.selectedPackageGroup[pkgGroupKey] = [];
            this.selectedPackageGroup[pkgGroupKey].push(newSelPkg);
         }
        })
      });
    } else {
      this.selectedPackageGroup = [];
    }
  }

  // Enable/Disable Select Insurance button
  enableSelectInsuranceBtn(salesModel: string, subType: string, description: string, productTerm: string) {
    if (salesModel && description && subType && productTerm && !this.initialupdateLoad) {
      this.enableSelectInsurance = true;
    } else {
      this.enableSelectInsurance = false;
    }
  }

  //  Enable/Disable Select Insurance button on the basis of dropdpwn changes
  dropdownChanged() {
    this.initialupdateLoad = false;
    this.selectedProduct = [];
    this.selectedProductData = null;
    this.enableSelectInsuranceBtn(this.selectedSalesModel[Constants.Code],
      this.selectedSubType[Constants.Code], this.selectedDescription[Constants.Description],
      this.selectedProductTerm[Constants.ProductTermType]);
  }

  // Set selected product and to fetch question-answer
  setSelectedProduct() {
    const selectedProduct = _.cloneDeep(this.selectedDescription);
    this.packageGroup.forEach(pkg => { pkg.isError=false; });//remove the error message

    let selectedPackage = []; // _.cloneDeep(this.selectedPackageGroup);
    if (selectedProduct !== Constants.Empty && selectedProduct !== undefined && selectedProduct[Constants.ProductId] !== undefined) {
      if (selectedProduct[Constants.PackageGroups].length > 0) {
        selectedProduct[Constants.PackageGroups] = [];

          Object.keys(this.selectedPackageGroup).forEach(pkgGroupKey => {
            this.selectedPackageGroup[pkgGroupKey].forEach(pkg => {
              if(pkg.ischecked){
              let pkgCopy = _.cloneDeep(pkg);
              delete pkgCopy.ischecked;
              selectedProduct[Constants.PackageGroups].push({
                PackageGroupId: pkgCopy.PackageGroupId,
                Packages: [pkgCopy]
              });
            }
            });
          })

      }
      this.srvInsurance.setSelectedProductTerm(<ProductTerm> this.selectedProductTerm);
      this.srvInsurance.setSelectedProduct(<Product>selectedProduct);
      this.changeProduct.emit(null);
    }
  }

  setSelectedOptionalPackage(optionalPackage, packageGroupId, event) {
    const pkgGroupKey=optionalPackage.PackageGroupId==0?"PK"+ optionalPackage.PackageId:"PG"+optionalPackage.PackageGroupId;
    if (event.target.checked) {
      if (this.selectedPackageGroup[pkgGroupKey]) {

        this.packageGroup.forEach(pkg => {
          if(pkg.packageGroupId == optionalPackage.PackageGroupId) {
            pkg.isError = true;

            pkg.packages.forEach(pkgItem => {
              if(pkgItem.PackageId != optionalPackage.PackageId) {
                pkgItem.ischecked = false;
              }
            });
          }
        });
      }
      delete this.selectedPackageGroup[pkgGroupKey];
      this.selectedPackageGroup[pkgGroupKey] = [];
      this.selectedPackageGroup[pkgGroupKey].push(optionalPackage);

    } else {
      delete this.selectedPackageGroup[pkgGroupKey];
    }
  }

  // Reset the Mandatory & optional package
  resetPackages() {
    this.packageGroup = this.mandatoryPackage=[];
    this.selectedPackageGroup = [];
  }

  ngOnDestroy() {
    if (this.subProducts) {
      this.subProducts.unsubscribe();
    }
    if (this.subSelectedAgreement) {
      this.subSelectedAgreement.unsubscribe();
    }
  }
}
