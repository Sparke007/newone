import { ModuleWithProviders } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';

import { InsuranceWrapperComponent } from './insurance-wrapper/insurance-wrapper.component';
import { InsuranceEditComponent } from './insurance-action/insurance-edit/insurance-edit.component';
import { InsuranceManageComponent } from './insurance-action/insurance-manage/insurance-manage.component';
import { InsuranceCancelComponent } from './insurance-action/insurance-cancel/insurance-cancel.component';
import { AuthGuard } from '../shared/services/auth-guard.service';

const appInsuranceRoutes: Routes = [
    {
        path: 'insurance',
        component: InsuranceWrapperComponent,
        canActivateChild: [AuthGuard],
        children: [
           /*  {
                path: 'add',
                component: InsuranceEditComponent,
            },
            {
                path: 'update/:policyId',
                component: InsuranceEditComponent
            }, */
            {
                path: 'manage/:action',
                component: InsuranceEditComponent
            },
            {
                path: 'manage/:action/:policyId',
                component: InsuranceEditComponent
            },
           /*  {
                path: 'cancel/:policyId',
                component: InsuranceCancelComponent
            } */
        ]
    },
    /* {
        path: "**",
        redirectTo: "/"
    } */
];

export const InsuranceRoutingModule: ModuleWithProviders = RouterModule.forChild(appInsuranceRoutes);
