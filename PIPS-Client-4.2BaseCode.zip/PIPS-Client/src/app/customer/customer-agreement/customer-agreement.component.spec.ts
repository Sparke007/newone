import { ComponentFixture, TestBed } from '@angular/core/testing';
import { NO_ERRORS_SCHEMA } from '@angular/core';
import { Router } from '@angular/router';
import { ActivatedRoute } from '@angular/router';
import { CustomerService } from '../../shared/services/customer.service';
import { CustomerAgreementComponent } from './customer-agreement.component';

describe('CustomerAgreementComponent', () => {
    let comp: CustomerAgreementComponent;
    let fixture: ComponentFixture<CustomerAgreementComponent>;

    beforeEach(() => {
        const routerStub = {
            navigate: () => ({})
        };
        const activatedRouteStub = {
            params: {
                subscribe: () => ({})
            }
        };
        const customerServiceStub = {
            getCustomerByPIN: () => ({
                subscribe: () => ({})
            }),
            nationalId: {
                getValue: () => ({})
            },
            selectedCustomer: {
                // tslint:disable-next-line:max-line-length
                subscribe: () => ({
                        'CustomerId': 36000013573, 'BirthDate': '1962-05-05T00:00:00', 'Pin': '59022702344', 'CustomerStatusCode': 'CC', 'DisplayName': 'Pani Cyprian Nowak', 'ContactDetails': {'EmailAddress': null, 'ShortAddress': '43-100 Tychy Azaliowa 34 3', 'Telephone': [{'PhoneNumberType': 'MO', 'PhoneNumber': '36123456789'}]},
                        // tslint:disable-next-line:max-line-length
                        'Agreements': [{'AgreementId': 36000016765, 'AgreementNumber': '241246089', 'AgreementStatus': 'PU', 'IssueDate': '2005-01-22T00:00:00', 'IssuerId': 36000122635, 'Term': 52, 'IssueValue': 500.0, 'FirstPaymentDueDate': '2005-01-29T00:00:00', 'RepaymentFrequency': 'WE', 'Distribution': 'Home Collected'}],
                        // tslint:disable-next-line:max-line-length
                        'Insurance': [{'PolicyId': 'a38e2fe3-c1a0-45c8-a963-10c178cfd095', 'AgreementId': 36000016765, 'PolicyNumber': 'AB3333333', 'StartDate': '11/25/2015 00:00:00', 'ProductDescription': 'Health', 'Status': 'Active'}]
                    })
            },
            setSelectedAgreement: () => ({})
        };
        TestBed.configureTestingModule({
            declarations: [CustomerAgreementComponent],
            schemas: [NO_ERRORS_SCHEMA],
            providers: [
                { provide: Router, useValue: routerStub },
                { provide: ActivatedRoute, useValue: activatedRouteStub },
                { provide: CustomerService, useValue: customerServiceStub }
            ]
        });
        fixture = TestBed.createComponent(CustomerAgreementComponent);
        comp = fixture.componentInstance;
    });

    it('can load instance', () => {
        expect(comp).toBeTruthy();
    });

    it('agreements defaults to: []', () => {
        expect(comp.agreements).toEqual([]);
    });

    describe('ngOnInit', () => {
        it('makes expected calls', () => {
            const routerStub: Router = fixture.debugElement.injector.get(Router);
            const customerServiceStub: CustomerService = fixture.debugElement.injector.get(CustomerService);
            spyOn(routerStub, 'navigate');
            spyOn(customerServiceStub, 'getCustomerByPIN');
            comp.ngOnInit();
            customerServiceStub.selectedCustomer.next(this.customerServiceStub.selectedCustomer);
            expect(routerStub.navigate).toHaveBeenCalled();
            expect(customerServiceStub.getCustomerByPIN).toHaveBeenCalled();
        });
    });

});
