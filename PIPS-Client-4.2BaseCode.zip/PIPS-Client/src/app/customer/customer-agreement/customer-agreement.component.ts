import { Component, OnDestroy, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { ISubscription } from 'rxjs/Subscription';

import { Constants } from '../../shared/interfaces/constants';
import { Agreement, Customer } from '../../shared/interfaces/customer.interface';
import { CustomerService } from '../../shared/services/customer.service';
import { HttpLocaleService } from '../../shared/services/http-locale.service';


@Component({
  selector: 'app-customer-agreement',
  templateUrl: './customer-agreement.component.html',
  styleUrls: ['./customer-agreement.component.css']
})
export class CustomerAgreementComponent implements OnInit, OnDestroy {

  locale: string;

  customer: Customer;
  agreements: Agreement[] = [];

  subSelectedCustomer: ISubscription;
  subCustomerByPIN: ISubscription;
  subRoute: ISubscription;

  constructor(private srvCustomer: CustomerService, private router: Router, private route: ActivatedRoute,
    private srvHttpLocale: HttpLocaleService) { }

  ngOnInit() {

    this.locale = this.srvHttpLocale.locale.getValue();

    this.subRoute = this.route.params.subscribe(params => {
      if (params.action === Constants.Refresh) {
        setTimeout(() => {
          this.getCustomer();
        }, 5000);
        setTimeout(() => {
          this.getCustomer();
        }, 15000);
        setTimeout(() => {
          this.getCustomer();
        }, 30000);
      }
    });

    this.subSelectedCustomer = this.srvCustomer.selectedCustomer.subscribe(selectedCustomer => {
      if (isNaN(selectedCustomer.CustomerId)) {
        // this.router.navigate(['/']);
      } else {
        this.customer = selectedCustomer;
        this.agreements = selectedCustomer.Agreements.filter(x => Date.parse(x.EndDate) >= new Date().setHours(0,0,0,0));
      }
    });
  }

  getCustomer() {
    if (this.srvCustomer.nationalId.getValue()) {
      this.subCustomerByPIN = this.srvHttpLocale.subscribeBasedonToken(this.srvCustomer.
        getCustomerByPIN(this.srvCustomer.nationalId.getValue(), Constants.Empty, false));
    }
    if (this.srvCustomer.customerId.getValue()) {
      this.subCustomerByPIN = this.srvHttpLocale.subscribeBasedonToken(this.srvCustomer.
        getCustomerByCID(this.srvCustomer.getCustomerIdValidFormat(this.srvCustomer.customerId.getValue()), false));
    }
  }
  selectAgreement(agreementIndex) {
    this.srvCustomer.setSelectedAgreement(this.agreements[agreementIndex]);
    this.router.navigate([Constants.NavLinkAddInsurance]);
  }

  ngOnDestroy() {
    if (this.subSelectedCustomer) {
      this.subSelectedCustomer.unsubscribe();
    }
    if (this.subCustomerByPIN) {
      this.subCustomerByPIN.unsubscribe();
    }
    if (this.subRoute) {
      this.subRoute.unsubscribe();
    }
  }
}
