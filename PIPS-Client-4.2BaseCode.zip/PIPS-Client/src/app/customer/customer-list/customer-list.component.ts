import { Component, OnDestroy, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { ISubscription } from 'rxjs/Subscription';

import { CustomerService } from '../../shared/services/customer.service';


@Component({
  selector: 'app-customer-list',
  templateUrl: './customer-list.component.html',
  styleUrls: ['./customer-list.component.css']
})
export class CustomerListComponent implements OnInit, OnDestroy {

  customerList = [];

  subCustomerList: ISubscription;

  constructor(private srvCustomer: CustomerService, private router: Router, private route: ActivatedRoute) {

  }

  ngOnInit() {
      this.subCustomerList = this.srvCustomer.customerList.subscribe(customerList => {
          this.customerList = customerList;
      });
  }

  selectCustomer(customerIndex) {
    this.srvCustomer.setSelectedCustomer(this.customerList[customerIndex]);

    this.router.navigate(['./loan-agreement'], { relativeTo: this.route });
  }

  ngOnDestroy() {
    this.subCustomerList.unsubscribe();
  }
}
