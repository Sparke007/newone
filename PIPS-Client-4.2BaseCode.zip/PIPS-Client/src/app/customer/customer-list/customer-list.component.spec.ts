import { NO_ERRORS_SCHEMA } from '@angular/core';
import { ComponentFixture, TestBed } from '@angular/core/testing';
import { Router } from '@angular/router';
import { ActivatedRoute } from '@angular/router';

import { CustomerService } from '../../shared/services/customer.service';
import { CustomerListComponent } from './customer-list.component';

describe('CustomerListComponent', () => {
    let comp: CustomerListComponent;
    let fixture: ComponentFixture<CustomerListComponent>;

    beforeEach(() => {
        const customerServiceStub = {
            nationalId: {
                subscribe: () => ({})
            },
            customerList: {
                subscribe: () => ({})
            },
            setSelectedCustomer: () => ({})
        };
        const routerStub = {
            navigate: () => ({})
        };
        const activatedRouteStub = {};
        TestBed.configureTestingModule({
            declarations: [ CustomerListComponent ],
            schemas: [ NO_ERRORS_SCHEMA ],
            providers: [
                { provide: CustomerService, useValue: customerServiceStub },
                { provide: Router, useValue: routerStub },
                { provide: ActivatedRoute, useValue: activatedRouteStub }
            ]
        });
        fixture = TestBed.createComponent(CustomerListComponent);
        comp = fixture.componentInstance;
    });

    it('can load instance', () => {
        expect(comp).toBeTruthy();
    });

    it('customerList defaults to: []', () => {
        expect(comp.customerList).toEqual([]);
    });

});
