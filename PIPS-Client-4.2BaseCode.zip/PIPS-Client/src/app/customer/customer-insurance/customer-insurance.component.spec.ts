import { ComponentFixture, TestBed } from '@angular/core/testing';
import { NO_ERRORS_SCHEMA } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { Router } from '@angular/router';
import { CustomerService } from '../../shared/services/customer.service';
import { CustomerInsuranceComponent } from './customer-insurance.component';

describe('CustomerInsuranceComponent', () => {
    let comp: CustomerInsuranceComponent;
    let fixture: ComponentFixture<CustomerInsuranceComponent>;

    beforeEach(() => {
        const activatedRouteStub = {};
        const routerStub = {
            navigate: () => ({})
        };
        const customerServiceStub = {
            selectedCustomer: {
                subscribe: () => ({})
            },
            setSelectedAgreement: () => ({})
        };
        TestBed.configureTestingModule({
            declarations: [ CustomerInsuranceComponent ],
            schemas: [ NO_ERRORS_SCHEMA ],
            providers: [
                { provide: ActivatedRoute, useValue: activatedRouteStub },
                { provide: Router, useValue: routerStub },
                { provide: CustomerService, useValue: customerServiceStub }
            ]
        });
        fixture = TestBed.createComponent(CustomerInsuranceComponent);
        comp = fixture.componentInstance;
    });

    it('can load instance', () => {
        expect(comp).toBeTruthy();
    });

    it('agreements defaults to: []', () => {
        expect(comp.agreements).toEqual([]);
    });

});
