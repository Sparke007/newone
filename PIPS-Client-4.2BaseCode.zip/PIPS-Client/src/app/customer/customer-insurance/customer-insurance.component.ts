import { ActivatedRoute, Router } from '@angular/router';
import { Component, OnDestroy, OnInit } from '@angular/core';
import { ISubscription } from 'rxjs/Subscription';
import { DatePipe } from '@angular/common';

import { Agreement, Customer } from '../../shared/interfaces/customer.interface';
import { CustomerService } from '../../shared/services/customer.service';

@Component({
  selector: 'app-customer-insurance',
  templateUrl: './customer-insurance.component.html',
  styleUrls: ['./customer-insurance.component.css']
})
export class CustomerInsuranceComponent implements OnInit, OnDestroy {
  customer: Customer;
  agreements: Agreement[] = [];
  insuranceList = [];
  insuranceCount = 0;

  subSelectedCustomer: ISubscription;
  constructor(private srvCustomer: CustomerService, private router: Router, private route: ActivatedRoute, public datepipe: DatePipe) { }

  ngOnInit() {
    this.subSelectedCustomer = this.srvCustomer.selectedCustomer.subscribe(selectedCustomer => {
      this.customer = selectedCustomer;
      this.agreements = selectedCustomer.Agreements;
      this.insuranceList = [];
      
      this.srvCustomer.setSelectedAgreement(new Agreement);
      this.srvCustomer.agreementSetSelectedAgreement(new Agreement);

      if (selectedCustomer.Agreements && selectedCustomer.Agreements.length) {
        selectedCustomer.Agreements.forEach((agreement, index) => {
          if (agreement.Insurance && agreement.Insurance.length > 0) {
            agreement.Insurance = Array.from(new Set(agreement.Insurance));
            agreement.Insurance.forEach((insurance, insuranceIndex) => {
              const tempInsurance = insurance;
              tempInsurance['AgreementNumber'] = agreement.AgreementNumber;
              tempInsurance['AgreementIndex'] = index;
              tempInsurance['InsuranceIndex'] = insuranceIndex;
              this.insuranceList.push(tempInsurance);
            });
          }
        });
        this.insuranceCount = selectedCustomer.Agreements.filter(i => i.Insurance).length;
      }
      this.insuranceList.sort(function (a, b) {
        const c: number = (new Date(a.StartDate)).valueOf();
        const d: number = (new Date(b.StartDate)).valueOf();
        return d - c;
      });
    });
  }

  insuranceAction(insuranceIndex: number, agreementIndex: number, action: string) {
    this.srvCustomer.setSelectedAgreement(this.agreements[agreementIndex]);
    const insurance = this.agreements[agreementIndex].Insurance[insuranceIndex];
    action = ((insurance.Status === 'CA' || insurance.Status === 'RE') && action === 'Update') ? 'updatecancel' : action;
    this.router.navigate([action !== undefined ? '/insurance/manage/' + action.toLowerCase() : '/',
    insurance.PolicyId], { relativeTo: this.route });
  }
  ngOnDestroy() {
    if (this.subSelectedCustomer) {
      this.subSelectedCustomer.unsubscribe();
    }
  }
}
