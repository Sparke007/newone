import { Component, OnDestroy, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { ISubscription } from 'rxjs/Subscription';

import { Agreement, Customer, CustomerLoan } from '../../shared/interfaces/customer.interface';
import { CustomerService } from '../../shared/services/customer.service';
import { Constants } from '../../shared/interfaces/constants';

@Component({
  selector: 'app-customer-details',
  templateUrl: './customer-details.component.html',
  styleUrls: ['./customer-details.component.css']
})
export class CustomerDetailsComponent implements OnInit, OnDestroy {
  customer: Customer;
  subSelectedCustomer: ISubscription;
  subSelectedAgreement: ISubscription;
  subRoute: ISubscription;

  loanAgreement: CustomerLoan;

  constructor(private srvCustomer: CustomerService, private activatedRoute: ActivatedRoute) { }

  ngOnInit() {

    this.subRoute = this.activatedRoute.firstChild.params.subscribe(params => {
      let selectCustomer;
      let selectAgreement;
      if (params.action) {
        if (params.action !== Constants.Update) {
          selectCustomer = this.srvCustomer.selectedCustomer;
          selectAgreement = this.srvCustomer.selectedAgreement;
        } else {
          selectCustomer = this.srvCustomer.agreementSelectedCustomer;
          selectAgreement = this.srvCustomer.agreementselectedAgreement;
        }
        this.subSelectedCustomer = selectCustomer.subscribe(selectedCustomer => {
          if (isNaN(selectedCustomer.CustomerId)) {
            // this.router.navigate(['/']);
          } else {
            this.customer = selectedCustomer;
          }
        });

        this.subSelectedAgreement = selectAgreement.subscribe(agreementDetails => {
          this.loanAgreement = agreementDetails;
        });
      }
    });

  }

  ngOnDestroy(): void {
    if (this.subSelectedCustomer) {
      this.subSelectedCustomer.unsubscribe();
    }
    if (this.subSelectedAgreement) {
      this.subSelectedAgreement.unsubscribe();
    }
    if (this.subRoute) {
      this.subRoute.unsubscribe();
    }
  }
}
