import { NO_ERRORS_SCHEMA } from '@angular/core';
import { ComponentFixture, TestBed } from '@angular/core/testing';
import { Router } from '@angular/router';

import { CustomerDetailsComponent } from './customer-details.component';
import { CustomerService } from '../../shared/services/customer.service';

describe('CustomerDetailsComponent', () => {
    let comp: CustomerDetailsComponent;
    let fixture: ComponentFixture<CustomerDetailsComponent>;

    beforeEach(() => {
        const routerStub = {
            navigate: () => ({})
        };
        const customerServiceStub = {
            selectedCustomer: {
                subscribe: () => ({})
            },
            selectedAgreement: {
                subscribe: () => ({})
            }
        };
        TestBed.configureTestingModule({
            declarations: [ CustomerDetailsComponent ],
            schemas: [ NO_ERRORS_SCHEMA ],
            providers: [
                { provide: Router, useValue: routerStub },
                { provide: CustomerService, useValue: customerServiceStub }
            ]
        });
        fixture = TestBed.createComponent(CustomerDetailsComponent);
        comp = fixture.componentInstance;
    });

    it('can load instance', () => {
        expect(comp).toBeTruthy();
    });

    describe('ngOnInit', () => {
        xit('makes expected calls', () => {
            const routerStub: Router = fixture.debugElement.injector.get(Router);
            spyOn(routerStub, 'navigate');
            comp.ngOnInit();
            expect(routerStub.navigate).toHaveBeenCalled();
        });
    });

});
