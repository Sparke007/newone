import { ModuleWithProviders } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';

import { CustomerAgreementComponent } from './customer-agreement/customer-agreement.component';
import { CustomerListComponent } from './customer-list/customer-list.component';
import { CustomerWrapperComponent } from './customer-wrapper/customer-wrapper.component';
import { AuthGuard } from '../shared/services/auth-guard.service';

const appCustomerRoutes: Routes = [
    {
        path: 'customer',
        component: CustomerWrapperComponent,
        canActivateChild: [AuthGuard],
        children: [
            {
                path: '',
                component: CustomerListComponent
            },
            {
                path: 'list',
                component: CustomerListComponent
            },
            {
                path: 'loan-agreement',
                component: CustomerAgreementComponent
            },
            {
                path: 'loan-agreement/:action',
                component: CustomerAgreementComponent
            }
        ]
    },
];

export const CustomerRoutingModule: ModuleWithProviders = RouterModule.forChild(appCustomerRoutes);
