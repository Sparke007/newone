import { NO_ERRORS_SCHEMA } from '@angular/core';
import { ComponentFixture, TestBed } from '@angular/core/testing';
import { Router } from '@angular/router';
import { ActivatedRoute } from '@angular/router';

import { CustomerService } from '../../shared/services/customer.service';
import { SharedModule } from '../../shared/shared.module';
import { CustomerSearchComponent } from './customer-search.component';

describe('CustomerSearchComponent', () => {
    let comp: CustomerSearchComponent;
    let fixture: ComponentFixture<CustomerSearchComponent>;
    let customerService: CustomerService;

    beforeEach(() => {
        const routerStub = {
            navigate: () => ({})
        };
        const activatedRouteStub = {};
        const customerServiceStub = {
            nationalId: {
                subscribe: () => ({})
            },
            customerList: {
                subscribe: () => ({})
            },
            setNationalId: () => ({})
        };
        TestBed.configureTestingModule({
            imports: [SharedModule],
            declarations: [ CustomerSearchComponent ],
            schemas: [ NO_ERRORS_SCHEMA ],
            providers: [
                { provide: Router, useValue: routerStub },
                { provide: ActivatedRoute, useValue: activatedRouteStub },
                { provide: CustomerService, useValue: customerServiceStub }
            ]
        });
        fixture = TestBed.createComponent(CustomerSearchComponent);
        comp = fixture.componentInstance;
        customerService = TestBed.get(CustomerService);
    });

    it('can load instance', () => {
        expect(comp).toBeTruthy();
    });

    it('warningMessageList defaults to: []', () => {
        expect(comp.warningMessageList).toEqual([]);
    });

    it('errorMessageList defaults to: []', () => {
        expect(comp.errorMessageList).toEqual([]);
    });

    it('noRecordFound defaults to: false', () => {
        expect(comp.noRecordFound).toEqual(false);
    });

    describe('ngOnInit', () => {
        it('should set focus on National ID PIN', () => {
            spyOn(comp, 'setNationalPinFocus');
            comp.ngOnInit();
            expect(comp.setNationalPinFocus).toHaveBeenCalled();
        });
        it('should subscribe to nationalId and customerList', () => {
            spyOn(customerService.nationalId, 'subscribe');
            spyOn(customerService.customerList, 'subscribe');

            comp.ngOnInit();

            expect(customerService.nationalId.subscribe).toHaveBeenCalled();
            expect(customerService.customerList.subscribe).toHaveBeenCalled();
        });
    });

    describe('ngOnDestroy', () => {
        xit('unsubscribes all subscriptions', () => {
            spyOn(customerService.nationalId, 'unsubscribe');
            spyOn(customerService.customerList, 'unsubscribe');

            comp.ngOnDestroy();

            expect(customerService.nationalId).toHaveBeenCalled();
            expect(customerService.customerList).toHaveBeenCalled();
        });
    });

    describe('validateForm', () => {
        it('should return error message', () => {
            comp.validateForm('','');
            expect(comp.errorMessageList.length).toBe(1);
        });
        it('should return warning message when PIN is not of 11 digit', () => {
            comp.validateForm('123','');
            expect(comp.warningMessageList.length).toBe(1);
        });
        it('should return warning message if PIN is non-numeric', () => {
            comp.validateForm('123sdf','');
            expect(comp.warningMessageList.length).toBe(1);
        });
        it('should return 0 when valid number is entered', () => {
            const retVal = comp.validateForm('12121212121','');
            expect(retVal).toBe(0);
        });
    });

    describe('onSubmit', () => {
        it('should call validateForm method', () => {
            spyOn(comp, 'validateForm');

            comp.onSubmit({pin: '123'});

            expect(comp.validateForm).toHaveBeenCalled();
        });
        it('should call set National PIN when validation is returned without error', () => {
            spyOn(customerService, 'setNationalId');

            comp.onSubmit({pin: '12312312311'});

            expect(customerService.setNationalId).toHaveBeenCalled();
        });
    });
});
