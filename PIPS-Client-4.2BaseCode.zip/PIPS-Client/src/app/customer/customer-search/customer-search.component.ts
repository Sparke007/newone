import { Component, OnDestroy, OnInit, ViewChild } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { ISubscription } from 'rxjs/Subscription';

import { Search } from '../../shared/interfaces/customer.interface';
import { CustomerService } from '../../shared/services/customer.service';
import { Constants } from '../../shared/interfaces/constants';

@Component({
  selector: 'app-customer-search',
  templateUrl: './customer-search.component.html',
  styleUrls: ['./customer-search.component.css']
})
export class CustomerSearchComponent implements OnInit, OnDestroy {

  warningMessageList = [];
  errorMessageList = [];
  errorCustomerId: Boolean = false;
  errorPin: Boolean = false;
  noRecordFound = false;
  searchTouched = false;

  customer: Search = new Search();
  @ViewChild(Constants.Pinfocus) pinfocus: any;
  @ViewChild(Constants.Cidfocus) cidfocus: any;

  subNationalId: ISubscription;
  subCustomerId: ISubscription;
  subCustomerList: ISubscription;

  constructor(private srvCustomer: CustomerService, private router: Router, private route: ActivatedRoute) {
  }

  ngOnInit() {
    this.subNationalId = this.srvCustomer.nationalId.subscribe(nationalId => {
      this.customer.Pin = nationalId;
      if (this.customer.Pin && this.searchTouched) {
        this.validateForm(nationalId, Constants.Empty);
      }
    });

    this.subCustomerId = this.srvCustomer.customerId.subscribe(customerId => {
      this.customer.CustomerId = customerId;
      if (!this.customer.CustomerId && this.searchTouched) {
        this.validateForm(Constants.Empty, this.customer.CustomerId);
      }
    });


    this.subCustomerList = this.srvCustomer.customerList.subscribe(customerList => {
      this.errorMessageList = [];
      if (customerList !== undefined && customerList.length > 0) {
      } else if (this.customer && this.customer.Pin && this.searchTouched) {
        this.navigateToHome();
        this.errorPin = true;
        this.errorMessageList.push(Constants.ErrorCustomerNotFoundbyPin);
        this.validatedPin(this.customer.Pin);
      } else if (sessionStorage.getItem(Constants.CustomerId) && this.searchTouched) {
        this.errorMessageList.push(Constants.ErrorCustomerNotFoundbyCid);
        this.errorCustomerId = true;
        this.navigateToHome();
      }
    });
  }

  onSubmit(customer) {
    customer.pin = (customer.pin) ? customer.pin.trim() : (customer.pin);
    customer.customerId = (customer.customerId) ? customer.customerId.trim() : (customer.customerId);

    //  this.searchTouched = true;
    this.validateForm(customer.pin, customer.customerId);
    this.searchTouched = true;
    if (customer.pin) {
      this.setNationalPinFocus();
      this.srvCustomer.setCustomerId(Constants.Empty);
      this.srvCustomer.setNationalId(customer.pin);
    } else if (customer.customerId && !this.errorMessageList.length) {
      this.setCustomerIdFocus();
      this.srvCustomer.setNationalId(Constants.Empty);
      this.srvCustomer.setCustomerId(customer.customerId);
    }
    if (!this.errorMessageList.length && (customer.pin !== Constants.Empty ||
      customer.customerId !== Constants.Empty || customer.customerId === undefined)) {
      this.navigateToHome();
    }
  }

  // Validate the input pin & customer id
  validateForm(pin, customerId) {
    this.errorMessageList = [];
    this.warningMessageList = [];
    this.errorCustomerId = false;
    this.errorPin = false;
    if ((pin === undefined || pin === Constants.Empty) &&
      (customerId === undefined || customerId === Constants.Empty)) {
        this.errorCustomerId =  true;
        this.errorPin = true;
      this.errorMessageList.push(Constants.ErrorPinCustomerIdRequired);
    } else if (pin) {
      (this.validatedPin(pin));
    } else if (customerId) {
      if (! new RegExp(Constants.RegexCustomerIdSearch).test(customerId)) {
        this.errorCustomerId = true;
        this.errorMessageList.push(Constants.ErrorCustomerIdInvalid);
        this.navigateToHome();
      }
    }
    return this.warningMessageList.length + this.errorMessageList.length;
  }

  // Validate the input pin format
  validatedPin(pin) {
    this.warningMessageList = [];
    if (! new RegExp(Constants.RegexPinSearch).test(pin)) {
      this.warningMessageList.push(Constants.ErrorPinIsNumeric);
      this.errorPin = true;
    } else if (pin.length < 11 || pin.length > 11) {
      this.warningMessageList.push(Constants.ErrorPinDigit);
      this.errorPin = true;
    }
  }


  // navigate To original Page
  navigateToHome() {
    this.router.navigate(['./'], { relativeTo: this.route });
  }



  // Set focus on Pin
  setNationalPinFocus() {
    this.pinfocus.nativeElement.focus();
  }

  // Set focus on Customer Id
  setCustomerIdFocus() {
    this.cidfocus.nativeElement.focus();
  }

  ngOnDestroy(): void {
    this.subNationalId.unsubscribe();
    this.subCustomerId.unsubscribe();
    this.subCustomerList.unsubscribe();
  }
}
