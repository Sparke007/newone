import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';

import { CustomerSearchComponent } from './customer-search/customer-search.component';
import { CustomerListComponent } from './customer-list/customer-list.component';
import { CustomerAgreementComponent } from './customer-agreement/customer-agreement.component';
import { CustomerWrapperComponent } from './customer-wrapper/customer-wrapper.component';

const routes: Routes = [
    {
        path: '*',
        component: CustomerWrapperComponent
    },
    {
        path: 'customer',
        component: CustomerWrapperComponent,
        pathMatch: 'full',
        children: [
            {
                path: '*',
                component: CustomerListComponent,
                // pathMatch: 'full'
            },
            {
                path: 'list',
                component: CustomerListComponent,
                // outlet: "customer-route-outlet"
            },
            {
                path: 'loan-agreement',
                component: CustomerAgreementComponent,
                // outlet: "customer-route-outlet"
            }
        ]
    }
];

@NgModule({
    imports: [
        RouterModule.forChild(routes)
    ],
    declarations: [],
    exports: [
        RouterModule
    ]
})
export class CustomersRoutingModule { }
