import { NgModule } from '@angular/core';
import { RouterModule } from '@angular/router';

import { SharedModule } from '../shared/shared.module';
import { CustomerAgreementComponent } from './customer-agreement/customer-agreement.component';
import { CustomerInsuranceComponent } from './customer-insurance/customer-insurance.component';
import { CustomerListComponent } from './customer-list/customer-list.component';
import { CustomerRoutingModule } from './customer-routing.module';
import { CustomerSearchComponent } from './customer-search/customer-search.component';
import { CustomerWrapperComponent } from './customer-wrapper/customer-wrapper.component';

// import { CommonModule } from '@angular/common';
@NgModule({
  imports: [
    SharedModule,
    RouterModule,
    CustomerRoutingModule
  ],
  declarations: [
    CustomerListComponent,
    CustomerSearchComponent,
    CustomerAgreementComponent,
    CustomerWrapperComponent,
    CustomerInsuranceComponent
  ]
})
export class CustomerModule { }
