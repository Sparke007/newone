import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-customer-wrapper',
  templateUrl: './customer-wrapper.component.html',
  styleUrls: ['./customer-wrapper.component.css']
})
export class CustomerWrapperComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
