import { NO_ERRORS_SCHEMA } from '@angular/core';
import { ComponentFixture, TestBed } from '@angular/core/testing';

import { CustomerWrapperComponent } from './customer-wrapper.component';

describe('CustomerWrapperComponent', () => {
    let comp: CustomerWrapperComponent;
    let fixture: ComponentFixture<CustomerWrapperComponent>;

    beforeEach(() => {
        TestBed.configureTestingModule({
            declarations: [ CustomerWrapperComponent ],
            schemas: [ NO_ERRORS_SCHEMA ]
        });
        fixture = TestBed.createComponent(CustomerWrapperComponent);
        comp = fixture.componentInstance;
    });

    it('can load instance', () => {
        expect(comp).toBeTruthy();
    });

});
