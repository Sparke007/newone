export const environment = {
  production: true,
  availableLocale: ['en', 'pl'],
  domainURLPIP: 'http://DC2WGUATKONG001.UAT01.LOCAL:80/uat/edge/insurancesPipsClient.v1/',
  domainURLKong: 'https://dc2uat01pipa101.uat01.local:9030/api/',
  lifeTimeTokenThreshold: 50,
  loaderDelaySeconds: 0,
};

// http://10.82.11.22:9020/api/
// http://DC2WGPREKONG101.uat01.local/uat/edge/insurancesPipsClient.v1/
//https://dc2pre01pipa001.uat01.local:9030/api/
