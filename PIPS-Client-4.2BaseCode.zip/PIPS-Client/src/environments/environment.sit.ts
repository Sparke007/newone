export const environment = {
  production: true,
  availableLocale: ['en', 'pl'],
  domainURLPIP: 'https://dc2wgdevkong101.dev01.local/st/edge/insurancesPipsClient.v1/',
  domainURLKong: 'https://dc2dev01fts005.dev01.local:9030/api/',
  lifeTimeTokenThreshold: 50,
  loaderDelaySeconds: 0,
};

// http://10.55.5.73:9091/api/
// http://dc2wgdevkong101.dev01.local/st/edge/insurancesPipsClient.v1/
