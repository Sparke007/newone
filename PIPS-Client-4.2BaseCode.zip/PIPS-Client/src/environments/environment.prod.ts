export const environment = {
  production: true,
  availableLocale: ['en', 'pl'],
  domainURLPIP: 'https://dc1prd01kongnlb01.prod01.local/prd/edge/insurancesPipsClient.v1/',
  domainURLKong: 'https://DC1PRD01PIPANLB01.PROD01.local:9030/api/',
  lifeTimeTokenThreshold: 50,
  loaderDelaySeconds: 0,
};
